package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpWexPageInfo;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpToWexTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpToWexTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;
	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info(" Enter in to SCBOcrNlpToWexTransformer calss ");
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object source = null;
			SCBCommObj commObj = null;
			String loggerDealId = EMPTY;
			String indexCount;
			int index;
			try {
				source = message.getPayload();
				loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);
				indexCount = message.getInvocationProperty(Fields.INDEX_COUNT, EMPTY);
				index = Integer.valueOf(indexCount);
				log.debug(loggerDealId + " - Enter in to NLP to WEX transformer  calss ");

				log.debug(loggerDealId + " - source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug(loggerDealId + " - source instance of comm obj ... " + source);
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					log.debug(loggerDealId + " - input request :::   ==>" + input);
					commObj = mapper.readValue(input, SCBCommObj.class);
				}

				if (null != commObj) {
					String documentId = null;
					String byteStr = null;
					SCBSection section = null;
					String wexServerCode = null;
					SCBOcrNlpWexPageInfo nlpWexPageInfo = null;
					log.debug(loggerDealId + " - MULE DEBUG ::  index :: "+index);
					if (index == 0) {
						SCBOcrNlpWexPageInfo pageInfo = new SCBOcrNlpWexPageInfo();
						nlpWexPageInfo = (SCBOcrNlpWexPageInfo) SCBCommObjTransformer.sectionToSCBPojo(commObj,
								pageInfo);
						documentId = nlpWexPageInfo.getDocumentId();
						log.info(loggerDealId + " - MULE DEBUG ::  IF 0 documentId :: "+documentId);
						//byteStr = nlpWexPageInfo.getWexPageList().get(index).getWexInput();
						String jsonResp = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(nlpWexPageInfo);
						message.setInvocationProperty(Fields.FINAL_WEX_PLAYLOAD, jsonResp);
						// process section with available WEX server
						log.debug(loggerDealId + " - assigning available WEX server to use...");
						section = ((SCBCommObj) commObj).getBodySection(Sections.GET_ACTIVE_WEX_SERVER);
						wexServerCode = section.getStringValue(Fields.WEX_SERVER_CODE);
						log.debug(loggerDealId + " - wexServerCode in the fist page ===>  "+wexServerCode);
						message.setInvocationProperty(Fields.WEX_SERVER_CODE, wexServerCode);
					} else {
						String invocationProperty = message.getInvocationProperty(Fields.FINAL_WEX_PLAYLOAD, EMPTY);
						nlpWexPageInfo = mapper.readValue(invocationProperty, SCBOcrNlpWexPageInfo.class);
						log.debug(loggerDealId + " - MULE DEBUG :: ELSE documentId :: "+documentId);
						documentId = nlpWexPageInfo.getDocumentId();
						//byteStr = nlpWexPageInfo.getWexPageList().get(index).getWexInput();
						wexServerCode = message.getInvocationProperty(Fields.WEX_SERVER_CODE, EMPTY);
					}

					SCBCommObj reqObj = new SCBCommObj();
					SCBHeader header = new SCBHeader();
					SCBFooter footer = new SCBFooter();
					reqObj.setHeader(header);
					reqObj.setFooter(footer);
					SCBSection pageSection = new SCBSection();
					pageSection.putBinaryValue(Sections.WEX_PAGE_INFO, byteStr);
					reqObj.getBody().addSection(Fields.BINARY + Sections.WEX_PAGE_INFO, pageSection);

					byte[] byteWexData = new byte[0];
					byteWexData = (byte[]) SCBCommObjTransformer.sectionToBinaryDataObj(reqObj, Sections.WEX_PAGE_INFO,
							byteWexData);
					String wexInput = new String(byteWexData);

					message.setInvocationProperty(Fields.DOCUMENT_ID, documentId);
					message.setInvocationProperty(Fields.LAYOUT_TEXT, wexInput);
					//Incrementing index in the intermediate transformer.
					message.setInvocationProperty(Fields.INDEX_COUNT, index);
					log.debug(loggerDealId + " - wexServerCode :::   ==>" + wexServerCode);

					String serverData;
					if (message.getInvocationProperty("wexServer1").toString().contains(wexServerCode))
						serverData = message.getInvocationProperty("wexServer1");
					else if (message.getInvocationProperty("wexServer2").toString().contains(wexServerCode))
						serverData = message.getInvocationProperty("wexServer2");
					else
						serverData = message.getInvocationProperty("wexServer1");

					log.debug(loggerDealId + " - WEX Server Information ===> "+serverData);
					String[] serverDataArray = serverData.split(":");
					if (serverDataArray.length == 3) {
						message.setInvocationProperty("wexHostToUse", serverDataArray[1]);
						message.setInvocationProperty("wexPortToUse", serverDataArray[2]);
					}
					log.debug(loggerDealId + " - End of  SCBNlpToWexTransformer ");
				}
			} catch (Exception e) {
				throw new TransformerException(CoreMessages.createStaticMessage(
						loggerDealId + " - SCBNlpToWexTransformer Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return null;
	}
}
