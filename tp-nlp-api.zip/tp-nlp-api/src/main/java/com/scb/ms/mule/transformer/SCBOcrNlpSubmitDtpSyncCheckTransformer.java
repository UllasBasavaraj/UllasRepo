package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealSubStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DigitizerStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpSubmitDtpSyncCheckTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpSubmitDtpSyncCheckTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to Submit Sync check transformer calss ");
		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		Object source = null;
		String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE, EMPTY);
		String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);

		if (message != null) {
			String input = null;
			SCBCommObj commObj = null;
			switch (flowType.toUpperCase()) {
			case FlowType.SUBMIT_DTP_SYNC:
				log.info(loggerDealId + "  -  SUBMIT_DTP_SYNC Post Check Transformer.");
				try {
					source = message.getInvocationProperty(Fields.DTP_SYNC_RESPONSE_PAYLOAD);
					log.debug(loggerDealId + " source ==>" + source);
					if (source instanceof String) {
						input = (String) source;
					} else if (source instanceof InputStream) {
						input = IOUtils.toString((InputStream) source, "UTF-8");
					} else if (source instanceof SCBCommObj) {
						log.info("comm object");
						commObj = (SCBCommObj) source;
					}
					if (null != input) {
						commObj = mapper.readValue(input, SCBCommObj.class);
					}
					log.debug("commObj " + commObj.getBodySection(Sections.DTP_REQUEST_INFO));
					SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.DTP_REQUEST_INFO);
					if (null != section) {
						SCBOcrNlpDealDataObjectExtn dealDataExtobj = new SCBOcrNlpDealDataObjectExtn();
						dealDataExtobj = (SCBOcrNlpDealDataObjectExtn) SCBCommObjTransformer.sectionToSCBPojo(commObj, dealDataExtobj);
						String submitSyncStatus = message.getInvocationProperty(Fields.TP_SUB_SYNC_STATUS, EMPTY);
						String dtpSyncApplicable = message.getInvocationProperty(Fields.DTP_SYNC_APPLICABLE, EMPTY);
						
						
						if(StringUtils.isNotBlank(dtpSyncApplicable) 
								&& dtpSyncApplicable.equalsIgnoreCase(Fields.DTP_SYNC)){
							
							if(StringUtils.isNotBlank(submitSyncStatus) 
									&& submitSyncStatus.equalsIgnoreCase(DealSubStatus.SUCCESS)){
								message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.YES);
								dealDataExtobj.setStatusFlag(Fields.N);
							}else{
								message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.NO);
								dealDataExtobj.setStatusFlag(Fields.N);
								dealDataExtobj.setResponse(DigitizerStatus.TECHFAIL);
								dealDataExtobj.setDigitizerStatus(DigitizerStatus.TECHFAIL);
							}
							commObj.removeBodySection(Sections.DTP_REQUEST_INFO);
							commObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(dealDataExtobj, SCBOcrNlpDealDataObjectExtn.class));
							vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObj);
							log.debug(loggerDealId + " -  SCBOcrNlpSubmitDtpSyncCheckTransformer final json" + vppGenericJson);
						}
						else if(StringUtils.isNotBlank(dtpSyncApplicable) 
								&& dtpSyncApplicable.equalsIgnoreCase(Fields.DTP_BATCH)){
							
							message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.NO);
							dealDataExtobj.setStatusFlag(Fields.N);
							dealDataExtobj.setResponse(DigitizerStatus.BATCH);
							dealDataExtobj.setDigitizerStatus(DigitizerStatus.BATCH);
							
							commObj.removeBodySection(Sections.DTP_REQUEST_INFO);
							commObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(dealDataExtobj, SCBOcrNlpDealDataObjectExtn.class));
							vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObj);
							log.debug(loggerDealId + " - DTP_BATCH - SCBOcrNlpSubmitDtpSyncCheckTransformer final json" + vppGenericJson);
						}
						else if(StringUtils.isNotBlank(dtpSyncApplicable) 
								&& dtpSyncApplicable.equalsIgnoreCase(Fields.NOT_MAKR)){
							message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.NO);
							dealDataExtobj.setStatusFlag(Fields.N);
							dealDataExtobj.setResponse(DigitizerStatus.NOTMAKR);
							dealDataExtobj.setDigitizerStatus(DigitizerStatus.NOTMAKR);
							
							commObj.removeBodySection(Sections.DTP_REQUEST_INFO);
							commObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(dealDataExtobj, SCBOcrNlpDealDataObjectExtn.class));
							vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObj);
							log.debug(loggerDealId + " - NOT_MAKR - SCBOcrNlpSubmitDtpSyncCheckTransformer final json" + vppGenericJson);
						}
	
					}

				} catch (Exception e) {
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to perform transformation of the DTP Post Sync check level" + input),
							e);
				}
				break;

			default:
				log.info(loggerDealId + "  -  SUBMIT_DTP_SYNC No Match in the Post Sync Transformer");
			}
		}
		return vppGenericJson;
	}


}
