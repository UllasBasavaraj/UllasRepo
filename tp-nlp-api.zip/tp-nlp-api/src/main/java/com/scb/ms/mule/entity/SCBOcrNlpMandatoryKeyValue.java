package com.scb.ms.mule.entity;

public class SCBOcrNlpMandatoryKeyValue {

	private String key;
	private SCBOcrNlpKeyValue value = new SCBOcrNlpKeyValue();

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key
	 *            the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the value
	 */
	public SCBOcrNlpKeyValue getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(SCBOcrNlpKeyValue value) {
		this.value = value;
	}

}
