package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;

public class SCBOcrNlpApproveDataEntryFields {

	@Id
	private String id;
	private String dealId;
	private String productId;
	private String stepId;
	private String clientId;
	private String country;
	private String regTimestamp;
	private String systemCode;
	private List<SCBOcrNlpDataExtractionFieldsList> approvedDataEntryFieldsList = new ArrayList<SCBOcrNlpDataExtractionFieldsList>();

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the regTimestamp
	 */
	public String getRegTimestamp() {
		return regTimestamp;
	}

	/**
	 * @param regTimestamp
	 *            the regTimestamp to set
	 */
	public void setRegTimestamp(String regTimestamp) {
		this.regTimestamp = regTimestamp;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the approvedDataEntryFieldsList
	 */
	public List<SCBOcrNlpDataExtractionFieldsList> getApprovedDataEntryFieldsList() {
		return approvedDataEntryFieldsList;
	}

	/**
	 * @param approvedDataEntryFieldsList
	 *            the approvedDataEntryFieldsList to set
	 */
	public void setApprovedDataEntryFieldsList(List<SCBOcrNlpDataExtractionFieldsList> approvedDataEntryFieldsList) {
		this.approvedDataEntryFieldsList = approvedDataEntryFieldsList;
	}

}
