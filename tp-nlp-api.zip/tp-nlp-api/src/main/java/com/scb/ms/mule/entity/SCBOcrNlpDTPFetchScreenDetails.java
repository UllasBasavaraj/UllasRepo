package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpDTPFetchScreenDetails {

	private String countryCode = "";
	private String customerId = "";
	private String dealReferance = "";
	private String productCode = "";
	private String stepCode = "";
	private List<SCBOcrNlpDTPFetchPartyDetails> partyDetailsList = new ArrayList<SCBOcrNlpDTPFetchPartyDetails>();
	private List<SCBOcrNlpDTPFetchPartyDetails> partyDetails = new ArrayList<SCBOcrNlpDTPFetchPartyDetails>();

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the dealReferance
	 */
	public String getDealReferance() {
		return dealReferance;
	}

	/**
	 * @param dealReferance
	 *            the dealReferance to set
	 */
	public void setDealReferance(String dealReferance) {
		this.dealReferance = dealReferance;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode
	 *            the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the stepCode
	 */
	public String getStepCode() {
		return stepCode;
	}

	/**
	 * @param stepCode
	 *            the stepCode to set
	 */
	public void setStepCode(String stepCode) {
		this.stepCode = stepCode;
	}

	/**
	 * @return the partyDetailsList
	 */
	public List<SCBOcrNlpDTPFetchPartyDetails> getPartyDetailsList() {
		return partyDetailsList;
	}

	/**
	 * @param partyDetailsList
	 *            the partyDetailsList to set
	 */
	public void setPartyDetailsList(List<SCBOcrNlpDTPFetchPartyDetails> partyDetailsList) {
		this.partyDetailsList = partyDetailsList;
	}

	/**
	 * @return the partyDetails
	 */
	public List<SCBOcrNlpDTPFetchPartyDetails> getPartyDetails() {
		return partyDetails;
	}

	/**
	 * @param partyDetails
	 *            the partyDetails to set
	 */
	public void setPartyDetails(List<SCBOcrNlpDTPFetchPartyDetails> partyDetails) {
		this.partyDetails = partyDetails;
	}


	
}
