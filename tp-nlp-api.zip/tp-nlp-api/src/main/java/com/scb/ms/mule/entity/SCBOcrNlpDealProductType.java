package com.scb.ms.mule.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SCBOcrNlpDealProductType {

	private String dealId = "";
	private String countryCode = "";
	private String regTimeStamp = "";
	private String systemCode = "";
	private String productType = "";
	private String tdApplicationRef = "";

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the regTimeStamp
	 */
	public String getRegTimeStamp() {
		return regTimeStamp;
	}

	/**
	 * @param regTimeStamp
	 *            the regTimeStamp to set
	 */
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the productType
	 */
	public String getProductType() {
		return productType;
	}

	/**
	 * @param productType
	 *            the productType to set
	 */
	public void setProductType(String productType) {
		this.productType = productType;
	}

	/**
	 * @return the tdApplicationRef
	 */
	public String getTdApplicationRef() {
		return tdApplicationRef;
	}

	/**
	 * @param tdApplicationRef
	 *            the tdApplicationRef to set
	 */
	public void setTdApplicationRef(String tdApplicationRef) {
		this.tdApplicationRef = tdApplicationRef;
	}

}
