package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.elasticsearch.common.lang3.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpReadLayoutNLPTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpReadLayoutNLPTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBReadLayoutNLPTransformer calss ");
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			String vppGenericJson = null;
			Object genericJson = null;
			SCBCommObj commObj = null;
			Object source = message.getPayload();
			try {

				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("source instance of comm obj");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					log.debug("input request :::   ==>" + input);
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				SCBCommObj rqstObj = new SCBCommObj();
				SCBHeader scbHeader = new SCBHeader();
				SCBFooter scbFooter = new SCBFooter();
				scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.FORWARD);
				scbHeader.setModuleFunctionCode(ModuleFunctionCodes.READ_LAYOUT);
				rqstObj.setHeader(scbHeader);
				rqstObj.setFooter(scbFooter);
				try {
					SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.INITIATE_NLP_PROCESS);
					String datacapScanId = section.getStringData().get(Fields.PROCESS_ID);
					// Set the Process Data primary Key to the variable
					if (StringUtils.isNotEmpty(datacapScanId)) {
						message.setInvocationProperty(Fields.FILE_OPER_STATUS, "SUCC");
					} else {
						message.setInvocationProperty(Fields.FILE_OPER_STATUS, "FAIL");
					}
					SCBSection responseSection = new SCBSection();
					responseSection.putStringValue(Fields.DATACAP_SCANID, datacapScanId);
					rqstObj.getBody().addSection(Sections.SCB_DATACAP_SCAN, responseSection);
				} catch (Exception e) {
					e.printStackTrace();
					generateTechnicalErrorMsg(scbFooter, "400", "Invalid Request",
							"Invalid request, missing or invalid data.");
				}
				genericJson = rqstObj;
				log.debug("genericJson json ==>" + genericJson.toString());
				vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
				log.debug("intial  data from datacap  json ==>" + vppGenericJson);
				return vppGenericJson;
			} catch (Exception e) {
				throw new TransformerException(
						CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return null;
	}

	private static void generateTechnicalErrorMsg(SCBFooter scbFooter, String errorCode, String errorTitle,
			String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}

}
