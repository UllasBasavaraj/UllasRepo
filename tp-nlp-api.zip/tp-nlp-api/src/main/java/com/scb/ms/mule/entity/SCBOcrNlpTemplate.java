package com.scb.ms.mule.entity;

import org.springframework.data.annotation.Id;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpTemplate {

	@Id
	private String id;
	private String classificationType;
	private String width;
	private String height;
	private String datacapPageLocation;
	private String datacapCcoLocation;
	private String datacapLayoutXmlLocation;
	private String partyName;
	private List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList = new ArrayList<>();
	private List<SCBOcrNlpTemplateEntity> entitiesList = new ArrayList<>();
	private String dealId;
	private String documentId;
	private String pageId;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the classificationType
	 */
	public String getClassificationType() {
		return classificationType;
	}

	/**
	 * @param classificationType
	 *            the classificationType to set
	 */
	public void setClassificationType(String classificationType) {
		this.classificationType = classificationType;
	}

	/**
	 * @return the width
	 */
	public String getWidth() {
		return width;
	}

	/**
	 * @param width
	 *            the width to set
	 */
	public void setWidth(String width) {
		this.width = width;
	}

	/**
	 * @return the height
	 */
	public String getHeight() {
		return height;
	}

	/**
	 * @param height
	 *            the height to set
	 */
	public void setHeight(String height) {
		this.height = height;
	}

	/**
	 * @return the datacapPageLocation
	 */
	public String getDatacapPageLocation() {
		return datacapPageLocation;
	}

	/**
	 * @param datacapPageLocation
	 *            the datacapPageLocation to set
	 */
	public void setDatacapPageLocation(String datacapPageLocation) {
		this.datacapPageLocation = datacapPageLocation;
	}

	/**
	 * @return the datacapCcoLocation
	 */
	public String getDatacapCcoLocation() {
		return datacapCcoLocation;
	}

	/**
	 * @param datacapCcoLocation
	 *            the datacapCcoLocation to set
	 */
	public void setDatacapCcoLocation(String datacapCcoLocation) {
		this.datacapCcoLocation = datacapCcoLocation;
	}

	/**
	 * @return the datacapLayoutXmlLocation
	 */
	public String getDatacapLayoutXmlLocation() {
		return datacapLayoutXmlLocation;
	}

	/**
	 * @param datacapLayoutXmlLocation
	 *            the datacapLayoutXmlLocation to set
	 */
	public void setDatacapLayoutXmlLocation(String datacapLayoutXmlLocation) {
		this.datacapLayoutXmlLocation = datacapLayoutXmlLocation;
	}

	/**
	 * @return the partyName
	 */
	public String getPartyName() {
		return partyName;
	}

	/**
	 * @param partyName
	 *            the partyName to set
	 */
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	/**
	 * @return the matchingTemplateIdsList
	 */
	public List<SCBOcrNlpMatchingTemplateId> getMatchingTemplateIdsList() {
		return matchingTemplateIdsList;
	}

	/**
	 * @param matchingTemplateIdsList
	 *            the matchingTemplateIdsList to set
	 */
	public void setMatchingTemplateIdsList(List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList) {
		this.matchingTemplateIdsList = matchingTemplateIdsList;
	}

	/**
	 * @return the entitiesList
	 */
	public List<SCBOcrNlpTemplateEntity> getEntitiesList() {
		return entitiesList;
	}

	/**
	 * @param entitiesList
	 *            the entitiesList to set
	 */
	public void setEntitiesList(List<SCBOcrNlpTemplateEntity> entitiesList) {
		this.entitiesList = entitiesList;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * @return the pageId
	 */
	public String getPageId() {
		return pageId;
	}

	/**
	 * @param pageId the pageId to set
	 */
	public void setPageId(String pageId) {
		this.pageId = pageId;
	}

}