package com.scb.ms.mule.transformer;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.transformer.exception.SCBTransformException;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.util.SCBOcrNlpUtil;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DigitizerStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;
import org.apache.commons.lang3.StringUtils;

public class SCBOcrNlpTdStgMvmntToNLPTransformer extends AbstractMessageTransformer {

	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpTdStgMvmntToNLPTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {

		log.info("Enter in to SCBTdStgMvmntToNLPTransformer transformer calss ");

		String vppGenericJson = null;
		Object genericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		String status = "";
		String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE);
		if (message != null) {
			switch (flowType.toUpperCase()) {
			case FlowType.SUBMIT_DTP_FLOW:
				try {
					String dtprequestPayLoad = message.getInvocationProperty(Fields.DTP_REQ_PAYLOAD);
					String dtpresponsePayload = message.getInvocationProperty(Fields.DTP_RESPONSE_PAYLOAD);
					String statusMvmntResponsePayload = message.getInvocationProperty(Fields.STATUS_MVMNT_RES_PAYLOAD);
					String stageMvmntResponsePayload = message.getInvocationProperty(Fields.STAGE_MVMNT_RES_PAYLOAD);

					if (StringUtils.contains(dtprequestPayLoad, Fields.SANCTION_PARTIES_REQ)) {
						log.debug(" td response payload original : " + dtpresponsePayload);
						String dealId = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(dtprequestPayLoad),
								"$.sanctionPartiesRequest.dealReferance");
						String countryCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(dtprequestPayLoad),
								"$.sanctionPartiesRequest.countryCode");
						log.debug(" country code : " + countryCode);
						String customerId = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(dtprequestPayLoad),
								"$.sanctionPartiesRequest.customerId");
						String productCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(dtprequestPayLoad),
								"$.sanctionPartiesRequest.productCode");
						String stepCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(dtprequestPayLoad),
								"$.sanctionPartiesRequest.stepCode");

						if (StringUtils.contains(dtpresponsePayload, Fields.NAMES_SCREENING_RESPONSE)) {
							status = JsonPath.read(
									Configuration.defaultConfiguration().jsonProvider().parse(dtpresponsePayload),
									"$.namesScreeningResponse.status");
							log.debug(" DTP Status ::  " + status);
							if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
									|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {

								if (StringUtils.contains(statusMvmntResponsePayload, Fields.TD_STATUS_MVMT_RES)) {
									status = JsonPath.read(Configuration.defaultConfiguration().jsonProvider()
											.parse(dtpresponsePayload), "$.tdStatusMvmtResponse.status");
									log.debug(" TD Status Movement  Status ::  " + status);
									if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
											|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {
										if (StringUtils.contains(stageMvmntResponsePayload, Fields.TD_STAGE_MVMT_RES)) {
											status = JsonPath.read(Configuration.defaultConfiguration().jsonProvider()
													.parse(dtpresponsePayload), "$.tdStageMvmtResponse.status");
											log.debug(" TD Stage Movement  Status ::  " + status);
											if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
													|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {
												status = Fields.DSUC;
											} else {
												status = Fields.TDFL;
											}
										}
									}
								} else {
									status = Fields.TDFL;
								}
							}
						} else {
							status = Fields.TPFL;
						}

						log.debug("Final submit deal status : " + status);
						SCBCommObj rqstObj = new SCBCommObj();
						SCBHeader scbHeader = new SCBHeader();
						SCBFooter scbFooter = new SCBFooter();
						try {
							SCBOcrNlpDealDataObjectExtn scbDealExtn = new SCBOcrNlpDealDataObjectExtn();
							scbDealExtn.setDealId(dealId);
							scbDealExtn.setProductId(productCode);
							scbDealExtn.setClientId(customerId);
							scbDealExtn.setStepId(stepCode);
							scbDealExtn.setCountry(countryCode);
							scbDealExtn.setDealStatus(status);
							scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
							scbHeader.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_FINAL_DEAL_RES);
							rqstObj.setHeader(scbHeader);
							rqstObj.setFooter(scbFooter);

							rqstObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(scbDealExtn,
									SCBOcrNlpDealDataObjectExtn.class));
						} catch (SCBTransformException e) {
							e.printStackTrace();
							generateTechnicalErrorMsg(scbFooter, "400", "Invalid Request",
									"Invalid request, missing or invalid data.");
						}
						genericJson = rqstObj;
						log.debug("genericJson json ==>" + genericJson.toString());
						vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
						log.debug("SCBTDStgmvntToNLPTransformer json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					throw new TransformerException(
							CoreMessages.createStaticMessage("Unable to generate deal extn from td stamvnt response"),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_OTH_FLOW:
				try {
					String otpOthRequestPayLoad = message.getInvocationProperty(Fields.OTP_OTH_REQ_PAYLOAD);
					String otpOthResponsePayload = message.getInvocationProperty(Fields.OTP_OTH_RES_PAYLOAD);
					String statusMvmntResponsePayload = message.getInvocationProperty(Fields.STATUS_MVMNT_RES_PAYLOAD);
					String stageMvmntResponsePayload = message.getInvocationProperty(Fields.STAGE_MVMNT_RES_PAYLOAD);

					if (StringUtils.contains(otpOthRequestPayLoad, Fields.SANCTION_PARTIES_REQ)) {
						log.debug(" td response payload original : " + otpOthResponsePayload);
						String dealId = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpOthRequestPayLoad),
								"$.sanctionPartiesRequest.dealReferance");
						String countryCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpOthRequestPayLoad),
								"$.sanctionPartiesRequest.countryCode");
						log.debug(" country code : " + countryCode);
						String customerId = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpOthRequestPayLoad),
								"$.sanctionPartiesRequest.customerId");
						String productCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpOthRequestPayLoad),
								"$.sanctionPartiesRequest.productCode");
						String stepCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpOthRequestPayLoad),
								"$.sanctionPartiesRequest.stepCode");

						if (StringUtils.contains(otpOthResponsePayload, Fields.NAMES_SCREENING_RESPONSE)) {
							status = JsonPath.read(
									Configuration.defaultConfiguration().jsonProvider().parse(otpOthResponsePayload),
									"$.namesScreeningResponse.status");
							log.debug(" DTP Status ::  " + status);
							if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
									|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {

								if (StringUtils.contains(statusMvmntResponsePayload, Fields.TD_STATUS_MVMT_RES)) {
									status = JsonPath.read(Configuration.defaultConfiguration().jsonProvider()
											.parse(otpOthResponsePayload), "$.tdStatusMvmtResponse.status");
									log.debug(" TD Status Movement  Status ::  " + status);
									if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
											|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {
										if (StringUtils.contains(stageMvmntResponsePayload, Fields.TD_STAGE_MVMT_RES)) {
											status = JsonPath.read(Configuration.defaultConfiguration().jsonProvider()
													.parse(otpOthResponsePayload), "$.tdStageMvmtResponse.status");
											log.debug(" TD Stage Movement  Status ::  " + status);
											if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
													|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {
												status = Fields.DSUC;
											} else {
												status = Fields.TDFL;
											}
										}
									}
								} else {
									status = Fields.TDFL;
								}
							}
						} else {
							status = Fields.TPFL;
						}

						log.debug("Final submit deal status : " + status);
						SCBCommObj rqstObj = new SCBCommObj();
						SCBHeader scbHeader = new SCBHeader();
						SCBFooter scbFooter = new SCBFooter();
						try {
							SCBOcrNlpDealDataObjectExtn scbDealExtn = new SCBOcrNlpDealDataObjectExtn();
							scbDealExtn.setDealId(dealId);
							scbDealExtn.setProductId(productCode);
							scbDealExtn.setClientId(customerId);
							scbDealExtn.setStepId(stepCode);
							scbDealExtn.setCountry(countryCode);
							scbDealExtn.setDealStatus(status);
							scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
							scbHeader.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_FINAL_DEAL_RES);
							rqstObj.setHeader(scbHeader);
							rqstObj.setFooter(scbFooter);

							rqstObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(scbDealExtn,
									SCBOcrNlpDealDataObjectExtn.class));
						} catch (SCBTransformException e) {
							e.printStackTrace();
							generateTechnicalErrorMsg(scbFooter, "400", "Invalid Request",
									"Invalid request, missing or invalid data.");
						}
						genericJson = rqstObj;
						log.debug("genericJson json ==>" + genericJson.toString());
						vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);

						log.debug("SCBTDStgmvntToNLPTransformer json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					throw new TransformerException(
							CoreMessages.createStaticMessage("Unable to generate deal extn from td stamvnt response"),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_NEW_FLOW:
				try {
					String otpNewRequestPayLoad = message.getInvocationProperty(Fields.OTP_NEW_REQ_PAYLOAD);
					String otpNewResponsePayload = message.getInvocationProperty(Fields.OTP_NEW_RES_PAYLOAD);
					String statusMvmntResponsePayload = message.getInvocationProperty(Fields.STATUS_MVMNT_RES_PAYLOAD);
					String stageMvmntResponsePayload = message.getInvocationProperty(Fields.STAGE_MVMNT_RES_PAYLOAD);

					if (StringUtils.contains(otpNewRequestPayLoad, Fields.DOC_CREATE_REQ)) {
						log.debug("otpNewresponsePayload original : " + otpNewResponsePayload);
						String dealId = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpNewRequestPayLoad),
								"$.documentCreateRequest.dealReferance");
						String countryCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpNewRequestPayLoad),
								"$.documentCreateRequest.countryCode");
						log.debug(" country code : " + countryCode);
						String customerId = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpNewRequestPayLoad),
								"$.documentCreateRequest.customerId");
						String productCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpNewRequestPayLoad),
								"$.documentCreateRequest.productCode");
						String stepCode = JsonPath.read(
								Configuration.defaultConfiguration().jsonProvider().parse(otpNewRequestPayLoad),
								"$.documentCreateRequest.stepCode");

						if (StringUtils.contains(otpNewResponsePayload, Fields.DOC_CREATE_RES)) {
							status = JsonPath.read(
									Configuration.defaultConfiguration().jsonProvider().parse(otpNewResponsePayload),
									"$.documentCreateResponse.status");
							log.debug(" OTP New Status ::  " + status);
							if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
									|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {

								if (StringUtils.contains(statusMvmntResponsePayload, Fields.TD_STATUS_MVMT_RES)) {

									status = JsonPath.read(Configuration.defaultConfiguration().jsonProvider()
											.parse(otpNewResponsePayload), "$.tdStatusMvmtResponse.status");
									log.debug(" TD Status Movement  Status ::  " + status);
									if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
											|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {

										if (StringUtils.contains(stageMvmntResponsePayload, Fields.TD_STAGE_MVMT_RES)) {
											status = JsonPath.read(Configuration.defaultConfiguration().jsonProvider()
													.parse(otpNewResponsePayload), "$.tdStageMvmtResponse.status");
											log.debug(" TD Stage Movement  Status ::  " + status);
											if (StringUtils.equalsIgnoreCase(status, DigitizerStatus.UPDATED)
													|| StringUtils.equalsIgnoreCase(status, Fields.STATUS_SUCCESS)) {
												status = Fields.DSUC;
											} else {
												status = Fields.TDFL;
											}
										}
									}
								} else {
									status = Fields.TDFL;
								}
							}

						} else {
							status = Fields.TPFL;
						}

						log.debug("Final submit deal status : " + status);

						SCBCommObj rqstObj = new SCBCommObj();
						SCBHeader scbHeader = new SCBHeader();
						SCBFooter scbFooter = new SCBFooter();
						try {
							SCBOcrNlpDealDataObjectExtn scbDealExtn = new SCBOcrNlpDealDataObjectExtn();
							scbDealExtn.setDealId(dealId);
							scbDealExtn.setProductId(productCode);
							scbDealExtn.setClientId(customerId);
							scbDealExtn.setStepId(stepCode);
							scbDealExtn.setCountry(countryCode);
							scbDealExtn.setDealStatus(status);
							scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
							scbHeader.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_FINAL_DEAL_RES);
							rqstObj.setHeader(scbHeader);
							rqstObj.setFooter(scbFooter);

							rqstObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(scbDealExtn,
									SCBOcrNlpDealDataObjectExtn.class));
						} catch (SCBTransformException e) {
							e.printStackTrace();
							generateTechnicalErrorMsg(scbFooter, "400", "Invalid Request",
									"Invalid request, missing or invalid data.");
						}
						genericJson = rqstObj;
						log.debug("genericJson json ==>" + genericJson.toString());
						vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
						log.debug("SCBTDStgmvntToNLPTransformer json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					throw new TransformerException(
							CoreMessages.createStaticMessage("Unable to generate deal extn from td stamvnt response"),
							e);
				}
				break;
			}
		}
		return vppGenericJson;

	}

	private static void generateTechnicalErrorMsg(SCBFooter scbFooter, String errorCode, String errorTitle,
			String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}

}
