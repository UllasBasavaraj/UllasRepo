package com.scb.ms.mule.entity;

public class SCBOcrNlpOTPShipmentDetails {

	private String goodsCategory = "";
	private String goodsDesc = "";
	private String ctyOfOrigin = "";
	private String shipmentDoc = "";
	private String shipmentRefNo = "";
	private String shipmentFromCty = "";
	private String shipmentFrom = "";
	private String shipmentToCty = "";
	private String shipmentTo = "";
	private String shipmentDate = "";
	private String vesselAirlineName = "";
	private String incoterms = "";
	private String shipmentBy = "";
	private String partShipmentAllowed = "";

	/**
	 * @return the goodsCategory
	 */
	public String getGoodsCategory() {
		return goodsCategory;
	}

	/**
	 * @param goodsCategory
	 *            the goodsCategory to set
	 */
	public void setGoodsCategory(String goodsCategory) {
		this.goodsCategory = goodsCategory;
	}

	/**
	 * @return the goodsDesc
	 */
	public String getGoodsDesc() {
		return goodsDesc;
	}

	/**
	 * @param goodsDesc
	 *            the goodsDesc to set
	 */
	public void setGoodsDesc(String goodsDesc) {
		this.goodsDesc = goodsDesc;
	}

	/**
	 * @return the ctyOfOrigin
	 */
	public String getCtyOfOrigin() {
		return ctyOfOrigin;
	}

	/**
	 * @param ctyOfOrigin
	 *            the ctyOfOrigin to set
	 */
	public void setCtyOfOrigin(String ctyOfOrigin) {
		this.ctyOfOrigin = ctyOfOrigin;
	}

	/**
	 * @return the shipmentDoc
	 */
	public String getShipmentDoc() {
		return shipmentDoc;
	}

	/**
	 * @param shipmentDoc
	 *            the shipmentDoc to set
	 */
	public void setShipmentDoc(String shipmentDoc) {
		this.shipmentDoc = shipmentDoc;
	}

	/**
	 * @return the shipmentRefNo
	 */
	public String getShipmentRefNo() {
		return shipmentRefNo;
	}

	/**
	 * @param shipmentRefNo
	 *            the shipmentRefNo to set
	 */
	public void setShipmentRefNo(String shipmentRefNo) {
		this.shipmentRefNo = shipmentRefNo;
	}

	/**
	 * @return the shipmentFromCty
	 */
	public String getShipmentFromCty() {
		return shipmentFromCty;
	}

	/**
	 * @param shipmentFromCty
	 *            the shipmentFromCty to set
	 */
	public void setShipmentFromCty(String shipmentFromCty) {
		this.shipmentFromCty = shipmentFromCty;
	}

	/**
	 * @return the shipmentFrom
	 */
	public String getShipmentFrom() {
		return shipmentFrom;
	}

	/**
	 * @param shipmentFrom
	 *            the shipmentFrom to set
	 */
	public void setShipmentFrom(String shipmentFrom) {
		this.shipmentFrom = shipmentFrom;
	}

	/**
	 * @return the shipmentToCty
	 */
	public String getShipmentToCty() {
		return shipmentToCty;
	}

	/**
	 * @param shipmentToCty
	 *            the shipmentToCty to set
	 */
	public void setShipmentToCty(String shipmentToCty) {
		this.shipmentToCty = shipmentToCty;
	}

	/**
	 * @return the shipmentTo
	 */
	public String getShipmentTo() {
		return shipmentTo;
	}

	/**
	 * @param shipmentTo
	 *            the shipmentTo to set
	 */
	public void setShipmentTo(String shipmentTo) {
		this.shipmentTo = shipmentTo;
	}

	/**
	 * @return the shipmentDate
	 */
	public String getShipmentDate() {
		return shipmentDate;
	}

	/**
	 * @param shipmentDate
	 *            the shipmentDate to set
	 */
	public void setShipmentDate(String shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	/**
	 * @return the vesselAirlineName
	 */
	public String getVesselAirlineName() {
		return vesselAirlineName;
	}

	/**
	 * @param vesselAirlineName
	 *            the vesselAirlineName to set
	 */
	public void setVesselAirlineName(String vesselAirlineName) {
		this.vesselAirlineName = vesselAirlineName;
	}

	/**
	 * @return the incoterms
	 */
	public String getIncoterms() {
		return incoterms;
	}

	/**
	 * @param incoterms
	 *            the incoterms to set
	 */
	public void setIncoterms(String incoterms) {
		this.incoterms = incoterms;
	}

	/**
	 * @return the shipmentBy
	 */
	public String getShipmentBy() {
		return shipmentBy;
	}

	/**
	 * @param shipmentBy
	 *            the shipmentBy to set
	 */
	public void setShipmentBy(String shipmentBy) {
		this.shipmentBy = shipmentBy;
	}

	/**
	 * @return the partShipmentAllowed
	 */
	public String getPartShipmentAllowed() {
		return partShipmentAllowed;
	}

	/**
	 * @param partShipmentAllowed
	 *            the partShipmentAllowed to set
	 */
	public void setPartShipmentAllowed(String partShipmentAllowed) {
		this.partShipmentAllowed = partShipmentAllowed;
	}

}
