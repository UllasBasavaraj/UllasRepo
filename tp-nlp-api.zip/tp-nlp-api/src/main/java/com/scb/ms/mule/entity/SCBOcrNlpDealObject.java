package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * OCR NLP MicroService deal Object Model Structure
 * 
 * @author 1586910
 * @version 1.0.0
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class SCBOcrNlpDealObject {

	private List<SCBOcrNlpDealDataObject> dealDataList = new ArrayList<SCBOcrNlpDealDataObject>();

	/**
	 * @return the dealDataList
	 */
	public List<SCBOcrNlpDealDataObject> getDealDataList() {
		return dealDataList;
	}

	/**
	 * @param dealDataList
	 *            the dealDataList to set
	 */
	public void setDealDataList(List<SCBOcrNlpDealDataObject> dealDataList) {
		this.dealDataList = dealDataList;
	}

}
