package com.scb.ms.mule.transformer;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.core.util.SCBObjectMapper;

public class SCBOcrNlpCommObjToJsonTransformer extends AbstractTransformer {

	@Autowired
	SCBObjectMapper mapper;

	@Override
	protected String doTransform(Object src, String enc) throws TransformerException {
		String json = "";
		try {
			if (src instanceof SCBCommObj) {
				json = mapper.writer().writeValueAsString(src);
			}
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage(), e);
		}

		return json;
	}

}