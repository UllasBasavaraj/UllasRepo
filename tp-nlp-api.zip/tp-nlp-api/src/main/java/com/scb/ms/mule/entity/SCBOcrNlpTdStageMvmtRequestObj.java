package com.scb.ms.mule.entity;

public class SCBOcrNlpTdStageMvmtRequestObj {

	private String uuid = "";
	private String countryCode = "";
	private String customerId = "";
	private String dealReferance = "";
	private String productCode = "";
	private String stepCode = "";
	private String regTimeStamp = "";
	private String curTDTxnStageCode = "";
	private String regTimeMsStr = "";

	private String systemCode = "";

	/**
	 * @return the uuid
	 */
	public String getUuid() {
		return uuid;
	}

	/**
	 * @param uuid
	 *            the uuid to set
	 */
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the dealReferance
	 */
	public String getDealReferance() {
		return dealReferance;
	}

	/**
	 * @param dealReferance
	 *            the dealReferance to set
	 */
	public void setDealReferance(String dealReferance) {
		this.dealReferance = dealReferance;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode
	 *            the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the stepCode
	 */
	public String getStepCode() {
		return stepCode;
	}

	/**
	 * @param stepCode
	 *            the stepCode to set
	 */
	public void setStepCode(String stepCode) {
		this.stepCode = stepCode;
	}

	/**
	 * @return the regTimeStamp
	 */
	public String getRegTimeStamp() {
		return regTimeStamp;
	}

	/**
	 * @param regTimeStamp
	 *            the regTimeStamp to set
	 */
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}

	/**
	 * @return the curTDTxnStageCode
	 */
	public String getCurTDTxnStageCode() {
		return curTDTxnStageCode;
	}

	/**
	 * @param curTDTxnStageCode
	 *            the curTDTxnStageCode to set
	 */
	public void setCurTDTxnStageCode(String curTDTxnStageCode) {
		this.curTDTxnStageCode = curTDTxnStageCode;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the regTimeMsStr
	 */
	public String getRegTimeMsStr() {
		return regTimeMsStr;
	}

	/**
	 * @param regTimeMsStr
	 *            the regTimeMsStr to set
	 */
	public void setRegTimeMsStr(String regTimeMsStr) {
		this.regTimeMsStr = regTimeMsStr;
	}

}
