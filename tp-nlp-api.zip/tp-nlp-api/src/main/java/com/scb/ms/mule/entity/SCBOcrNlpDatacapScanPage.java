package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpDatacapScanPage {

	private String pageNumber;
	List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList = new ArrayList<SCBOcrNlpMatchingTemplateId>();
	private String docClsTyp;
	private String docClsMthd;
	private String layoutXml;
	private String pagelocation;
	private String ccolocation;
	private String layoutxmllocation;

	/**
	 * @return the pageNumber
	 */
	public String getPageNumber() {
		return pageNumber;
	}

	/**
	 * @param pageNumber
	 *            the pageNumber to set
	 */
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}

	/**
	 * @return the matchingTemplateIdsList
	 */
	public List<SCBOcrNlpMatchingTemplateId> getMatchingTemplateIdsList() {
		return matchingTemplateIdsList;
	}

	/**
	 * @param matchingTemplateIdsList
	 *            the matchingTemplateIdsList to set
	 */
	public void setMatchingTemplateIdsList(List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList) {
		this.matchingTemplateIdsList = matchingTemplateIdsList;
	}

	/**
	 * @return the docClsTyp
	 */
	public String getDocClsTyp() {
		return docClsTyp;
	}

	/**
	 * @param docClsTyp
	 *            the docClsTyp to set
	 */
	public void setDocClsTyp(String docClsTyp) {
		this.docClsTyp = docClsTyp;
	}

	/**
	 * @return the docClsMthd
	 */
	public String getDocClsMthd() {
		return docClsMthd;
	}

	/**
	 * @param docClsMthd
	 *            the docClsMthd to set
	 */
	public void setDocClsMthd(String docClsMthd) {
		this.docClsMthd = docClsMthd;
	}

	/**
	 * @return the layoutXml
	 */
	public String getLayoutXml() {
		return layoutXml;
	}

	/**
	 * @param layoutXml
	 *            the layoutXml to set
	 */
	public void setLayoutXml(String layoutXml) {
		this.layoutXml = layoutXml;
	}

	/**
	 * @return the pagelocation
	 */
	public String getPagelocation() {
		return pagelocation;
	}

	/**
	 * @param pagelocation
	 *            the pagelocation to set
	 */
	public void setPagelocation(String pagelocation) {
		this.pagelocation = pagelocation;
	}

	/**
	 * @return the ccolocation
	 */
	public String getCcolocation() {
		return ccolocation;
	}

	/**
	 * @param ccolocation
	 *            the ccolocation to set
	 */
	public void setCcolocation(String ccolocation) {
		this.ccolocation = ccolocation;
	}

	/**
	 * @return the layoutxmllocation
	 */
	public String getLayoutxmllocation() {
		return layoutxmllocation;
	}

	/**
	 * @param layoutxmllocation
	 *            the layoutxmllocation to set
	 */
	public void setLayoutxmllocation(String layoutxmllocation) {
		this.layoutxmllocation = layoutxmllocation;
	}

}
