package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpProcessedTemplateFeedbackPage {

	private String templateReqId;
	private List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList = new ArrayList<>();

	/**
	 * @return the templateReqId
	 */
	public String getTemplateReqId() {
		return templateReqId;
	}

	/**
	 * @param templateReqId
	 *            the templateReqId to set
	 */
	public void setTemplateReqId(String templateReqId) {
		this.templateReqId = templateReqId;
	}

	/**
	 * @return the matchingTemplateIdsList
	 */
	public List<SCBOcrNlpMatchingTemplateId> getMatchingTemplateIdsList() {
		return matchingTemplateIdsList;
	}

	/**
	 * @param matchingTemplateIdsList
	 *            the matchingTemplateIdsList to set
	 */
	public void setMatchingTemplateIdsList(List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList) {
		this.matchingTemplateIdsList = matchingTemplateIdsList;
	}

}
