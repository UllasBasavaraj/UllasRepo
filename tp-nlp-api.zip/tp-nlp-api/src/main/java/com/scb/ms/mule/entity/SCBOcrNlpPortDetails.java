package com.scb.ms.mule.entity;

public class SCBOcrNlpPortDetails {

	private String loadingUNLocationCode = "";
	private String loading = "";
	private String loadingCountry = "";
	private String dischargeUNLocationCode = "";
	private String discharge = "";
	private String dischargeCountry = "";

	/**
	 * @return the loadingUNLocationCode
	 */
	public String getLoadingUNLocationCode() {
		return loadingUNLocationCode;
	}

	/**
	 * @param loadingUNLocationCode
	 *            the loadingUNLocationCode to set
	 */
	public void setLoadingUNLocationCode(String loadingUNLocationCode) {
		this.loadingUNLocationCode = loadingUNLocationCode;
	}

	/**
	 * @return the loading
	 */
	public String getLoading() {
		return loading;
	}

	/**
	 * @param loading
	 *            the loading to set
	 */
	public void setLoading(String loading) {
		this.loading = loading;
	}

	/**
	 * @return the loadingCountry
	 */
	public String getLoadingCountry() {
		return loadingCountry;
	}

	/**
	 * @param loadingCountry
	 *            the loadingCountry to set
	 */
	public void setLoadingCountry(String loadingCountry) {
		this.loadingCountry = loadingCountry;
	}

	/**
	 * @return the dischargeUNLocationCode
	 */
	public String getDischargeUNLocationCode() {
		return dischargeUNLocationCode;
	}

	/**
	 * @param dischargeUNLocationCode
	 *            the dischargeUNLocationCode to set
	 */
	public void setDischargeUNLocationCode(String dischargeUNLocationCode) {
		this.dischargeUNLocationCode = dischargeUNLocationCode;
	}

	/**
	 * @return the discharge
	 */
	public String getDischarge() {
		return discharge;
	}

	/**
	 * @param discharge
	 *            the discharge to set
	 */
	public void setDischarge(String discharge) {
		this.discharge = discharge;
	}

	/**
	 * @return the dischargeCountry
	 */
	public String getDischargeCountry() {
		return dischargeCountry;
	}

	/**
	 * @param dischargeCountry
	 *            the dischargeCountry to set
	 */
	public void setDischargeCountry(String dischargeCountry) {
		this.dischargeCountry = dischargeCountry;
	}

}
