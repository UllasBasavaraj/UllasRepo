package com.scb.ms.mule.transformer;

import java.io.IOException;

import org.apache.commons.lang.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewTxnUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpTdStageMvmtRequest;
import com.scb.ms.mule.entity.SCBOcrNlpTdStageMvmtRequestObj;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.HighLightTypes;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpTDStageMvmntTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpTDStageMvmntTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to TD Stage Movement transformer calss ");
		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE, EMPTY);
		String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);
		if (message != null) {

			switch (flowType.toUpperCase()) {
			case FlowType.SUBMIT_DTP_FLOW:
				log.debug(loggerDealId + "  -  SUBMIT_DTP_FLOW SCB Stage movement transformer...");
				String dtpRequestPayLoad = EMPTY;
				try {
					dtpRequestPayLoad = message.getInvocationProperty(Fields.DTP_REQ_PAYLOAD);
					String dataEntryApplicable = message.getInvocationProperty(Fields.DATA_ENTRY_APPLICABLE);
					if (StringUtils.contains(dtpRequestPayLoad, Fields.SANCTION_PARTIES_REQ) || StringUtils.equals(Fields.Y, dataEntryApplicable)) {
						vppGenericJson = getStageMvmtJsonForDTPOrOTPOth(mapper, loggerDealId, dtpRequestPayLoad,
								message);
						log.debug(loggerDealId + " -  DTP Submit SCB Stage movement  Request  json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to generate deal extn from td stamvnt response" + dtpRequestPayLoad),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_OTH_FLOW:
				log.debug(loggerDealId + " -  OTP OTHRS Stage mvmnt transformer....");
				String otpRequestPayLoad = EMPTY;
				try {
					otpRequestPayLoad = message.getInvocationProperty(Fields.OTP_OTH_REQ_PAYLOAD);
					if (StringUtils.contains(otpRequestPayLoad, Fields.SANCTION_PARTIES_REQ)) {
						vppGenericJson = getStageMvmtJsonForDTPOrOTPOth(mapper, loggerDealId, otpRequestPayLoad,
								message);
						log.debug(loggerDealId + " -  SCB Stage movement  Request  json" + vppGenericJson);

					}
				} catch (JsonProcessingException e) {
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to generate deal extn from td stamvnt response" + otpRequestPayLoad),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_NEW_FLOW:
				String otpNewRequestPayLoad = null;
				log.debug(loggerDealId + " -  Submit OTP New Stage mvmnt transformer....");
				try {
					otpNewRequestPayLoad = message.getInvocationProperty(Fields.OTP_NEW_REQ_PAYLOAD);
					if (StringUtils.contains(otpNewRequestPayLoad, Fields.DOC_CREATE_REQ)) {
						vppGenericJson = getStageMvmtJsonForOTPNew(mapper, loggerDealId, otpNewRequestPayLoad, message);

						log.debug(loggerDealId + " -  OTP NEW SCB Stage movement  Request  json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					throw new TransformerException(CoreMessages.createStaticMessage(
							loggerDealId + " -  Unable to generate deal extn from td stamvnt response for OTP NEW "
									+ otpNewRequestPayLoad),
							e);
				}
				break;

			case FlowType.FORWARD_FLOW:
				try {
					vppGenericJson = getStageMvmtJsonForForwardFlow(message, mapper, loggerDealId);

					log.debug(loggerDealId + " - SCBStage movement Forward flow Request  json" + vppGenericJson);
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SCBStage movement forward Request" + e);
					throw new TransformerException(CoreMessages.createStaticMessage(
							loggerDealId + " - Unable to generate deal extn from td stamvnt response"), e);
				}
				break;
			}
		}
		return vppGenericJson;
	}

	private String getStageMvmtJsonForForwardFlow(MuleMessage message, ObjectMapper mapper, String loggerDealId)
			throws JsonProcessingException {
		String dealId = message.getInvocationProperty(Fields.DEAL_ID);
		String countryCode = message.getInvocationProperty(HighLightTypes.COUNTRY);
		String customerId = message.getInvocationProperty(Fields.CUSTOMER_ID);
		String productId = message.getInvocationProperty(Fields.PRODUCT_ID);
		String stepId = message.getInvocationProperty(Fields.STEP_ID);
		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		String systemCode = message.getInvocationProperty(Fields.SYSTEM_CODE);
		String tdTxnStageCode = message.getInvocationProperty(Fields.TD_TXN_STAGE_CODE);
		String regTimeMsStr = message.getInvocationProperty(Fields.REG_TIME_MS_STR);

		SCBOcrNlpTdStageMvmtRequestObj stageMvmntReqObj = new SCBOcrNlpTdStageMvmtRequestObj();
		if (StringUtils.isBlank(tdTxnStageCode)) {
			// if elastic not send set to 41
			tdTxnStageCode = "41";
		}
		log.debug(loggerDealId + " -  set and send to TD - txn stage code : in forward flow  " + tdTxnStageCode);
		stageMvmntReqObj.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
		stageMvmntReqObj.setSystemCode(systemCode);
		stageMvmntReqObj.setCountryCode(countryCode);
		stageMvmntReqObj.setCustomerId(customerId);
		stageMvmntReqObj.setDealReferance(dealId);
		stageMvmntReqObj.setProductCode(productId);
		stageMvmntReqObj.setStepCode(stepId);
		stageMvmntReqObj.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(regTimeStamp));
		stageMvmntReqObj.setCurTDTxnStageCode(tdTxnStageCode);
		stageMvmntReqObj.setRegTimeMsStr(regTimeMsStr);

		SCBOcrNlpTdStageMvmtRequest tdStageMvmntReq = new SCBOcrNlpTdStageMvmtRequest();
		tdStageMvmntReq.setTdStageMvmtRequest(stageMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStageMvmntReq);
		return vppGenericJson;
	}

	private String getStageMvmtJsonForOTPNew(ObjectMapper mapper, String loggerDealId, String otpRequestPayLoad,
			MuleMessage message) throws JsonProcessingException {

		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		String curTDTxnStageCode = message.getInvocationProperty(Fields.CUR_TD_TXN_STAGECODE);
		String regTimeMsStr = message.getInvocationProperty(Fields.REG_TIME_MS_STR);
		SCBOcrNlpTdStageMvmtRequestObj stageMvmntReqObj = new SCBOcrNlpTdStageMvmtRequestObj();
		if (StringUtils.isBlank(curTDTxnStageCode)) {
			// if elastic not send set to 40
			curTDTxnStageCode = "40";
		}
		log.debug(loggerDealId + " -   set snd send TD - txn stage code : in submit otp new  " + curTDTxnStageCode);
		SCBOcrNlpOTPNewUpdateReq dealdeInfo = getDealBasicInfo(otpRequestPayLoad);
		stageMvmntReqObj.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
		stageMvmntReqObj.setSystemCode(dealdeInfo.getSourceSystem());
		stageMvmntReqObj.setCountryCode(dealdeInfo.getCountryCode());
		stageMvmntReqObj.setCustomerId(dealdeInfo.getCustomerId());
		stageMvmntReqObj.setDealReferance(dealdeInfo.getDealReferance());
		stageMvmntReqObj.setProductCode(dealdeInfo.getProductCode());
		stageMvmntReqObj.setStepCode(dealdeInfo.getStepCode());
		stageMvmntReqObj.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(regTimeStamp));
		stageMvmntReqObj.setCurTDTxnStageCode(curTDTxnStageCode);
		stageMvmntReqObj.setRegTimeMsStr(regTimeMsStr);

		SCBOcrNlpTdStageMvmtRequest tdStageMvmntReq = new SCBOcrNlpTdStageMvmtRequest();
		tdStageMvmntReq.setTdStageMvmtRequest(stageMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStageMvmntReq);
		return vppGenericJson;
	}

	private String getStageMvmtJsonForDTPOrOTPOth(ObjectMapper mapper, String loggerDealId, String dtpRequestPayLoad,
			MuleMessage message) throws JsonProcessingException {

		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		String curTDTxnStageCode = message.getInvocationProperty(Fields.CUR_TD_TXN_STAGECODE);
		String regTimeMsStr = message.getInvocationProperty(Fields.REG_TIME_MS_STR);

		SCBOcrNlpTdStageMvmtRequestObj stageMvmntReqObj = new SCBOcrNlpTdStageMvmtRequestObj();
		if (StringUtils.isBlank(curTDTxnStageCode)) {
			// if elastic not send set to 40
			curTDTxnStageCode = "40";
		}
		log.debug(loggerDealId + " -   set and send to TD - txn stage code : in submit DTP  " + curTDTxnStageCode);
		
		stageMvmntReqObj.setUuid(Fields.OCR_NLP + SCBOcrNlpUtil.getCurrDate());
		stageMvmntReqObj.setSystemCode(message.getInvocationProperty(Fields.SYSTEM_CODE));
		stageMvmntReqObj.setCountryCode(message.getInvocationProperty(Fields.COUNTRY_CODE));
		stageMvmntReqObj.setCustomerId(message.getInvocationProperty(Fields.CUSTOMER_ID));
		stageMvmntReqObj.setDealReferance(message.getInvocationProperty(Fields.DEAL_ID));
		stageMvmntReqObj.setProductCode(message.getInvocationProperty(Fields.PRODUCT_ID));
		stageMvmntReqObj.setStepCode(message.getInvocationProperty(Fields.STEP_ID));
		stageMvmntReqObj.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(regTimeStamp));
		stageMvmntReqObj.setCurTDTxnStageCode(curTDTxnStageCode);
		stageMvmntReqObj.setRegTimeMsStr(regTimeMsStr);

		SCBOcrNlpTdStageMvmtRequest tdStageMvmntReq = new SCBOcrNlpTdStageMvmtRequest();
		tdStageMvmntReq.setTdStageMvmtRequest(stageMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStageMvmntReq);
		return vppGenericJson;
	}

/*	private SCBOcrNlpNamesScreeningRequest getSanctionParties(String dtpRequestPayLoad) {
		SCBOcrNlpNamesScreeningRequest sanctionPartiesRequest = null;
		try {
			SCBOcrNlpNamesScreeningListRequest sanctionPartiesList = new ObjectMapper().readValue(dtpRequestPayLoad,
					SCBOcrNlpNamesScreeningListRequest.class);
			sanctionPartiesRequest = sanctionPartiesList.getSanctionPartiesRequest();
		} catch (IOException e) {
			log.error(dtpRequestPayLoad + " - Exception in getSanctionParties Request" + e);
		}
		return sanctionPartiesRequest;
	}*/

	private SCBOcrNlpOTPNewUpdateReq getDealBasicInfo(String otpNewRequestPayLoad) {
		SCBOcrNlpOTPNewTxnUpdateReq otpNewReq = null;
		SCBOcrNlpOTPNewUpdateReq docCreateRequest = null;
		try {
			otpNewReq = new ObjectMapper().readValue(otpNewRequestPayLoad, SCBOcrNlpOTPNewTxnUpdateReq.class);
			docCreateRequest = otpNewReq.getDocCreateRequest();
		} catch (IOException e) {
			log.error(otpNewRequestPayLoad + " - Exception in getDealBasicInfo Request for OTP New" + e);
		}
		return docCreateRequest;
	}
}
