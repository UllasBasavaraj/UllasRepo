package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealProductType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpProductTypeTransformer extends AbstractMessageTransformer {

	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpProductTypeTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBNLPProductTypeTransformer transformer calss ");

		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		Object source = null;
		String input = null;
		SCBCommObj commObj = null;
		if (message != null) {
			try {
				source = message.getPayload();
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}

				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.DEAL_PRODUCT_TYPE);
				SCBOcrNlpDealProductType productType = new SCBOcrNlpDealProductType();
				if (null != section) {
					productType = (SCBOcrNlpDealProductType) SCBCommObjTransformer.sectionToSCBPojo(commObj,
							productType);
				}
				vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(productType);
				log.debug("SCBNLPProductTypeTransformer Response  json" + vppGenericJson);

			} catch (Exception e) {
				throw new TransformerException(
						CoreMessages.createStaticMessage("Unable to generate product Type from Response" + source), e);
			}
		}
		return vppGenericJson;
	}
}
