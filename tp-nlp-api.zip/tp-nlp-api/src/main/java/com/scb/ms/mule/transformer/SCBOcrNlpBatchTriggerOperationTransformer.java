package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.datatypes.SCBDataTable;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealObject;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpBatchTriggerOperationTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpBatchTriggerOperationTransformer.class);
	private static String dealDataList = "dealDataList";
	private static String countryStr = "country";
	private static String dealIdStr = "dealId";
	private static String stepIdStr = "stepId";
	private static String tdApplicationReferenceIdStr = "tdApplicationReferenceId";
	private static String clientIdStr = "clientId";
	private static String productIdStr = "productId";
	private static String sysStatusStr = "sysStatus";
	private static String regTimeStampStr = "regTimeStamp";
	private static String dealReleasedStatus = "dealReleasedStatus";

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBOcrNlpBatchTriggerOperationTransformer calss ");
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object source = message.getPayload();
			SCBCommObj commObj = null;
			try {
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.DEAL_OBJECT));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.DEAL_OBJECT);

				if (null != section) {

					SCBDataTable tableData = section.getTableData().get(dealDataList);

					if (CollectionUtils.isNotEmpty(tableData.getRowData())) {
						message.setInvocationProperty(Fields.BATCH_PAGE_COUNTER, tableData.getRowData().size());
					} else {
						message.setInvocationProperty(Fields.BATCH_PAGE_COUNTER, 0);
					}

				} else {
					log.info("No Deals available in Batch window ");
					message.setInvocationProperty(Fields.BATCH_PAGE_COUNTER, 0);
				}

			} catch (Exception e) {
				log.error("error in SCBOcrNlpBatchTriggerTransformer" + e);
				throw new TransformerException(
						CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return null;
	}

}
