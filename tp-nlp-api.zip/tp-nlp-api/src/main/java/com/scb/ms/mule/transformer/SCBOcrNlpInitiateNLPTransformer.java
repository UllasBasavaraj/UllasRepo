package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpDataObj;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpInitiateNLPTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpInitiateNLPTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBInitiateNLPTransformer calss ");
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			String vppGenericJson = null;
			Object genericJson = null;
			String loggerDealId = "";
			Object source = message.getPayload();
			try {
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				}

				SCBCommObj rqstObj = new SCBCommObj();
				SCBHeader scbHeader = new SCBHeader();
				SCBFooter scbFooter = new SCBFooter();
				scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.FORWARD);
				rqstObj.setHeader(scbHeader);
				rqstObj.setFooter(scbFooter);
				try {
					SCBOcrNlpDataObj ocrReqObj = mapper.readValue(input, SCBOcrNlpDataObj.class);
					loggerDealId = ocrReqObj.getDealId();
					message.setInvocationProperty(Fields.LOGGER_DEAL_ID, loggerDealId);

					rqstObj.getBody()
							.addSection(SCBCommObjTransformer.pojoToSection(ocrReqObj, SCBOcrNlpDataObj.class));
				} catch (Exception e) {
					e.printStackTrace();
					generateTechnicalErrorMsg(scbFooter, "400", "Invalid Request",
							"Invalid request, missing or invalid data.");
				}

				genericJson = rqstObj;
				log.debug(loggerDealId + " - genericJson json ==>" + genericJson.toString());
				vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);

				return vppGenericJson;
			} catch (Exception e) {
				log.error(loggerDealId + " - error in Datacap Input Json Transformation" + e);
				throw new TransformerException(
						CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return null;
	}

	private static void generateTechnicalErrorMsg(SCBFooter scbFooter, String errorCode, String errorTitle,
			String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}

}
