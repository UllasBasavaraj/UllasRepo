package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.JsonNodeType;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.transformer.exception.SCBTransformException;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpDTPFetchPartyDetails;
import com.scb.ms.mule.entity.SCBOcrNlpDTPFetchScreenDetails;
import com.scb.ms.mule.entity.SCBOcrNlpUpdateFinalDeal;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DTPFetchFields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpDTPPartiesToNLPTransformer extends AbstractMessageTransformer {

	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpDTPPartiesToNLPTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to DTP Parties Fetch transformer calss ");

		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		SCBOcrNlpDTPFetchScreenDetails returnFetchDetails = null;
		Object source = null;
		if (message != null) {
			String payload = "";
			String forwardTpCallStatus = message.getInvocationProperty(Fields.TP_FF_STATUS);
			String submitTpSyncStatus = message.getInvocationProperty(Fields.TP_SUB_SYNC_STATUS);
			String loggerDealId = message.getInvocationProperty(Fields.DEAL_ID);
			

			try {
				source = message.getPayload();
				log.debug(loggerDealId + " SCBOcrNlpDTPPartiesToNLPTransformer source ==>" + source);
				if (source instanceof String) {
					payload = (String) source;
				} else if (source instanceof InputStream) {
					payload = IOUtils.toString((InputStream) source, "UTF-8");
				} else {
					log.info(loggerDealId + " Undefined Input Source");
				}
				
				if (payload.toString().contains(Fields.ERRORS)) {
					JsonNode topNode = mapper.readTree(payload).findPath(Fields.ERRORS);
					if(topNode.getNodeType().equals(JsonNodeType.ARRAY)){
						JsonNode innerNode = topNode.get(0);
						if(innerNode.get(Fields.STATUS).asText().equalsIgnoreCase(SCBOcrNlpMuleConstants.NO_RECORD_FOUND_CODE)){
							log.info( loggerDealId +" Creating the request for 404 Entry");
							SCBCommObj request = createDTPOldPartiesSection(message, forwardTpCallStatus,submitTpSyncStatus, null, true);
							// create JSON string
							vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
							log.debug(loggerDealId +" DTP Parties Fetch ==> " + vppGenericJson);
						}
					}
				}
				else if (payload.toString().contains(Fields.SCREEN_NAMES)) {
					JsonNode topNode = mapper.readTree(payload).findPath(Fields.SCREEN_NAMES);
					log.info(loggerDealId +" Creating the request");
					returnFetchDetails = new SCBOcrNlpDTPFetchScreenDetails();
					if(StringUtils.isNotBlank(topNode.findPath(DTPFetchFields.COUNTRY_CODE).toString())){
						returnFetchDetails.setCountryCode(topNode.findPath(DTPFetchFields.COUNTRY_CODE).toString().trim().replaceAll("^\"+|\"+$", ""));
					}
					if(StringUtils.isNotBlank(topNode.findPath(DTPFetchFields.CUSTOMER_ID).toString())){
						returnFetchDetails.setCustomerId(topNode.findPath(DTPFetchFields.CUSTOMER_ID).toString().trim().replaceAll("^\"+|\"+$", ""));
					}
					if(StringUtils.isNotBlank(topNode.findPath(DTPFetchFields.DEAL_REFERANCE).toString())){
						returnFetchDetails.setDealReferance(topNode.findPath(DTPFetchFields.DEAL_REFERANCE).toString().trim().replaceAll("^\"+|\"+$", ""));
					}
					if(StringUtils.isNotBlank(topNode.findPath(DTPFetchFields.PRODUCT_CODE).toString())){
						returnFetchDetails.setProductCode(topNode.findPath(DTPFetchFields.PRODUCT_CODE).toString().trim().replaceAll("^\"+|\"+$", ""));
					}
					if(StringUtils.isNotBlank(topNode.findPath(DTPFetchFields.STEP_CODE).toString())){
						returnFetchDetails.setStepCode(topNode.findPath(DTPFetchFields.STEP_CODE).toString().trim().replaceAll("^\"+|\"+$", ""));
					}
					
					JsonNode nextNode = topNode.findPath(DTPFetchFields.PARTY_DETAILS_LIST);
					if(null != nextNode && nextNode.getNodeType().equals(JsonNodeType.ARRAY)){
						for(int i=0 ; i < nextNode.size() ; i++){
							SCBOcrNlpDTPFetchPartyDetails partyDetails = new SCBOcrNlpDTPFetchPartyDetails();
							JsonNode innerNode = nextNode.get(i);
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_ROLE).toString())){
								partyDetails.setPartyRole(innerNode.findPath(DTPFetchFields.PARTY_ROLE).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_NAME).toString())){
								partyDetails.setPartyName(innerNode.findPath(DTPFetchFields.PARTY_NAME).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_ID).toString())){
								partyDetails.setPartyId(innerNode.findPath(DTPFetchFields.PARTY_ID).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_EXTN_ID).toString())){
								partyDetails.setPartyExtId(innerNode.findPath(DTPFetchFields.PARTY_EXTN_ID).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_ADDRESS1).toString())){
								partyDetails.setAddress1(innerNode.findPath(DTPFetchFields.PARTY_ADDRESS1).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_ADDRESS2).toString())){
								partyDetails.setAddress2(innerNode.findPath(DTPFetchFields.PARTY_ADDRESS2).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_ADDRESS3).toString())){
								partyDetails.setAddress3(innerNode.findPath(DTPFetchFields.PARTY_ADDRESS3).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_COUNTRY).toString())){
								partyDetails.setAddCtyCode(innerNode.findPath(DTPFetchFields.PARTY_COUNTRY).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_DOC_NUMBER).toString())){
								partyDetails.setDocNumber(innerNode.findPath(DTPFetchFields.PARTY_DOC_NUMBER).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_CREATED_STEP).toString())){
								partyDetails.setCreatedStep(innerNode.findPath(DTPFetchFields.PARTY_CREATED_STEP).toString().replaceAll("^\"+|\"+$", ""));
							}
							if(StringUtils.isNotBlank(innerNode.findPath(DTPFetchFields.PARTY_OP_CODE).toString())){
								partyDetails.setOpCode(innerNode.findPath(DTPFetchFields.PARTY_OP_CODE).toString().replaceAll("^\"+|\"+$", ""));
							}
							
							returnFetchDetails.getPartyDetailsList().add(partyDetails);
						}
					}
					
					SCBCommObj request = createDTPOldPartiesSection(message, forwardTpCallStatus,submitTpSyncStatus, returnFetchDetails, true);
					// create JSON string
					vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
					log.debug(loggerDealId + " DTP Parties Fetch ==> " + vppGenericJson);

				} else {
					log.info(loggerDealId + " Creating the Failed request");
					SCBCommObj request = createDTPOldPartiesSection(message, forwardTpCallStatus,submitTpSyncStatus, null, false);

					// create JSON string
					vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(request);
					log.debug(loggerDealId + " DTP Parties Fetch ==> " + vppGenericJson);
				}
			} catch (Exception e) {
				throw new TransformerException(
						CoreMessages.createStaticMessage(loggerDealId +" Unable to generate dtp fetch response " + payload), e);
			}
		}
		return vppGenericJson;
	}

	private SCBCommObj createDTPOldPartiesSection(MuleMessage message, String forwardTpCallStatus,String submitTpSyncStatus,
			SCBOcrNlpDTPFetchScreenDetails fetchParty, boolean flag) throws SCBTransformException {
		String tpForwardFlowStartTime = message.getInvocationProperty(Fields.TP_FF_ST);
		String tpForwardFlowEndTime = message.getInvocationProperty(Fields.TP_FF_ET);
		String logDealId = message.getInvocationProperty(Fields.DEAL_ID);
		String logCountryCode = message.getInvocationProperty(Fields.COUNTRY_CODE);
		String logRegTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		String tdApplicationReferenceId = message.getInvocationProperty(Fields.TD_APP_REF_ID);
		String customerId = message.getInvocationProperty(Fields.CUSTOMER_ID);
		String productId = message.getInvocationProperty(Fields.PRODUCT_ID);
		String stepId = message.getInvocationProperty(Fields.STEP_ID);
		String logFlowType = message.getInvocationProperty(FlowType.FLOW_TYPE);
		if(null == fetchParty){
			fetchParty = new SCBOcrNlpDTPFetchScreenDetails();
			fetchParty.setCountryCode(logCountryCode);
			fetchParty.setCustomerId(customerId);
			fetchParty.setDealReferance(logDealId);
			fetchParty.setProductCode(productId);
		}
		SCBCommObj commObj = new SCBCommObj();
		SCBHeader requestHeader = SCBOcrNlpUtil.createSCBDTPFetchHeaderObject(ModuleCodes.FORWARD);
		SCBFooter requestFooter = new SCBFooter();
		commObj.setHeader(requestHeader);
		commObj.setFooter(requestFooter);
		if (flag) {
			commObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(fetchParty, SCBOcrNlpDTPFetchScreenDetails.class));
		}
		SCBOcrNlpUpdateFinalDeal finalDeal = new SCBOcrNlpUpdateFinalDeal();
		finalDeal.setForwardTpCallStatus(forwardTpCallStatus);
		finalDeal.setSubmitTpSyncStatus(submitTpSyncStatus);
		finalDeal.setTpForwardFlowStartTime(tpForwardFlowStartTime);
		finalDeal.setTpForwardFlowEndTime(tpForwardFlowEndTime);
		finalDeal.setLogDealId(logDealId);
		finalDeal.setLogCountryCode(logCountryCode);
		finalDeal.setLogRegTimeStamp(logRegTimeStamp);
		finalDeal.setLogTdApplicationReferenceId(tdApplicationReferenceId);
		finalDeal.setStepId(stepId);
		finalDeal.setLogFlowType(logFlowType);
		commObj.getBody()
		.addSection(SCBCommObjTransformer.pojoToSection(finalDeal, SCBOcrNlpUpdateFinalDeal.class));
		return commObj;
	}
}
