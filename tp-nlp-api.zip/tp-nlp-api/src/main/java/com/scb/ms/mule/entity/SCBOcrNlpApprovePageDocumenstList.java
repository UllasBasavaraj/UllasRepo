package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;

public class SCBOcrNlpApprovePageDocumenstList {
	
	@Id
	private String id;
	private String filenetDocumentId;
	private List<SCBOcrNlpApprovePageDocumentPagesList> documentApprovePagesList = new ArrayList<SCBOcrNlpApprovePageDocumentPagesList>();
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFilenetDocumentId() {
		return filenetDocumentId;
	}
	public void setFilenetDocumentId(String filenetDocumentId) {
		this.filenetDocumentId = filenetDocumentId;
	}
	public List<SCBOcrNlpApprovePageDocumentPagesList> getDocumentApprovePagesList() {
		return documentApprovePagesList;
	}
	public void setDocumentApprovePagesList(List<SCBOcrNlpApprovePageDocumentPagesList> documentApprovePagesList) {
		this.documentApprovePagesList = documentApprovePagesList;
	}
	
	
	

}
