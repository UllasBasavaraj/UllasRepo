package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;


public class SCBOcrNlpDocumentPagesList {

	@Id
	private String id;
	private String screenable;
	private String pageNumber;
	private String pageOrder;
	private String pageSet = "";
	private String oldPageSet = "";
	private String duplicateOf = "";
	private boolean duplicate = false; 
	@Transient
	List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList = new ArrayList<SCBOcrNlpMatchingTemplateId>();
	private String dealClsTp;
	private String dealClsMtd;
	private String oldDealClsTp;
	private String clsConfidence = "";
	private String clsStatus = "";
	private boolean approved;
	// private String approved;
	@Transient
	private String width;
	@Transient
	private String height;
	@Transient
	private String layoutXmlExtractedText = "";
	@Transient
	private String templateExtractedText;
	private String datacapTemplateCategoryMetadata;
	private String datacapPageLocation;
	private String datacapCcoLocation;
	private String datacapLayoutXmlLocation;

	@Transient
	private List<SCBOcrNlpNameCaptureList> nameCaptureList = new ArrayList<SCBOcrNlpNameCaptureList>();
	@Transient
	private List<SCBOcrNlpTextCoordinatesList> textCoordinatesList = new ArrayList<SCBOcrNlpTextCoordinatesList>();
	@Transient
	private int pageCharacterPosition;

	private String image;
	private int rescanDocNum;
	private int totalPageTime;
	@Transient
	private String deReRun = "";
	private int scanOrder;
	@Transient
	private List<Integer> printAreaCoords = new ArrayList<Integer>();

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the screenable
	 */
	public String getScreenable() {
		return screenable;
	}

	/**
	 * @param screenable
	 *            the screenable to set
	 */
	public void setScreenable(String screenable) {
		this.screenable = screenable;
	}

	/**
	 * @return the pageNumber
	 */
	public String getPageNumber() {
		return pageNumber;
	}

	/**
	 * @param pageNumber
	 *            the pageNumber to set
	 */
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}

	/**
	 * @return the pageOrder
	 */
	public String getPageOrder() {
		return pageOrder;
	}

	/**
	 * @param pageOrder
	 *            the pageOrder to set
	 */
	public void setPageOrder(String pageOrder) {
		this.pageOrder = pageOrder;
	}

	/**
	 * @return the pageSet
	 */
	public String getPageSet() {
		return pageSet;
	}

	/**
	 * @param pageSet
	 *            the pageSet to set
	 */
	public void setPageSet(String pageSet) {
		this.pageSet = pageSet;
	}

	/**
	 * @return the oldPageSet
	 */
	public String getOldPageSet() {
		return oldPageSet;
	}

	/**
	 * @param oldPageSet
	 *            the oldPageSet to set
	 */
	public void setOldPageSet(String oldPageSet) {
		this.oldPageSet = oldPageSet;
	}

	/**
	 * @return the duplicateOf
	 */
	public String getDuplicateOf() {
		return duplicateOf;
	}

	/**
	 * @param duplicateOf
	 *            the duplicateOf to set
	 */
	public void setDuplicateOf(String duplicateOf) {
		this.duplicateOf = duplicateOf;
	}
	
	

	/**
	 * @return the duplicate
	 */
	public boolean getDuplicate() {
		return duplicate;
	}

	/**
	 * @param duplicate the duplicate to set
	 */
	public void setDuplicate(boolean duplicate) {
		this.duplicate = duplicate;
	}

	/**
	 * @return the matchingTemplateIdsList
	 */
	public List<SCBOcrNlpMatchingTemplateId> getMatchingTemplateIdsList() {
		return matchingTemplateIdsList;
	}

	/**
	 * @param matchingTemplateIdsList
	 *            the matchingTemplateIdsList to set
	 */
	public void setMatchingTemplateIdsList(List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList) {
		this.matchingTemplateIdsList = matchingTemplateIdsList;
	}

	/**
	 * @return the dealClsTp
	 */
	public String getDealClsTp() {
		return dealClsTp;
	}

	/**
	 * @param dealClsTp
	 *            the dealClsTp to set
	 */
	public void setDealClsTp(String dealClsTp) {
		this.dealClsTp = dealClsTp;
	}

	/**
	 * @return the dealClsMtd
	 */
	public String getDealClsMtd() {
		return dealClsMtd;
	}

	/**
	 * @return the oldDealClsTp
	 */
	public String getOldDealClsTp() {
		return oldDealClsTp;
	}

	/**
	 * @param oldDealClsTp
	 *            the oldDealClsTp to set
	 */
	public void setOldDealClsTp(String oldDealClsTp) {
		this.oldDealClsTp = oldDealClsTp;
	}

	/**
	 * @param dealClsMtd
	 *            the dealClsMtd to set
	 */
	public void setDealClsMtd(String dealClsMtd) {
		this.dealClsMtd = dealClsMtd;
	}

	/**
	 * @return the clsConfidence
	 */
	public String getClsConfidence() {
		return clsConfidence;
	}

	/**
	 * @param clsConfidence
	 *            the clsConfidence to set
	 */
	public void setClsConfidence(String clsConfidence) {
		this.clsConfidence = clsConfidence;
	}

	/**
	 * @return the clsStatus
	 */
	public String getClsStatus() {
		return clsStatus;
	}

	/**
	 * @param clsStatus
	 *            the clsStatus to set
	 */
	public void setClsStatus(String clsStatus) {
		this.clsStatus = clsStatus;
	}

	/**
	 * @return the approved
	 */
	public boolean getApproved() {
		return approved;
	}

	/**
	 * @param approved
	 *            the approved to set
	 */
	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	/**
	 * @return the width
	 */
	public String getWidth() {
		return width;
	}

	/**
	 * @param width
	 *            the width to set
	 */
	public void setWidth(String width) {
		this.width = width;
	}

	/**
	 * @return the height
	 */
	public String getHeight() {
		return height;
	}

	/**
	 * @param height
	 *            the height to set
	 */
	public void setHeight(String height) {
		this.height = height;
	}

	/**
	 * @return the layoutXmlExtractedText
	 */
	public String getLayoutXmlExtractedText() {
		return layoutXmlExtractedText;
	}

	/**
	 * @param layoutXmlExtractedText
	 *            the layoutXmlExtractedText to set
	 */
	public void setLayoutXmlExtractedText(String layoutXmlExtractedText) {
		this.layoutXmlExtractedText = layoutXmlExtractedText;
	}

	/**
	 * @return the templateExtractedText
	 */
	public String getTemplateExtractedText() {
		return templateExtractedText;
	}

	/**
	 * @param templateExtractedText
	 *            the templateExtractedText to set
	 */
	public void setTemplateExtractedText(String templateExtractedText) {
		this.templateExtractedText = templateExtractedText;
	}

	/**
	 * @return the datacapTemplateCategoryMetadata
	 */
	public String getDatacapTemplateCategoryMetadata() {
		return datacapTemplateCategoryMetadata;
	}

	/**
	 * @param datacapTemplateCategoryMetadata
	 *            the datacapTemplateCategoryMetadata to set
	 */
	public void setDatacapTemplateCategoryMetadata(String datacapTemplateCategoryMetadata) {
		this.datacapTemplateCategoryMetadata = datacapTemplateCategoryMetadata;
	}

	/**
	 * @return the datacapPageLocation
	 */
	public String getDatacapPageLocation() {
		return datacapPageLocation;
	}

	/**
	 * @param datacapPageLocation
	 *            the datacapPageLocation to set
	 */
	public void setDatacapPageLocation(String datacapPageLocation) {
		this.datacapPageLocation = datacapPageLocation;
	}

	/**
	 * @return the datacapCcoLocation
	 */
	public String getDatacapCcoLocation() {
		return datacapCcoLocation;
	}

	/**
	 * @param datacapCcoLocation
	 *            the datacapCcoLocation to set
	 */
	public void setDatacapCcoLocation(String datacapCcoLocation) {
		this.datacapCcoLocation = datacapCcoLocation;
	}

	/**
	 * @return the datacapLayoutXmlLocation
	 */
	public String getDatacapLayoutXmlLocation() {
		return datacapLayoutXmlLocation;
	}

	/**
	 * @param datacapLayoutXmlLocation
	 *            the datacapLayoutXmlLocation to set
	 */
	public void setDatacapLayoutXmlLocation(String datacapLayoutXmlLocation) {
		this.datacapLayoutXmlLocation = datacapLayoutXmlLocation;
	}

	/**
	 * @return the nameCaptureList
	 */
	public List<SCBOcrNlpNameCaptureList> getNameCaptureList() {
		return nameCaptureList;
	}

	/**
	 * @param nameCaptureList
	 *            the nameCaptureList to set
	 */
	public void setNameCaptureList(List<SCBOcrNlpNameCaptureList> nameCaptureList) {
		this.nameCaptureList = nameCaptureList;
	}

	/**
	 * @return the textCoordinatesList
	 */
	public List<SCBOcrNlpTextCoordinatesList> getTextCoordinatesList() {
		return textCoordinatesList;
	}

	/**
	 * @param textCoordinatesList
	 *            the textCoordinatesList to set
	 */
	public void setTextCoordinatesList(List<SCBOcrNlpTextCoordinatesList> textCoordinatesList) {
		this.textCoordinatesList = textCoordinatesList;
	}

	/**
	 * @return the pageCharacterPosition
	 */
	public int getPageCharacterPosition() {
		return pageCharacterPosition;
	}

	/**
	 * @param pageCharacterPosition
	 *            the pageCharacterPosition to set
	 */
	public void setPageCharacterPosition(int pageCharacterPosition) {
		this.pageCharacterPosition = pageCharacterPosition;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}

	/**
	 * @return the rescanDocNum
	 */
	public int getRescanDocNum() {
		return rescanDocNum;
	}

	/**
	 * @param rescanDocNum
	 *            the rescanDocNum to set
	 */
	public void setRescanDocNum(int rescanDocNum) {
		this.rescanDocNum = rescanDocNum;
	}

	/**
	 * @return the totalPageTime
	 */
	public int getTotalPageTime() {
		return totalPageTime;
	}

	/**
	 * @param totalPageTime
	 *            the totalPageTime to set
	 */
	public void setTotalPageTime(int totalPageTime) {
		this.totalPageTime = totalPageTime;
	}

	/**
	 * @return the deReRun
	 */
	public String getDeReRun() {
		return deReRun;
	}

	/**
	 * @param deReRun the deReRun to set
	 */
	public void setDeReRun(String deReRun) {
		this.deReRun = deReRun;
	}

   /**
	 * @return the scanOrder
	 */
	public int getScanOrder() {
		return scanOrder;
	}

	/**
	 * @param scanOrder
	 *            the scanOrder to set
	 */
	public void setScanOrder(int scanOrder) {
		this.scanOrder = scanOrder;
	}

	/**
	 * @return the printAreaCoords
	 */
	public List<Integer> getPrintAreaCoords() {
		return printAreaCoords;
	}

	/**
	 * @param printAreaCoords the printAreaCoords to set
	 */
	public void setPrintAreaCoords(List<Integer> printAreaCoords) {
		this.printAreaCoords = printAreaCoords;
	}

}
