package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpDataEntryFieldsDetails {

	private String requestorReferenceId = "";
	private String requestorSystemCode = "OCR";
	private String requestorCustomerId = "";
	private String countryCode = "";
	private String branchCode = "";
	private String customerId = "";
	private String customerName = "";
	private String customerReferenceNo = "";
	private String dealReferenceNo = "";
	private String productCode = "";
	private String stepCode = "";
	private String transactionLogId = "";
	private SCBOcrNlpDTPGeneralDetails generalDetails = new SCBOcrNlpDTPGeneralDetails();
	private List<SCBOcrNlpDTPShipmentDetails> shipmentDetails = new ArrayList<SCBOcrNlpDTPShipmentDetails>();
	private List<SCBOcrNlpDTPPartyDetails> partyDetails = new ArrayList<SCBOcrNlpDTPPartyDetails>();
	private List<SCBOcrNlpCollectionInstructions> collectionInstructions = new ArrayList<SCBOcrNlpCollectionInstructions>();

	/**
	 * @return the requestorReferenceId
	 */
	public String getRequestorReferenceId() {
		return requestorReferenceId;
	}

	/**
	 * @param requestorReferenceId
	 *            the requestorReferenceId to set
	 */
	public void setRequestorReferenceId(String requestorReferenceId) {
		this.requestorReferenceId = requestorReferenceId;
	}

	/**
	 * @return the requestorSystemCode
	 */
	public String getRequestorSystemCode() {
		return requestorSystemCode;
	}

	/**
	 * @param requestorSystemCode
	 *            the requestorSystemCode to set
	 */
	public void setRequestorSystemCode(String requestorSystemCode) {
		this.requestorSystemCode = requestorSystemCode;
	}

	/**
	 * @return the requestorCustomerId
	 */
	public String getRequestorCustomerId() {
		return requestorCustomerId;
	}

	/**
	 * @param requestorCustomerId
	 *            the requestorCustomerId to set
	 */
	public void setRequestorCustomerId(String requestorCustomerId) {
		this.requestorCustomerId = requestorCustomerId;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode
	 *            the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * @param customerId
	 *            the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName
	 *            the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	/**
	 * @return the customerReferenceNo
	 */
	public String getCustomerReferenceNo() {
		return customerReferenceNo;
	}

	/**
	 * @param customerReferenceNo
	 *            the customerReferenceNo to set
	 */
	public void setCustomerReferenceNo(String customerReferenceNo) {
		this.customerReferenceNo = customerReferenceNo;
	}

	/**
	 * @return the dealReferenceNo
	 */
	public String getDealReferenceNo() {
		return dealReferenceNo;
	}

	/**
	 * @param dealReferenceNo
	 *            the dealReferenceNo to set
	 */
	public void setDealReferenceNo(String dealReferenceNo) {
		this.dealReferenceNo = dealReferenceNo;
	}

	/**
	 * @return the productCode
	 */
	public String getProductCode() {
		return productCode;
	}

	/**
	 * @param productCode
	 *            the productCode to set
	 */
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/**
	 * @return the stepCode
	 */
	public String getStepCode() {
		return stepCode;
	}

	/**
	 * @param stepCode
	 *            the stepCode to set
	 */
	public void setStepCode(String stepCode) {
		this.stepCode = stepCode;
	}

	/**
	 * @return the transactionLogId
	 */
	public String getTransactionLogId() {
		return transactionLogId;
	}

	/**
	 * @param transactionLogId
	 *            the transactionLogId to set
	 */
	public void setTransactionLogId(String transactionLogId) {
		this.transactionLogId = transactionLogId;
	}

	/**
	 * @return the generalDetails
	 */
	public SCBOcrNlpDTPGeneralDetails getGeneralDetails() {
		return generalDetails;
	}

	/**
	 * @param generalDetails
	 *            the generalDetails to set
	 */
	public void setGeneralDetails(SCBOcrNlpDTPGeneralDetails generalDetails) {
		this.generalDetails = generalDetails;
	}

	/**
	 * @return the shipmentDetails
	 */
	public List<SCBOcrNlpDTPShipmentDetails> getShipmentDetails() {
		return shipmentDetails;
	}

	/**
	 * @param shipmentDetails
	 *            the shipmentDetails to set
	 */
	public void setShipmentDetails(List<SCBOcrNlpDTPShipmentDetails> shipmentDetails) {
		this.shipmentDetails = shipmentDetails;
	}

	/**
	 * @return the partyDetails
	 */
	public List<SCBOcrNlpDTPPartyDetails> getPartyDetails() {
		return partyDetails;
	}

	/**
	 * @param partyDetails
	 *            the partyDetails to set
	 */
	public void setPartyDetails(List<SCBOcrNlpDTPPartyDetails> partyDetails) {
		this.partyDetails = partyDetails;
	}

	/**
	 * @return the collectionInstructions
	 */
	public List<SCBOcrNlpCollectionInstructions> getCollectionInstructions() {
		return collectionInstructions;
	}

	/**
	 * @param collectionInstructions
	 *            the collectionInstructions to set
	 */
	public void setCollectionInstructions(List<SCBOcrNlpCollectionInstructions> collectionInstructions) {
		this.collectionInstructions = collectionInstructions;
	}

}
