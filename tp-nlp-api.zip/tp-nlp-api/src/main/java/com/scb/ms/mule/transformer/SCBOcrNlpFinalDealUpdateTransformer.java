package com.scb.ms.mule.transformer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.transformer.exception.SCBTransformException;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpDTPFetchPartyDetails;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.entity.SCBOcrNlpNamesScreeningListRequest;
import com.scb.ms.mule.entity.SCBOcrNlpNamesScreeningRequest;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewTxnUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpUpdateFinalDeal;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealSubStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpFinalDealUpdateTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpFinalDealUpdateTransformer.class);
	private  final String partyRole = "partyRole";
	private  final String partyName = "partyName";
	private  final String createdStep = "createdStep";
	private  final String dprStatus = "dprStatus";
	private  final String namesScreeningResponse = "namesScreeningResponse";
	private  final String partyDetails = "partyDetails";

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBFinalDealUpdateTransformer transformer calss ");
		String vppGenericJson = null;
		if (message != null) {
			String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE);
			String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID);
			ObjectMapper mapper = new ObjectMapper();
			switch (StringUtils.upperCase(flowType)) {
			case FlowType.FORWARD_FLOW:
				try {
					vppGenericJson = getForwardFlowJson(message, mapper, loggerDealId);
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in FORWARD Final Request" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to generate deal extn from td SCBFinalDealUpdateTransformer response"),
							e);
				}
				break;
				
			case FlowType.FORWARD_DTP_BATCH_FLOW:
				try {
					vppGenericJson = getDtpBatchForwardFlowJson(message, mapper, loggerDealId);
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in FORWARD DTP BATCH Final Request" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to generate deal extn from td SCBFinalDealUpdateTransformer response"),
							e);
				}
				break;
				
			case FlowType.SUBMIT_DTP_FLOW:
				try {
					String dtprequestPayLoad = message.getInvocationProperty(Fields.DTP_REQ_PAYLOAD);
					String dataEntryApplicable = message.getInvocationProperty(Fields.DATA_ENTRY_APPLICABLE);
					String dtpresponsePayLoad = message.getInvocationProperty(Fields.DTP_RESPONSE_PAYLOAD);
					if (StringUtils.contains(dtprequestPayLoad, Fields.SANCTION_PARTIES_REQ) || StringUtils.equals(Fields.Y, dataEntryApplicable)) {
						vppGenericJson = getGenericJson(message, mapper, loggerDealId, dtprequestPayLoad,dtpresponsePayLoad, false);
					}
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SUBMIT-DTP Final Request" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to generate deal extn from td SCBFinalDealUpdateTransformer response"),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_OTH_FLOW:
				try {
					String otpOthRequestPayLoad = message.getInvocationProperty(Fields.OTP_OTH_REQ_PAYLOAD);
					String otpOthResponsePayLoad = message.getInvocationProperty(Fields.OTP_OTH_RES_PAYLOAD);
					
					if (otpOthRequestPayLoad.toString().contains(Fields.SANCTION_PARTIES_REQ)) {
						vppGenericJson = getGenericJson(message, mapper, loggerDealId, otpOthRequestPayLoad,otpOthResponsePayLoad, false);
					}

				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SUBMIT-OTP-OTH Final Request" + e);
					throw new TransformerException(CoreMessages.createStaticMessage(
							"Unable to generate deal extn from td SCBFinalDealUpdateTransformer response"), e);
				}
				break;

			case FlowType.SUBMIT_OTP_NEW_FLOW:
				try {
					String otpNewRequestPayLoad = message.getInvocationProperty(Fields.OTP_NEW_REQ_PAYLOAD);
					if (StringUtils.contains(otpNewRequestPayLoad, Fields.DOC_CREATE_REQ)) {
						vppGenericJson = getGenericJson(message, mapper, loggerDealId, otpNewRequestPayLoad,null, true);
					}

				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SUBMIT-OTP-NEW Final Request" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " -  Unable to generate deal extn from td SCBFinalDealUpdateTransformer response"),
							e);
				}
				break;
			}
		}
		return vppGenericJson;
	}

	private String getGenericJson(MuleMessage message, ObjectMapper mapper, String loggerDealId, String requestPayLoad,String responsePayLoad,
			boolean isFromOtpNew) throws JsonProcessingException {

		SCBCommObj rqstObj = new SCBCommObj();
		SCBHeader scbHeader = new SCBHeader();
		SCBFooter scbFooter = new SCBFooter();
		try {
			SCBOcrNlpDealDataObjectExtn scbDealExtn = new SCBOcrNlpDealDataObjectExtn();
			String dealId;
			String productCode;
			String customerId;
			String stepCode;
			String countryCode;
			String systemCode = message.getInvocationProperty(Fields.SYSTEM_CODE);
			String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
			String dealFinalStatus = message.getInvocationProperty(Fields.DEAL_FINAL_SUBMIT_STATUS);
			String tdAppRefId = message.getInvocationProperty(Fields.TD_APP_REF_ID);
			String productId = message.getInvocationProperty(Fields.PRODUCT_ID);
			if (!isFromOtpNew) {
				//SCBOcrNlpNamesScreeningRequest sanctionParties = getSanctionParties(requestPayLoad);
				//dealId = sanctionParties.getDealReferance();
				//productCode = sanctionParties.getProductCode();
				//customerId = sanctionParties.getCustomerId();
				//stepCode = sanctionParties.getStepCode();
				//countryCode = sanctionParties.getCountryCode();*/
				dealId = message.getInvocationProperty(Fields.DEAL_Id);
				productCode = message.getInvocationProperty(Fields.PRODUCT_ID);
				customerId = message.getInvocationProperty(Fields.CUSTOMER_ID);
				stepCode = message.getInvocationProperty(Fields.STEP_ID);
				countryCode = message.getInvocationProperty(Fields.COUNTRY_CODE);
				//regTimeStamp = SCBOcrNlpUtil.getWTPRGTimeStamp(regTimeStamp);
			} else {
				SCBOcrNlpOTPNewUpdateReq dealInfo = getDealBasicInfo(requestPayLoad);
				dealId = dealInfo.getDealReferance();
				productCode = dealInfo.getProductCode();
				customerId = dealInfo.getCustomerId();
				stepCode = dealInfo.getStepCode();
				countryCode = dealInfo.getCountryCode();
				regTimeStamp = SCBOcrNlpUtil.getWTPRGTimeStamp(dealInfo.getRegTimeStamp());
			}

			scbDealExtn.setDealId(dealId);
			scbDealExtn.setProductId(productId);
			scbDealExtn.setClientId(customerId);
			scbDealExtn.setStepId(stepCode);
			scbDealExtn.setCountry(countryCode);
			scbDealExtn.setRegTimeStamp(regTimeStamp);
			scbDealExtn.setDealStatus(dealFinalStatus);
			scbDealExtn.setSystemCode(systemCode);
			scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
			scbHeader.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_FINAL_DEAL_RES);
			rqstObj.setHeader(scbHeader);
			rqstObj.setFooter(scbFooter);

			rqstObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(scbDealExtn, SCBOcrNlpDealDataObjectExtn.class));
			
			SCBOcrNlpUpdateFinalDeal finalDeal = new SCBOcrNlpUpdateFinalDeal();
			finalDeal.setSubmitTpCallStatus(message.getInvocationProperty(Fields.TP_SUB_CALL_STATUS));
			finalDeal.setSubmitTdStatusCallStatus(message.getInvocationProperty(Fields.TD_SUB_STATUS_CALL_STATUS));
			finalDeal.setSubmitTdStageCallStatus(message.getInvocationProperty(Fields.TD_SUB_STAGE_CALL_STATUS));
			finalDeal.setTpSubmitFlowStartTime(message.getInvocationProperty(Fields.TP_SUB_ST));
			finalDeal.setTpSubmitFlowEndTime(message.getInvocationProperty(Fields.TP_SUB_ET));
			finalDeal.setTdSubmitFlowStartTime(message.getInvocationProperty(Fields.TD_SUB_ST));
			finalDeal.setTdSubmitFlowEndTime(message.getInvocationProperty(Fields.TD_SUB_ET));
			finalDeal.setLogDealId(dealId);
			finalDeal.setLogCountryCode(countryCode);
			finalDeal.setProductId(productId);
			finalDeal.setClientId(customerId);
			finalDeal.setLogRegTimeStamp(regTimeStamp);
			finalDeal.setLogTdApplicationReferenceId(tdAppRefId);
			finalDeal.setLogFlowType(FlowType.SUBMIT);
			finalDeal.setDigitizerStatus(message.getInvocationProperty(Fields.DIGITIZER_STATUS));

			
			if (!isFromOtpNew) {
				finalDeal.setPartyDetailsList(getDTPOTPOthersPartyWiseStatus(responsePayLoad,dealId));
			}
			
			rqstObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(finalDeal, SCBOcrNlpUpdateFinalDeal.class));
			
		} catch (SCBTransformException e) {
			e.printStackTrace();
			generateTechnicalErrorMsg(scbFooter, "400", "Invalid Request", "Invalid request, missing or invalid data.");
		}

		Object genericJson = rqstObj;
		log.debug(loggerDealId + " -  genericJson json ==>" + genericJson.toString());
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
		log.debug(loggerDealId + " -  SCBFinalDealUpdateTransformer json" + vppGenericJson);
		return vppGenericJson;
	}

	private String getForwardFlowJson(MuleMessage message, ObjectMapper mapper, String loggerDealId)
			throws JsonProcessingException {
		String vppGenericJson = null;
		String dealId = message.getInvocationProperty(Fields.DEAL_ID);
		String countryCode = message.getInvocationProperty(Fields.COUNTRY_CODE);
		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		String tdApplicationReferenceId = message.getInvocationProperty(Fields.TD_APP_REF_ID);
		String systemCode = message.getInvocationProperty(Fields.SYSTEM_CODE);
		String dtpBatchWindow = message.getInvocationProperty(Fields.DTP_BATCH_WINDOW);
		String stepId = message.getInvocationProperty(Fields.STEP_ID);
		String forwardTpCallStatus = message.getInvocationProperty(Fields.TP_FF_STATUS);


		SCBCommObj rqstObj = new SCBCommObj();
		SCBHeader header = new SCBHeader();
		SCBFooter footer = new SCBFooter();
		try {
			SCBOcrNlpDealDataObjectExtn dealExtn = new SCBOcrNlpDealDataObjectExtn();
			dealExtn.setDealId(dealId);
			dealExtn.setProductId(message.getInvocationProperty(Fields.PRODUCT_ID));
			dealExtn.setClientId(message.getInvocationProperty(Fields.CUSTOMER_ID));
			dealExtn.setStepId(stepId);
			dealExtn.setCountry(countryCode);
			dealExtn.setRegTimeStamp(regTimeStamp);
			dealExtn.setSystemCode(systemCode);
			// ISS Step even though its Batch window will be updated as FSUCC
			// Other than ISS steps require to be blocked
			if(StringUtils.isNotEmpty(forwardTpCallStatus)
					&& forwardTpCallStatus.equalsIgnoreCase(DealSubStatus.BATCH)){
				dealExtn.setDealStatus(DealStatus.FORWARD_DTP_BATCH_WINDOW);
			}else if(StringUtils.isNotEmpty(forwardTpCallStatus)
					&& forwardTpCallStatus.equalsIgnoreCase(DealSubStatus.FAILED)){
				dealExtn.setDealStatus(DealStatus.FORWARD_FAILED);
			}else{
				dealExtn.setDealStatus(DealStatus.FORWARD_SUCCESSFUL);
			}

			header = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
			header.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_FINAL_DEAL_RES);
			rqstObj.setHeader(header);
			rqstObj.setFooter(footer);

			rqstObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(dealExtn, SCBOcrNlpDealDataObjectExtn.class));
			
			SCBOcrNlpUpdateFinalDeal finalDeal = new SCBOcrNlpUpdateFinalDeal();
			finalDeal.setWexCallStatus(message.getInvocationProperty(Fields.WEXCALL_STATUS));
			finalDeal.setWexTemplateCallStatus(message.getInvocationProperty(Fields.WEX_TEMPLATE_CALL_STATUS));
			finalDeal.setForwardTdStatusCallStatus(message.getInvocationProperty(Fields.TD_FF_STATUS_CALL));
			finalDeal.setForwardTdStageCallStatus(message.getInvocationProperty(Fields.TD_FF_STAGE_STATUS));
			finalDeal.setForwardTpCallStatus(forwardTpCallStatus);
			finalDeal.setTdForwardFlowStartTime(message.getInvocationProperty(Fields.TD_FF_ST));
			finalDeal.setTdForwardFlowEndTime(message.getInvocationProperty(Fields.TD_FF_ET));
			finalDeal.setTpForwardFlowStartTime(message.getInvocationProperty(Fields.TP_FF_ST,SCBOcrNlpMuleConstants.EMPTY_STRING));
			finalDeal.setTpForwardFlowEndTime(message.getInvocationProperty(Fields.TP_FF_ET,SCBOcrNlpMuleConstants.EMPTY_STRING));
			finalDeal.setLogDealId(dealId);
			finalDeal.setLogCountryCode(countryCode);
			finalDeal.setClientId(message.getInvocationProperty(Fields.CUSTOMER_ID));
			finalDeal.setStepId(message.getInvocationProperty(Fields.STEP_ID));
			finalDeal.setProductId(message.getInvocationProperty(Fields.PRODUCT_ID));
			finalDeal.setLogRegTimeStamp(regTimeStamp);
			finalDeal.setLogTdApplicationReferenceId(tdApplicationReferenceId);
			finalDeal.setLogFlowType(Fields.TD_FORWARD);
			finalDeal.setDigitizerStatus(message.getInvocationProperty(Fields.DIGITIZER_STATUS));
			rqstObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(finalDeal, SCBOcrNlpUpdateFinalDeal.class));
			Object genericJson = rqstObj;
			log.debug(loggerDealId + " -  genericJson json ==>" + genericJson.toString());
			vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
			log.debug(loggerDealId + " -  SCBFinalDealUpdateTransformer json" + vppGenericJson);
		} catch (SCBTransformException e) {
			e.printStackTrace();
			generateTechnicalErrorMsg(footer, "400", "Invalid Request", "Invalid request, missing or invalid data.");
		}
		return vppGenericJson;
	}

	private String getDtpBatchForwardFlowJson(MuleMessage message, ObjectMapper mapper, String loggerDealId)
			throws JsonProcessingException {
		String vppGenericJson = null;
		String dealId = message.getInvocationProperty(Fields.DEAL_ID);
		String countryCode = message.getInvocationProperty(Fields.COUNTRY_CODE);
		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		String tdApplicationReferenceId = message.getInvocationProperty(Fields.TD_APP_REF_ID);
		String forwardTpCallStatus = message.getInvocationProperty(Fields.TP_FF_STATUS);

		SCBCommObj rqstObj = new SCBCommObj();
		SCBHeader header = new SCBHeader();
		SCBFooter footer = new SCBFooter();
		try {
			SCBOcrNlpDealDataObjectExtn dealExtn = new SCBOcrNlpDealDataObjectExtn();
			dealExtn.setDealId(dealId);
			dealExtn.setProductId(message.getInvocationProperty(Fields.PRODUCT_ID));
			dealExtn.setClientId(message.getInvocationProperty(Fields.CUSTOMER_ID));
			dealExtn.setStepId(message.getInvocationProperty(Fields.STEP_ID));
			dealExtn.setCountry(countryCode);
			dealExtn.setRegTimeStamp(regTimeStamp);
			dealExtn.setSystemCode(Fields.DTP_SYSTEM);
			if(StringUtils.isNotEmpty(forwardTpCallStatus)
					&& forwardTpCallStatus.equalsIgnoreCase(DealSubStatus.FAILED)){
				dealExtn.setDealStatus(DealStatus.FORWARD_FAILED);
			}else{
				dealExtn.setDealStatus(DealStatus.FORWARD_SUCCESSFUL);
			}
			header = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
			header.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_FINAL_DEAL_RES);
			rqstObj.setHeader(header);
			rqstObj.setFooter(footer);

			rqstObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(dealExtn, SCBOcrNlpDealDataObjectExtn.class));
			
			SCBOcrNlpUpdateFinalDeal finalDeal = new SCBOcrNlpUpdateFinalDeal();
			finalDeal.setForwardTpCallStatus(forwardTpCallStatus);
			finalDeal.setTdForwardFlowStartTime(message.getInvocationProperty(Fields.TD_FF_ST));
			finalDeal.setTdForwardFlowEndTime(message.getInvocationProperty(Fields.TD_FF_ET));
			finalDeal.setLogDealId(dealId);
			finalDeal.setLogCountryCode(countryCode);
			finalDeal.setClientId(message.getInvocationProperty(Fields.CUSTOMER_ID));
			finalDeal.setStepId(message.getInvocationProperty(Fields.STEP_ID));
			finalDeal.setProductId(message.getInvocationProperty(Fields.PRODUCT_ID));
			finalDeal.setLogRegTimeStamp(regTimeStamp);
			finalDeal.setLogTdApplicationReferenceId(tdApplicationReferenceId);
			finalDeal.setLogFlowType(Fields.TP_FORWARD);
			rqstObj.getBody()
					.addSection(SCBCommObjTransformer.pojoToSection(finalDeal, SCBOcrNlpUpdateFinalDeal.class));
			Object genericJson = rqstObj;
			log.debug(loggerDealId + " -  genericJson json ==>" + genericJson.toString());
			vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
			log.debug(loggerDealId + " -  SCBFinalDealUpdateTransformer json" + vppGenericJson);
		} catch (SCBTransformException e) {
			e.printStackTrace();
			generateTechnicalErrorMsg(footer, "400", "Invalid Request", "Invalid request, missing or invalid data.");
		}
		return vppGenericJson;
	}
	
	private SCBOcrNlpOTPNewUpdateReq getDealBasicInfo(String otpNewRequestPayLoad) {
		SCBOcrNlpOTPNewTxnUpdateReq otpNewReq = null;
		SCBOcrNlpOTPNewUpdateReq docCreateRequest = null;
		try {
			otpNewReq = new ObjectMapper().readValue(otpNewRequestPayLoad, SCBOcrNlpOTPNewTxnUpdateReq.class);
			docCreateRequest = otpNewReq.getDocCreateRequest();
		} catch (IOException e) {
			log.error(otpNewRequestPayLoad + " - Exception in getDealBasicInfo Request for OTP New" + e);
		}
		return docCreateRequest;
	}

	private SCBOcrNlpNamesScreeningRequest getSanctionParties(String dtpRequestPayLoad) {
		SCBOcrNlpNamesScreeningRequest sanctionPartiesRequest = null;
		try {
			SCBOcrNlpNamesScreeningListRequest sanctionPartiesList = new ObjectMapper().readValue(dtpRequestPayLoad,
					SCBOcrNlpNamesScreeningListRequest.class);
			sanctionPartiesRequest = sanctionPartiesList.getSanctionPartiesRequest();
		} catch (IOException e) {
			log.error(dtpRequestPayLoad + " - Exception in getSanctionParties Request" + e);
		}
		return sanctionPartiesRequest;
	}

	private static void generateTechnicalErrorMsg(SCBFooter scbFooter, String errorCode, String errorTitle,
			String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}
	
	private List<SCBOcrNlpDTPFetchPartyDetails> getDTPOTPOthersPartyWiseStatus(String responsePayload, String loggerDealId ) {
		List<SCBOcrNlpDTPFetchPartyDetails> partyDetailsList = new ArrayList<SCBOcrNlpDTPFetchPartyDetails>();
		try {
			if (StringUtils.contains(responsePayload, Fields.NAMES_SCREENING_RESPONSE)) {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode partyList = mapper.readTree(responsePayload).findPath(namesScreeningResponse).findPath(partyDetails);
				if (!partyList.isMissingNode() && partyList.isArray()) {
					for (int i = 0; i < partyList.size(); i++) {
						JsonNode element = partyList.get(i);
						SCBOcrNlpDTPFetchPartyDetails partyDetails = new SCBOcrNlpDTPFetchPartyDetails();
						String role = element.findPath(partyRole).toString();
						if (StringUtils.isNotEmpty(role)) {
							role = role.replaceAll("^\"+|\"+$", "");
						}
						String name = element.findPath(partyName).toString();
						if (StringUtils.isNotEmpty(name)) {
							name = name.replaceAll("^\"+|\"+$", "");
						}
						String step = element.findPath(createdStep).toString();
						if (StringUtils.isNotEmpty(step)) {
							step = step.replaceAll("^\"+|\"+$", "");
						}
						String status = element.findPath(dprStatus).toString();
						if (StringUtils.isNotEmpty(status)) {
							status = status.replaceAll("^\"+|\"+$", "");
						}
							
						partyDetails.setPartyRole(role);
						partyDetails.setPartyName(name);
						partyDetails.setCreatedStep(step);
						partyDetails.setRoleStatus(status);
						partyDetailsList.add(partyDetails);
					}
				}
			}
		} catch (IOException e) {
			log.error(loggerDealId + " Exception in getDTPOTPOthersPartyWiseStatus Response computation" + e);
		}
		return partyDetailsList;
	}

}
