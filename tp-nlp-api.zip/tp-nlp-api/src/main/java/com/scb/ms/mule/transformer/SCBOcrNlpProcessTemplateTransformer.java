package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpProcessTemplateTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpProcessTemplateTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Starting SCBOcrNlpProcessTemplateTransformer class");
		String jsonResponse = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			byte[] input = null;
			Object genericJson = null;
			Object src = null;
			String loggerDealId = EMPTY;
			SCBCommObj commObj = null;
			try {
				src = message.getPayload();
				loggerDealId = message.getInvocationProperty("loggerDealId", EMPTY);
				log.debug(loggerDealId + " - source ==>" + src);
				if (src instanceof String) {
					log.info(loggerDealId + " - source instance of String");
					input = ((String) src).getBytes();
				} else if (src instanceof InputStream) {
					log.info(loggerDealId + " - source instance of Input Stream");
					input = IOUtils.toByteArray((InputStream) src);
				} else if (src instanceof SCBCommObj) {
					commObj = (SCBCommObj) src;
				}

				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}

				if (commObj != null) {
					// Create SCB Comm Object
					SCBCommObj reqObj = new SCBCommObj();
					SCBHeader header = SCBOcrNlpUtil.createSCBProcessWEXTemplateResultsHeaderObject(ModuleCodes.WEX);
					SCBFooter footer = new SCBFooter();
					reqObj.setHeader(header);
					reqObj.setFooter(footer);
					SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.WEX_PAGE_INFO);
					reqObj.getBody().addSection(Sections.WEX_PAGE_INFO, section);
					genericJson = reqObj;
					jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
				}
			} catch (Exception e) {
				log.error(loggerDealId + " - Other Exception " + e);
				throw new TransformerException(CoreMessages.createStaticMessage(loggerDealId
						+ " - SCBOcrNlpProcessTemplateTransformer Unable to transform commobj to Generic Json" + src),
						e);
			}
		}
		return jsonResponse;
	}
}
