package com.scb.ms.mule.entity;

public class SCBOcrNlpPartyDetails {

	private String partyRole = "";
	private String partyId = "";
	private String partyExtId = "";
	private String partyName = "";
	private String address1 = "";
	private String address2 = "";
	private String address3 = "";
	private String addCtyCode = "";
	private String docNumber = "";
    private String opCode = "";

	/**
	 * @return the partyRole
	 */
	public String getPartyRole() {
		return partyRole;
	}

	/**
	 * @param partyRole
	 *            the partyRole to set
	 */
	public void setPartyRole(String partyRole) {
		this.partyRole = partyRole;
	}

	/**
	 * @return the partyId
	 */
	public String getPartyId() {
		return partyId;
	}

	/**
	 * @param partyId
	 *            the partyId to set
	 */
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	/**
	 * @return the partyExtId
	 */
	public String getPartyExtId() {
		return partyExtId;
	}

	/**
	 * @param partyExtId
	 *            the partyExtId to set
	 */
	public void setPartyExtId(String partyExtId) {
		this.partyExtId = partyExtId;
	}

	/**
	 * @return the partyName
	 */
	public String getPartyName() {
		return partyName;
	}

	/**
	 * @param partyName
	 *            the partyName to set
	 */
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	/**
	 * @return the address1
	 */
	public String getAddress1() {
		return address1;
	}

	/**
	 * @param address1
	 *            the address1 to set
	 */
	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	/**
	 * @return the address2
	 */
	public String getAddress2() {
		return address2;
	}

	/**
	 * @param address2
	 *            the address2 to set
	 */
	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	/**
	 * @return the address3
	 */
	public String getAddress3() {
		return address3;
	}

	/**
	 * @param address3
	 *            the address3 to set
	 */
	public void setAddress3(String address3) {
		this.address3 = address3;
	}

	/**
	 * @return the addCtyCode
	 */
	public String getAddCtyCode() {
		return addCtyCode;
	}

	/**
	 * @param addCtyCode
	 *            the addCtyCode to set
	 */
	public void setAddCtyCode(String addCtyCode) {
		this.addCtyCode = addCtyCode;
	}

	/**
	 * @return the docNumber
	 */
	public String getDocNumber() {
		return docNumber;
	}

	/**
	 * @param docNumber
	 *            the docNumber to set
	 */
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}

	/**
	 * @return the opCode
	 */
	public String getOpCode() {
		return opCode;
	}

	/**
	 * @param opCode the opCode to set
	 */
	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}


}
