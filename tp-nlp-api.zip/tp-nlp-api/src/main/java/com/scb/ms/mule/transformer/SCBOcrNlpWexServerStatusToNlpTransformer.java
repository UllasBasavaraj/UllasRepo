package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.transformer.exception.SCBTransformException;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpWEXServerStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpWexServerStatusToNlpTransformer extends AbstractMessageTransformer {

	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpWexServerStatusToNlpTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.debug("Enter in to Mule Wex Server Status transformer class");

		String genericJson = null;
		Object src = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object commObjJson = null;

			src = message.getPayload();

			try {
				log.debug("Source Mule Wex Server Status ==> " + src);
				if (src instanceof String) {
					input = (String) src;
				} else if (src instanceof InputStream) {
					input = IOUtils.toString((InputStream) src, "UTF-8");
				}

				// create request, set header and footer
				log.debug("Creating the request");
				SCBCommObj reqObj = new SCBCommObj();
				SCBHeader reqHeader = SCBOcrNlpUtil.createSCBUpdateWEXServerStatusHeaderObject(ModuleCodes.WEX);
				SCBFooter reqFooter = new SCBFooter();
				reqObj.setHeader(reqHeader);
				reqObj.setFooter(reqFooter);

				// set the request body
				try {
					SCBOcrNlpWEXServerStatus wexServerStatus = mapper.readValue(input, SCBOcrNlpWEXServerStatus.class);
					reqObj.getBody()
							.addSection(SCBCommObjTransformer.pojoToSection(wexServerStatus, SCBOcrNlpWEXServerStatus.class));
				} catch (SCBTransformException e) {
					genTechErrMsg(reqFooter, "400", "Invalid Request", "Invalid request, missing or invalid data.");
				}

				// create JSON string
				commObjJson = reqObj;
				log.debug("Generic JSON ==> " + commObjJson.toString());
				genericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObjJson);
				log.debug("Initial data from WEX Utility JSON ==> " + genericJson);

			} catch (Exception e) {
				throw new TransformerException(
						CoreMessages.createStaticMessage("Error in SCBWexServerStatusToNlpTransformer: " + src), e);
			}
		}

		return genericJson;
	}

	private static void genTechErrMsg(SCBFooter requestFooter, String errorCode, String errorTitle,
			String errorMessage) {
		SCBValidationErrorResult scbValidationErrorCode = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMessage = new SCBValidationErrorResult(errorMessage, "errorMessage",
				null);
		requestFooter.addError(scbValidationErrorCode);
		requestFooter.addError(scbValidationErrorTitle);
		requestFooter.addError(scbValidationErrorMessage);
	}
}
