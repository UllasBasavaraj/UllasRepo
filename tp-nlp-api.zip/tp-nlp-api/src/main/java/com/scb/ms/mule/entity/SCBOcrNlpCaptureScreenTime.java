package com.scb.ms.mule.entity;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

public class SCBOcrNlpCaptureScreenTime {

	@Id
	private String id;
	private String dealId = "";
	private String productId = "";
	private String stepId = "";
	private String clientId = "";
	private String country = "";
	private String regTimeStamp = "";
	private String systemCode = "";
	private int idleTime;
	private String userId = "";
	private String userRole = "";
	private String screenType = "";
	private Date MC_S_Time;
	private Date MC_E_Time;
	private Date RC_S_Time;
	private Date RC_E_Time;
	private Date MS_S_Time;
	private Date MS_E_Time;
	private long totlal_time;
	@Transient
	private String entryType = "";
	

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the regTimeStamp
	 */
	public String getRegTimeStamp() {
		return regTimeStamp;
	}

	/**
	 * @param regTimeStamp
	 *            the regTimeStamp to set
	 */
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the idleTime
	 */
	public int getIdleTime() {
		return idleTime;
	}

	/**
	 * @param idleTime
	 *            the idleTime to set
	 */
	public void setIdleTime(int idleTime) {
		this.idleTime = idleTime;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the userRole
	 */
	public String getUserRole() {
		return userRole;
	}

	/**
	 * @param userRole
	 *            the userRole to set
	 */
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	/**
	 * @return the screenType
	 */
	public String getScreenType() {
		return screenType;
	}

	/**
	 * @param screenType
	 *            the screenType to set
	 */
	public void setScreenType(String screenType) {
		this.screenType = screenType;
	}

	/**
	 * @return the mC_S_Time
	 */
	public Date getMC_S_Time() {
		return MC_S_Time;
	}

	/**
	 * @param mC_S_Time
	 *            the mC_S_Time to set
	 */
	public void setMC_S_Time(Date mC_S_Time) {
		MC_S_Time = mC_S_Time;
	}

	/**
	 * @return the mC_E_Time
	 */
	public Date getMC_E_Time() {
		return MC_E_Time;
	}

	/**
	 * @param mC_E_Time
	 *            the mC_E_Time to set
	 */
	public void setMC_E_Time(Date mC_E_Time) {
		MC_E_Time = mC_E_Time;
	}

	/**
	 * @return the rC_S_Time
	 */
	public Date getRC_S_Time() {
		return RC_S_Time;
	}

	/**
	 * @param rC_S_Time
	 *            the rC_S_Time to set
	 */
	public void setRC_S_Time(Date rC_S_Time) {
		RC_S_Time = rC_S_Time;
	}

	/**
	 * @return the rC_E_Time
	 */
	public Date getRC_E_Time() {
		return RC_E_Time;
	}

	/**
	 * @param rC_E_Time
	 *            the rC_E_Time to set
	 */
	public void setRC_E_Time(Date rC_E_Time) {
		RC_E_Time = rC_E_Time;
	}

	/**
	 * @return the mS_S_Time
	 */
	public Date getMS_S_Time() {
		return MS_S_Time;
	}

	/**
	 * @param mS_S_Time
	 *            the mS_S_Time to set
	 */
	public void setMS_S_Time(Date mS_S_Time) {
		MS_S_Time = mS_S_Time;
	}

	/**
	 * @return the mS_E_Time
	 */
	public Date getMS_E_Time() {
		return MS_E_Time;
	}

	/**
	 * @param mS_E_Time
	 *            the mS_E_Time to set
	 */
	public void setMS_E_Time(Date mS_E_Time) {
		MS_E_Time = mS_E_Time;
	}

	/**
	 * @return the entryType
	 */
	public String getEntryType() {
		return entryType;
	}

	/**
	 * @param entryType
	 *            the entryType to set
	 */
	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}

	/**
	 * @return the totlal_time
	 */
	public long getTotlal_time() {
		return totlal_time;
	}

	/**
	 * @param totlal_time the totlal_time to set
	 */
	public void setTotlal_time(long totlal_time) {
		this.totlal_time = totlal_time;
	}

}
