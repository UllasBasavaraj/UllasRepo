package com.scb.ms.mule.transformer;

import java.io.IOException;

import org.elasticsearch.common.lang3.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.JsonPath;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewTxnUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpTDStatusMvmntRequest;
import com.scb.ms.mule.entity.SCBOcrNlpTDStatusMvmntRequestObj;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealSubStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DigitizerStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpTDStatusMvmntTransformer extends AbstractMessageTransformer {

	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpTDStatusMvmntTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to TD Status Movement transformer calss ");

		String vppGenericJson = null;
		String requestStatus = EMPTY;
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE, EMPTY);
			String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);
			switch (StringUtils.upperCase(flowType)) {

			case FlowType.SUBMIT_DTP_FLOW:
				log.debug(loggerDealId + " - SUBMIT DTP Status mvmnt transformer...");
				String dtpRequestPayLoad = null;
				String dtpResponsePayLoad = null;
				try {
					dtpRequestPayLoad = message.getInvocationProperty(Fields.DTP_REQ_PAYLOAD);
					dtpResponsePayLoad = message.getInvocationProperty(Fields.DTP_RESPONSE_PAYLOAD);
					String dataEntryApplicable = message.getInvocationProperty(Fields.DATA_ENTRY_APPLICABLE);
					
					if (StringUtils.contains(dtpRequestPayLoad, Fields.SANCTION_PARTIES_REQ) || StringUtils.equals(Fields.Y, dataEntryApplicable)) {
						vppGenericJson = getStatusMvmtJsonForDTPOrOTPOth(message, loggerDealId, dtpRequestPayLoad,dtpResponsePayLoad, mapper, dataEntryApplicable);

						log.debug(loggerDealId + " - SCBStatusMvmnt Submit DTP Request  json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Submit DTP Submit Status Movement Transformer Failed" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " - Unable to generate deal extn from td stamvnt response" + dtpRequestPayLoad),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_OTH_FLOW:
				log.debug(loggerDealId + "  SUBMIT OTP OTHRS Status mvmnt transformer...");
				String otpOthRequestPayLoad = null;
				String otpOthResponsePayLoad = null;
				try {
					otpOthRequestPayLoad = message.getInvocationProperty(Fields.OTP_OTH_REQ_PAYLOAD);
					otpOthResponsePayLoad = message.getInvocationProperty(Fields.OTP_OTH_RES_PAYLOAD);
					String dataEntryApplicable = message.getInvocationProperty(Fields.DATA_ENTRY_APPLICABLE);
					
					if (StringUtils.contains(otpOthRequestPayLoad, Fields.SANCTION_PARTIES_REQ)) {
						vppGenericJson = getStatusMvmtJsonForDTPOrOTPOth(message, loggerDealId, otpOthRequestPayLoad,otpOthResponsePayLoad, mapper, dataEntryApplicable);

						log.debug(loggerDealId + " SCBStatusMvmnt OTP OTHERS Request  json" + vppGenericJson);
					}
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SCBStatusMvmnt OTP OTHER Submit Request" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " Unable to generate deal extn from td stamvnt response" + otpOthRequestPayLoad),
							e);
				}
				break;

			case FlowType.SUBMIT_OTP_NEW_FLOW:
				log.debug(loggerDealId + "  SUBMIT OTP New Status mvmnt transformer...");
				String otpNewRequestPayLoad = null;
				String otpNewResponsePayLoad = null;
				try {
					otpNewRequestPayLoad = message.getInvocationProperty(Fields.OTP_NEW_REQ_PAYLOAD);
					otpNewResponsePayLoad = message.getInvocationProperty(Fields.OTP_NEW_RES_PAYLOAD);
					if (StringUtils.contains(otpNewRequestPayLoad, Fields.DOC_CREATE_REQ)) {
						vppGenericJson = getOTPNewStatusMvmnt(message, loggerDealId, otpNewRequestPayLoad,
								otpNewResponsePayLoad, mapper);

						log.debug(loggerDealId + " OTP NEW - SCBStatusMvmnt Request  json" + vppGenericJson);
						return vppGenericJson;
					}
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SCBStatusMvmnt OTP NEW Submit Request" + e);
					throw new TransformerException(
							CoreMessages.createStaticMessage(loggerDealId
									+ " Unable to generate deal extn from td stamvnt response" + otpNewRequestPayLoad),
							e);
				}
				break;

			case FlowType.FORWARD_FLOW:
				try {
					log.info(loggerDealId + " - Forward Flow Status mvmnt transformer...");
					String systemCode = message.getInvocationProperty(Fields.SYSTEM_CODE);
					String dtpBatchWindow = message.getInvocationProperty(Fields.DTP_BATCH_WINDOW);
					String stepId = message.getInvocationProperty(Fields.STEP_ID);

					requestStatus = message.getInvocationProperty(Fields.REQ_STATUS);
					String digitizerStatus = message.getInvocationProperty(Fields.DIGITIZER_STATUS);
					log.debug(loggerDealId + " - SCBStatusMvmnt forward Digitizer Status before" + digitizerStatus);
					if (digitizerStatus.equalsIgnoreCase(DigitizerStatus.UPDATED)) {
						requestStatus = DigitizerStatus.RESCANN;
						message.setInvocationProperty(Fields.DIGITIZER_STATUS, requestStatus);
					}

					if(StringUtils.isNotEmpty(systemCode) && systemCode.equalsIgnoreCase(Fields.DTP_SYSTEM)
							&& StringUtils.isNotEmpty(dtpBatchWindow) && dtpBatchWindow.equalsIgnoreCase(Fields.YES) 
							&& (!stepId.contains(Fields.DTP_ISSUANCE))){
						requestStatus = DigitizerStatus.BATCH;
						message.setInvocationProperty(Fields.DIGITIZER_STATUS, requestStatus);
					}
					vppGenericJson = getForwardStatusMvmtJson(message, mapper, loggerDealId, requestStatus);
					log.debug(loggerDealId + " Forward Flow - SCBStatusMvmnt Request  json" + vppGenericJson);
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SCBStatusMvmnt forward Request" + e);
					throw new TransformerException(CoreMessages.createStaticMessage(
							loggerDealId + " - Unable to generate Status Movement Json Request for the TD"), e);
				}
				break;

			case FlowType.UNLOCK_TD:
				try {
					log.info(loggerDealId + " - Unlock Status mvmnt transformer...");
					vppGenericJson = getUnlockStatusMvmtJson(message, mapper, loggerDealId, null);
					log.debug(loggerDealId + " Unlock - SCBStatusMvmnt Request  json" + vppGenericJson);
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SCBStatusMvmnt Unlock Request" + e);
					throw new TransformerException(CoreMessages.createStaticMessage(
							loggerDealId + " - Unable to generate Status Movement Json Request for the TD"), e);
				}
				break;
				
			case FlowType.SUBMIT_DTP_SYNC:
				try {
					log.info(loggerDealId + " - Submit Sync Status mvmnt transformer...");
					vppGenericJson = getDtpSyncStatusMvmtJson(message, mapper, loggerDealId, null);
					log.debug(loggerDealId + " Submit Sync - SCBStatusMvmnt Request  json" + vppGenericJson);
				} catch (JsonProcessingException e) {
					log.error(loggerDealId + " - Exception in SCBStatusMvmnt Unlock Request" + e);
					throw new TransformerException(CoreMessages.createStaticMessage(
							loggerDealId + " - Unable to generate Status Movement Json Request for the TD"), e);
				}
				break;
			}
		}
		return vppGenericJson;
	}

	private String getForwardStatusMvmtJson(MuleMessage message, ObjectMapper mapper, String loggerDealId, String reqStatus)
			throws JsonProcessingException {
		SCBOcrNlpTDStatusMvmntRequestObj statusMvmntReqObj = new SCBOcrNlpTDStatusMvmntRequestObj();
		statusMvmntReqObj.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
		statusMvmntReqObj.setSystemCode(message.getInvocationProperty(Fields.SYSTEM_CODE));
		statusMvmntReqObj.setCountryCode(message.getInvocationProperty(Fields.COUNTRY_CODE));
		statusMvmntReqObj.setCustomerId(message.getInvocationProperty(Fields.CUSTOMER_ID));
		statusMvmntReqObj.setDealReferance(message.getInvocationProperty(Fields.DEAL_ID));
		statusMvmntReqObj.setProductCode(message.getInvocationProperty(Fields.PRODUCT_ID));
		statusMvmntReqObj.setStepCode(message.getInvocationProperty(Fields.STEP_ID));
		statusMvmntReqObj
				.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(message.getInvocationProperty(Fields.REG_TIME_STAMP)));
		statusMvmntReqObj.setRequestType(Fields.DIGITIZER);
		statusMvmntReqObj.setEnableIcon(Fields.Y);
		statusMvmntReqObj.setReleaseTxnLock(Fields.Y);
		statusMvmntReqObj.setRequestStatus(
				StringUtils.isNotBlank(reqStatus) ? reqStatus : message.getInvocationProperty(Fields.REQ_STATUS));
		statusMvmntReqObj.setRegTimeMsStr(message.getInvocationProperty(Fields.REG_TIME_MS_STR));
		SCBOcrNlpTDStatusMvmntRequest tdStatusMvmntReq = new SCBOcrNlpTDStatusMvmntRequest();
		tdStatusMvmntReq.setTdStatusMvmtRequest(statusMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStatusMvmntReq);
		return vppGenericJson;
	}
	
	private String getUnlockStatusMvmtJson(MuleMessage message, ObjectMapper mapper, String loggerDealId, String reqStatus)
			throws JsonProcessingException {
		SCBOcrNlpTDStatusMvmntRequestObj statusMvmntReqObj = new SCBOcrNlpTDStatusMvmntRequestObj();
		statusMvmntReqObj.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
		statusMvmntReqObj.setSystemCode(message.getInvocationProperty(Fields.SYSTEM_CODE));
		statusMvmntReqObj.setCountryCode(message.getInvocationProperty(Fields.COUNTRY_CODE));
		statusMvmntReqObj.setCustomerId(message.getInvocationProperty(Fields.CUSTOMER_ID));
		statusMvmntReqObj.setDealReferance(message.getInvocationProperty(Fields.DEAL_ID));
		statusMvmntReqObj.setProductCode(message.getInvocationProperty(Fields.PRODUCT_ID));
		statusMvmntReqObj.setStepCode(message.getInvocationProperty(Fields.STEP_ID));
		statusMvmntReqObj
				.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(message.getInvocationProperty(Fields.REG_TIME_STAMP)));
		statusMvmntReqObj.setRequestType(Fields.DIGITIZER);
		statusMvmntReqObj.setEnableIcon(Fields.Y);
		statusMvmntReqObj.setReleaseTxnLock(Fields.Y);
		statusMvmntReqObj.setRequestStatus(
				StringUtils.isNotBlank(reqStatus) ? reqStatus : message.getInvocationProperty(Fields.REQ_STATUS));
		statusMvmntReqObj.setRegTimeMsStr(message.getInvocationProperty(Fields.REG_TIME_MS_STR));
		SCBOcrNlpTDStatusMvmntRequest tdStatusMvmntReq = new SCBOcrNlpTDStatusMvmntRequest();
		tdStatusMvmntReq.setTdStatusMvmtRequest(statusMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStatusMvmntReq);
		return vppGenericJson;
	}

	private String getDtpSyncStatusMvmtJson(MuleMessage message, ObjectMapper mapper, String loggerDealId, String reqStatus)
			throws JsonProcessingException {
		SCBOcrNlpTDStatusMvmntRequestObj statusMvmntReqObj = new SCBOcrNlpTDStatusMvmntRequestObj();
		statusMvmntReqObj.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
		statusMvmntReqObj.setSystemCode(message.getInvocationProperty(Fields.SYSTEM_CODE));
		statusMvmntReqObj.setCountryCode(message.getInvocationProperty(Fields.COUNTRY_CODE));
		statusMvmntReqObj.setCustomerId(message.getInvocationProperty(Fields.CUSTOMER_ID));
		statusMvmntReqObj.setDealReferance(message.getInvocationProperty(Fields.DEAL_ID));
		statusMvmntReqObj.setProductCode(message.getInvocationProperty(Fields.PRODUCT_ID));
		statusMvmntReqObj.setStepCode(message.getInvocationProperty(Fields.STEP_ID));
		statusMvmntReqObj
				.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(message.getInvocationProperty(Fields.REG_TIME_STAMP)));
		statusMvmntReqObj.setRequestType(Fields.DIGITIZER);
		statusMvmntReqObj.setEnableIcon(Fields.Y);
		statusMvmntReqObj.setReleaseTxnLock(Fields.N);
		statusMvmntReqObj.setRequestStatus(
				StringUtils.isNotBlank(reqStatus) ? reqStatus : message.getInvocationProperty(Fields.REQ_STATUS));
		
		if(StringUtils.isNotBlank(statusMvmntReqObj.getRequestStatus())
				&& statusMvmntReqObj.getRequestStatus().equalsIgnoreCase(DigitizerStatus.BATCHFAIL)){
			statusMvmntReqObj.setReleaseTxnLock(Fields.Y);
		}
		statusMvmntReqObj.setRegTimeMsStr(message.getInvocationProperty(Fields.REG_TIME_MS_STR));
		SCBOcrNlpTDStatusMvmntRequest tdStatusMvmntReq = new SCBOcrNlpTDStatusMvmntRequest();
		tdStatusMvmntReq.setTdStatusMvmtRequest(statusMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStatusMvmntReq);
		return vppGenericJson;
	}
	private String getOTPNewStatusMvmnt(MuleMessage message, String loggerDealId, String otpNewRequestPayLoad,
			String otpNewResponsePayLoad, ObjectMapper mapper) throws JsonProcessingException {
		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		SCBOcrNlpOTPNewUpdateReq dealInfo = getDealBasicInfo(otpNewRequestPayLoad);
		SCBOcrNlpTDStatusMvmntRequestObj statusMvmntReqObj = new SCBOcrNlpTDStatusMvmntRequestObj();
		regTimeStamp = StringUtils.isNotBlank(regTimeStamp) ? regTimeStamp : dealInfo.getRegTimeStamp();
		statusMvmntReqObj.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
		statusMvmntReqObj.setSystemCode(dealInfo.getSourceSystem());
		statusMvmntReqObj.setCountryCode(dealInfo.getCountryCode());
		statusMvmntReqObj.setCustomerId(dealInfo.getCustomerId());
		statusMvmntReqObj.setDealReferance(dealInfo.getDealReferance());
		statusMvmntReqObj.setProductCode(dealInfo.getProductCode());
		statusMvmntReqObj.setStepCode(dealInfo.getStepCode());
		statusMvmntReqObj.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(regTimeStamp));
		statusMvmntReqObj.setRequestType(message.getInvocationProperty(Fields.REQUEST_TYPE));
		statusMvmntReqObj.setEnableIcon(message.getInvocationProperty(Fields.ENABLE_ICON));
		statusMvmntReqObj.setReleaseTxnLock(message.getInvocationProperty(Fields.RELEASE_TXN_LOCK));
		statusMvmntReqObj.setRegTimeMsStr(message.getInvocationProperty(Fields.REG_TIME_MS_STR));
		// response need to get from OTP New response object
		String requestStatus = getOTPNewReqStatus(loggerDealId, otpNewResponsePayLoad);
		statusMvmntReqObj.setRequestStatus(getDigitizerStatus(message, requestStatus));
		SCBOcrNlpTDStatusMvmntRequest tdStatusMvmntReq = new SCBOcrNlpTDStatusMvmntRequest();
		tdStatusMvmntReq.setTdStatusMvmtRequest(statusMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStatusMvmntReq);
		log.debug(loggerDealId + " SCBStatusMvmnt OTP NEW Request  json" + vppGenericJson);

		return vppGenericJson;
	}

	private String getOTPNewReqStatus(String loggerDealId, String otpNewResponsePayLoad) {
		String requestStatus;
		if (StringUtils.contains(otpNewResponsePayLoad, Fields.DOC_CREATE_RES)) {
			requestStatus = JsonPath.read(
					Configuration.defaultConfiguration().jsonProvider().parse(otpNewResponsePayLoad),
					"$.documentCreateResponse.status");
			log.debug(loggerDealId + "  OTP NEEW system response  : " + requestStatus);
		} else {
			requestStatus = DigitizerStatus.TECHFAIL;
			log.debug(loggerDealId + "  DTP system response considered Error  : " + requestStatus);
		}
		return requestStatus;
	}

	private String getReqStatusFromResponse(String loggerDealId, String otpOthResponsePayLoad, String dataEntryApplicable) {
		String requestStatus = DigitizerStatus.UPDATED;
		
		if (StringUtils.contains(otpOthResponsePayLoad, Fields.NAMES_SCREENING_RESPONSE)
				&& StringUtils.equalsIgnoreCase(Fields.N, dataEntryApplicable) ) {
			try {
				ObjectMapper mapper = new ObjectMapper();
				String overAllStatus = mapper.readTree(otpOthResponsePayLoad).findPath("namesScreeningResponse").findPath("overAllStatus").toString();
				if (StringUtils.isNotEmpty(overAllStatus)) {
					overAllStatus = overAllStatus.replaceAll("^\"+|\"+$", "");
				}
				JsonNode partyList = mapper.readTree(otpOthResponsePayLoad).findPath("namesScreeningResponse").findPath("partyDetails");
				if (!partyList.isMissingNode() && partyList.isArray()) {
					for (int i = 0; i < partyList.size(); i++) {
						JsonNode element = partyList.get(i);
						String individualStatus = element.findPath("dprStatus").toString();
						if (StringUtils.isNotEmpty(individualStatus)) {
							individualStatus = individualStatus.replaceAll("^\"+|\"+$", "");
						}
						if(StringUtils.isBlank(individualStatus)){
							requestStatus = DigitizerStatus.TECHFAIL;
						}else if (!individualStatus.equalsIgnoreCase(Fields.DTP_SUCCESS_RESPONSE)
								&& !individualStatus.equalsIgnoreCase(Fields.DTP_DELETED_RESPONSE)
								&& !individualStatus.equalsIgnoreCase(Fields.DTP_INSERTED_RESPONSE)
								&& !individualStatus.equalsIgnoreCase(Fields.DTP_NOTFOUND_RESPONSE)){
							requestStatus = DigitizerStatus.TECHFAIL;
						}
					}
				}
				// If TechFail and Overal status is TxnLock then Take the Txn Lock as status
				if((requestStatus.equalsIgnoreCase(DigitizerStatus.TECHFAIL) 
						|| requestStatus.equalsIgnoreCase(DigitizerStatus.UPDATED))
						&& StringUtils.contains(overAllStatus.toUpperCase(), DigitizerStatus.TXNL) ){
					requestStatus = overAllStatus;
				}
				
			} catch (Exception e) {
				log.error(loggerDealId + "  DTP system response Individual Party looping : " + e);
				requestStatus = DigitizerStatus.TECHFAIL;
			} 
			log.debug(loggerDealId + "  OTP system response  : " + requestStatus);
		} else if (StringUtils.equals(Fields.Y, dataEntryApplicable)) {
			requestStatus = JsonPath.read(
					Configuration.defaultConfiguration().jsonProvider().parse(otpOthResponsePayLoad), "$.status");
			log.debug(loggerDealId + "  DTP IMP/EXP system response  : " + requestStatus);
		}else {
			requestStatus = DigitizerStatus.TECHFAIL;
			log.debug(loggerDealId + "  DTP system response considered Error  : " + requestStatus);
		}
		return requestStatus;
	}

	private String getStatusMvmtJsonForDTPOrOTPOth(MuleMessage message, String loggerDealId, String requestPayLoad,
			String responsePayLoad, ObjectMapper mapper, String dataEntryApplicable) throws JsonProcessingException {
		String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
		SCBOcrNlpTDStatusMvmntRequestObj statusMvmntReqObj = new SCBOcrNlpTDStatusMvmntRequestObj();
		// Status Movement Logic
		statusMvmntReqObj.setUuid(Fields.OCR_NLP + SCBOcrNlpUtil.getCurrDate());
		statusMvmntReqObj.setSystemCode(message.getInvocationProperty(Fields.SYSTEM_CODE));
		statusMvmntReqObj.setCountryCode(message.getInvocationProperty(Fields.COUNTRY_CODE));
		statusMvmntReqObj.setCustomerId(message.getInvocationProperty(Fields.CUSTOMER_ID));
		statusMvmntReqObj.setDealReferance(message.getInvocationProperty(Fields.DEAL_ID));
		statusMvmntReqObj.setProductCode(message.getInvocationProperty(Fields.PRODUCT_ID));
		statusMvmntReqObj.setStepCode(message.getInvocationProperty(Fields.STEP_ID));
		statusMvmntReqObj.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(regTimeStamp));
		statusMvmntReqObj.setRequestType(message.getInvocationProperty(Fields.REQUEST_TYPE));
		statusMvmntReqObj.setEnableIcon(message.getInvocationProperty(Fields.ENABLE_ICON));
		statusMvmntReqObj.setReleaseTxnLock(message.getInvocationProperty(Fields.RELEASE_TXN_LOCK));
		// response need to get from DTP response object
		String requestStatus = getReqStatusFromResponse(loggerDealId, responsePayLoad, dataEntryApplicable);
		statusMvmntReqObj.setRequestStatus(getDigitizerStatus(message, requestStatus));
		statusMvmntReqObj.setRegTimeMsStr(message.getInvocationProperty(Fields.REG_TIME_MS_STR));
		SCBOcrNlpTDStatusMvmntRequest tdStatusMvmntReq = new SCBOcrNlpTDStatusMvmntRequest();
		tdStatusMvmntReq.setTdStatusMvmtRequest(statusMvmntReqObj);
		String vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(tdStatusMvmntReq);
		return vppGenericJson;
	}

	private String getDigitizerStatus(MuleMessage message, String requestStatus) {
		String digitizerStatus;
		// Status Movement Logic
		String callInitiatedFromUI = message.getInvocationProperty(Fields.CALL_ORIGINATION_UI,EMPTY);
		if (StringUtils.contains(DigitizerStatus.UPDATED, requestStatus.toUpperCase())) {
			digitizerStatus = DigitizerStatus.UPDATED;
			message.setInvocationProperty(Fields.STAGE_CALL_INITIATE_STATUS, Fields.YES);
			message.setInvocationProperty(Fields.DEAL_FINAL_SUBMIT_STATUS, DealStatus.SUBMIT_SUCCESSFUL);
		} else if (StringUtils.contains(requestStatus.toUpperCase(), DigitizerStatus.TXNL)) {
			digitizerStatus = requestStatus;
			message.setInvocationProperty(Fields.STAGE_CALL_INITIATE_STATUS, Fields.NO);
			message.setInvocationProperty(Fields.TP_SUB_CALL_STATUS, DealSubStatus.FAILED);
			message.setInvocationProperty(Fields.DEAL_FINAL_SUBMIT_STATUS, DealStatus.FORWARD_SUCCESSFUL);
		} else if (StringUtils.contains(requestStatus.toUpperCase(), Fields.NOT_MAKR)) {
			digitizerStatus = Fields.NOT_MAKR;
			message.setInvocationProperty(Fields.STAGE_CALL_INITIATE_STATUS, Fields.NO);
			message.setInvocationProperty(Fields.TP_SUB_CALL_STATUS, DealSubStatus.FAILED);
			message.setInvocationProperty(Fields.DEAL_FINAL_SUBMIT_STATUS, DealStatus.FORWARD_SUCCESSFUL);
		} else {
			digitizerStatus = DigitizerStatus.TECHFAIL;
			if(StringUtils.isNotBlank(callInitiatedFromUI) && callInitiatedFromUI.equalsIgnoreCase(Fields.NO)){
				digitizerStatus = DigitizerStatus.BATCHFAIL;
			}
			message.setInvocationProperty(Fields.STAGE_CALL_INITIATE_STATUS, Fields.NO);
			message.setInvocationProperty(Fields.TP_SUB_CALL_STATUS, DealSubStatus.FAILED);
			message.setInvocationProperty(Fields.DEAL_FINAL_SUBMIT_STATUS, DealStatus.SUBMIT_FAILED);
		}
		message.setInvocationProperty(Fields.DIGITIZER_STATUS, digitizerStatus);
		return digitizerStatus;
	}

	private SCBOcrNlpOTPNewUpdateReq getDealBasicInfo(String otpNewRequestPayLoad) {
		SCBOcrNlpOTPNewTxnUpdateReq otpNewReq = null;
		SCBOcrNlpOTPNewUpdateReq docCreateRequest = null;
		try {
			otpNewReq = new ObjectMapper().readValue(otpNewRequestPayLoad, SCBOcrNlpOTPNewTxnUpdateReq.class);
			docCreateRequest = otpNewReq.getDocCreateRequest();
		} catch (IOException e) {
			log.error(otpNewRequestPayLoad + " - Exception in getDealBasicInfo Request for OTP New" + e);
		}
		return docCreateRequest;
	}

	/*private SCBOcrNlpNamesScreeningRequest getSanctionParties(String dtpRequestPayLoad) {
		SCBOcrNlpNamesScreeningRequest sanctionPartiesRequest = null;
		try {
			SCBOcrNlpNamesScreeningListRequest sanctionPartiesList = new ObjectMapper().readValue(dtpRequestPayLoad,
					SCBOcrNlpNamesScreeningListRequest.class);
			sanctionPartiesRequest = sanctionPartiesList.getSanctionPartiesRequest();
		} catch (IOException e) {
			log.error(dtpRequestPayLoad + " - Exception in getSanctionParties Request" + e);
		}
		return sanctionPartiesRequest;
	}*/
}
