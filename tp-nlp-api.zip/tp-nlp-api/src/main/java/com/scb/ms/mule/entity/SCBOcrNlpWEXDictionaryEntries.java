package com.scb.ms.mule.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpWEXDictionaryEntries {
	@JsonProperty("pendingDictionaryEntriesList")
	private List<SCBOcrNlpWEXDictionaryEntry> dictPendingEntriesList = new ArrayList<>();
	@JsonProperty("processedDictionaryEntriesList")
	private List<SCBOcrNlpWEXDictionaryEntry> dictProcessedEntriesList = new ArrayList<>();

	/**
	 * @return the dictPendingEntriesList
	 */
	public List<SCBOcrNlpWEXDictionaryEntry> getDictPendingEntriesList() {
		return dictPendingEntriesList;
	}

	/**
	 * @param dictPendingEntriesList
	 *            the dictPendingEntriesList to set
	 */
	public void setDictPendingEntriesList(List<SCBOcrNlpWEXDictionaryEntry> dictPendingEntriesList) {
		this.dictPendingEntriesList = dictPendingEntriesList;
	}

	/**
	 * @return the dictProcessedEntriesList
	 */
	public List<SCBOcrNlpWEXDictionaryEntry> getDictProcessedEntriesList() {
		return dictProcessedEntriesList;
	}

	/**
	 * @param dictProcessedEntriesList
	 *            the dictProcessedEntriesList to set
	 */
	public void setDictProcessedEntriesList(List<SCBOcrNlpWEXDictionaryEntry> dictProcessedEntriesList) {
		this.dictProcessedEntriesList = dictProcessedEntriesList;
	}

}
