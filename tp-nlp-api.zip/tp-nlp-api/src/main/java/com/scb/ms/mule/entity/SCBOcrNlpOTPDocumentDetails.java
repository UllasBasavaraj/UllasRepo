package com.scb.ms.mule.entity;

public class SCBOcrNlpOTPDocumentDetails {

	private String docNumber = "";
	private String newDocNumber = "";
	private String docType = "";
	private String docCurrency = "";
	private String docAmount = "";
	private String cptyId = "";
	private String relatedCptyParty = "";
	private String docTenor = "";
	private String docIssueDate = "";
	private String docTenorStartDate = "";
	private String docDueDate = "";
	private String acceptedDate = "";
	private String acceptedFlag = "";
	private String opCode = "";
	private SCBOcrNlpOTPShipmentDetails shipmentDetails;
	private SCBOcrNlpOTPAdditionalDetails additionalDetails;
	/**
	 * @return the docNumber
	 */
	public String getDocNumber() {
		return docNumber;
	}		
	/**
	 * @param docNumber the docNumber to set
	 */
	public void setDocNumber(String docNumber) {
		this.docNumber = docNumber;
	}
	/**
	 * @return the newDocNumber
	 */
	public String getNewDocNumber() {
		return newDocNumber;
	}
	/**
	 * @param newDocNumber the newDocNumber to set
	 */
	public void setNewDocNumber(String newDocNumber) {
		this.newDocNumber = newDocNumber;
	}
	/**
	 * @return the docType
	 */
	public String getDocType() {
		return docType;
	}
	/**
	 * @param docType the docType to set
	 */
	public void setDocType(String docType) {
		this.docType = docType;
	}
	/**
	 * @return the docCurrency
	 */
	public String getDocCurrency() {
		return docCurrency;
	}
	/**
	 * @param docCurrency the docCurrency to set
	 */
	public void setDocCurrency(String docCurrency) {
		this.docCurrency = docCurrency;
	}
	/**
	 * @return the docAmount
	 */
	public String getDocAmount() {
		return docAmount;
	}
	/**
	 * @param docAmount the docAmount to set
	 */
	public void setDocAmount(String docAmount) {
		this.docAmount = docAmount;
	}
	/**
	 * @return the cptyId
	 */
	public String getCptyId() {
		return cptyId;
	}
	/**
	 * @param cptyId the cptyId to set
	 */
	public void setCptyId(String cptyId) {
		this.cptyId = cptyId;
	}
	/**
	 * @return the relatedCptyParty
	 */
	public String getRelatedCptyParty() {
		return relatedCptyParty;
	}
	/**
	 * @param relatedCptyParty the relatedCptyParty to set
	 */
	public void setRelatedCptyParty(String relatedCptyParty) {
		this.relatedCptyParty = relatedCptyParty;
	}
	/**
	 * @return the docTenor
	 */
	public String getDocTenor() {
		return docTenor;
	}
	/**
	 * @param docTenor the docTenor to set
	 */
	public void setDocTenor(String docTenor) {
		this.docTenor = docTenor;
	}
	/**
	 * @return the docIssueDate
	 */
	public String getDocIssueDate() {
		return docIssueDate;
	}
	/**
	 * @param docIssueDate the docIssueDate to set
	 */
	public void setDocIssueDate(String docIssueDate) {
		this.docIssueDate = docIssueDate;
	}
	/**
	 * @return the docTenorStartDate
	 */
	public String getDocTenorStartDate() {
		return docTenorStartDate;
	}
	/**
	 * @param docTenorStartDate the docTenorStartDate to set
	 */
	public void setDocTenorStartDate(String docTenorStartDate) {
		this.docTenorStartDate = docTenorStartDate;
	}
	/**
	 * @return the docDueDate
	 */
	public String getDocDueDate() {
		return docDueDate;
	}
	/**
	 * @param docDueDate the docDueDate to set
	 */
	public void setDocDueDate(String docDueDate) {
		this.docDueDate = docDueDate;
	}
	/**
	 * @return the acceptedDate
	 */
	public String getAcceptedDate() {
		return acceptedDate;
	}
	/**
	 * @param acceptedDate the acceptedDate to set
	 */
	public void setAcceptedDate(String acceptedDate) {
		this.acceptedDate = acceptedDate;
	}
	/**
	 * @return the acceptedFlag
	 */
	public String getAcceptedFlag() {
		return acceptedFlag;
	}
	/**
	 * @param acceptedFlag the acceptedFlag to set
	 */
	public void setAcceptedFlag(String acceptedFlag) {
		this.acceptedFlag = acceptedFlag;
	}
	/**
	 * @return the opCode
	 */
	public String getOpCode() {
		return opCode;
	}
	/**
	 * @param opCode the opCode to set
	 */
	public void setOpCode(String opCode) {
		this.opCode = opCode;
	}
	/**
	 * @return the shipmentDetails
	 */
	public SCBOcrNlpOTPShipmentDetails getShipmentDetails() {
		return shipmentDetails;
	}
	/**
	 * @param shipmentDetails the shipmentDetails to set
	 */
	public void setShipmentDetails(SCBOcrNlpOTPShipmentDetails shipmentDetails) {
		this.shipmentDetails = shipmentDetails;
	}
	/**
	 * @return the additionalDetails
	 */
	public SCBOcrNlpOTPAdditionalDetails getAdditionalDetails() {
		return additionalDetails;
	}
	/**
	 * @param additionalDetails the additionalDetails to set
	 */
	public void setAdditionalDetails(SCBOcrNlpOTPAdditionalDetails additionalDetails) {
		this.additionalDetails = additionalDetails;
	}

	
}
