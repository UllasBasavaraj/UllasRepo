package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpTemplatesCoordinatesList {

	private int templateId;
	private List<SCBOcrNlpTemplateRoleCoordinatesList> templateRoleCoordinatesList = new ArrayList<SCBOcrNlpTemplateRoleCoordinatesList>();
	private String templateExtractedText= "";

	/**
	 * @return the templateId
	 */
	public int getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the templateCoordinatesList
	 */
	public List<SCBOcrNlpTemplateRoleCoordinatesList> getTemplateCoordinatesList() {
		return templateRoleCoordinatesList;
	}

	/**
	 * @param templateCoordinatesList
	 *            the templateCoordinatesList to set
	 */
	public void setTemplateCoordinatesList(List<SCBOcrNlpTemplateRoleCoordinatesList> templateCoordinatesList) {
		this.templateRoleCoordinatesList = templateCoordinatesList;
	}

	/**
	 * @return the templateRoleCoordinatesList
	 */
	public List<SCBOcrNlpTemplateRoleCoordinatesList> getTemplateRoleCoordinatesList() {
		return templateRoleCoordinatesList;
	}

	/**
	 * @param templateRoleCoordinatesList the templateRoleCoordinatesList to set
	 */
	public void setTemplateRoleCoordinatesList(List<SCBOcrNlpTemplateRoleCoordinatesList> templateRoleCoordinatesList) {
		this.templateRoleCoordinatesList = templateRoleCoordinatesList;
	}

	/**
	 * @return the templateExtractedText
	 */
	public String getTemplateExtractedText() {
		return templateExtractedText;
	}

	/**
	 * @param templateExtractedText the templateExtractedText to set
	 */
	public void setTemplateExtractedText(String templateExtractedText) {
		this.templateExtractedText = templateExtractedText;
	}
	

}
