package com.scb.ms.mule.entity;

public class SCBOcrNlpCollectionInstructions {

	private String rowData = "";

	/**
	 * @return the rowData
	 */
	public String getRowData() {
		return rowData;
	}

	/**
	 * @param rowData
	 *            the rowData to set
	 */
	public void setRowData(String rowData) {
		this.rowData = rowData;
	}

}
