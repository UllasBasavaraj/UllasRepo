package com.scb.ms.mule.entity;

import org.springframework.data.annotation.Id;

public class SCBOcrNlpApprovePageDocumentPagesList {

	
	@Id
	private String id;
	private String pageNumber;
	private String dealClsTp;
	private boolean approved;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(String pageNumber) {
		this.pageNumber = pageNumber;
	}
	public String getDealClsTp() {
		return dealClsTp;
	}
	public void setDealClsTp(String dealClsTp) {
		this.dealClsTp = dealClsTp;
	}
	/**
	 * @return the approved
	 */
	public boolean getApproved() {
		return approved;
	}

	/**
	 * @param approved
	 *            the approved to set
	 */
	public void setApproved(boolean approved) {
		this.approved = approved;
	}
	
	
}
