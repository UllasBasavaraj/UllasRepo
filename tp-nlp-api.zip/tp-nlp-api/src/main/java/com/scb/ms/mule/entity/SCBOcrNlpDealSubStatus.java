package com.scb.ms.mule.entity;

public class SCBOcrNlpDealSubStatus {

	private String wexCallStatus = "";
	private String wexTemplateCallStatus = "";
	private String wexDataExtractionCallStatus = "";
	private String forwardTdStageCallStatus = "";
	private String forwardTdStatusCallStatus = "";
	private String forwardTpCallStatus = "";
	private String submitTpCallStatus = "";
	private String submitTpSyncStatus = "";
	private String submitTdStageCallStatus = "";
	private String submitTdStatusCallStatus = "";
	private String submitIccFeedbackCallStatus = "";
	private String submitDatacapCallStatus = "";

	/**
	 * @return the wexCallStatus
	 */
	public String getWexCallStatus() {
		return wexCallStatus;
	}

	/**
	 * @param wexCallStatus
	 *            the wexCallStatus to set
	 */
	public void setWexCallStatus(String wexCallStatus) {
		this.wexCallStatus = wexCallStatus;
	}

	/**
	 * @return the wexTemplateCallStatus
	 */
	public String getWexTemplateCallStatus() {
		return wexTemplateCallStatus;
	}

	/**
	 * @param wexTemplateCallStatus
	 *            the wexTemplateCallStatus to set
	 */
	public void setWexTemplateCallStatus(String wexTemplateCallStatus) {
		this.wexTemplateCallStatus = wexTemplateCallStatus;
	}

	
	/**
	 * @return the wexDataExtractionCallStatus
	 */
	public String getWexDataExtractionCallStatus() {
		return wexDataExtractionCallStatus;
	}

	/**
	 * @param wexDataExtractionCallStatus the wexDataExtractionCallStatus to set
	 */
	public void setWexDataExtractionCallStatus(String wexDataExtractionCallStatus) {
		this.wexDataExtractionCallStatus = wexDataExtractionCallStatus;
	}

	/**
	 * @return the forwardTdStageCallStatus
	 */
	public String getForwardTdStageCallStatus() {
		return forwardTdStageCallStatus;
	}

	/**
	 * @param forwardTdStageCallStatus
	 *            the forwardTdStageCallStatus to set
	 */
	public void setForwardTdStageCallStatus(String forwardTdStageCallStatus) {
		this.forwardTdStageCallStatus = forwardTdStageCallStatus;
	}

	/**
	 * @return the forwardTdStatusCallStatus
	 */
	public String getForwardTdStatusCallStatus() {
		return forwardTdStatusCallStatus;
	}

	/**
	 * @param forwardTdStatusCallStatus
	 *            the forwardTdStatusCallStatus to set
	 */
	public void setForwardTdStatusCallStatus(String forwardTdStatusCallStatus) {
		this.forwardTdStatusCallStatus = forwardTdStatusCallStatus;
	}

	/**
	 * @return the forwardTpCallStatus
	 */
	public String getForwardTpCallStatus() {
		return forwardTpCallStatus;
	}

	/**
	 * @param forwardTpCallStatus
	 *            the forwardTpCallStatus to set
	 */
	public void setForwardTpCallStatus(String forwardTpCallStatus) {
		this.forwardTpCallStatus = forwardTpCallStatus;
	}

	/**
	 * @return the submitTpCallStatus
	 */
	public String getSubmitTpCallStatus() {
		return submitTpCallStatus;
	}

	/**
	 * @param submitTpCallStatus
	 *            the submitTpCallStatus to set
	 */
	public void setSubmitTpCallStatus(String submitTpCallStatus) {
		this.submitTpCallStatus = submitTpCallStatus;
	}

	/**
	 * @return the submitTdStageCallStatus
	 */
	public String getSubmitTdStageCallStatus() {
		return submitTdStageCallStatus;
	}

	/**
	 * @param submitTdStageCallStatus
	 *            the submitTdStageCallStatus to set
	 */
	public void setSubmitTdStageCallStatus(String submitTdStageCallStatus) {
		this.submitTdStageCallStatus = submitTdStageCallStatus;
	}

	/**
	 * @return the submitTdStatusCallStatus
	 */
	public String getSubmitTdStatusCallStatus() {
		return submitTdStatusCallStatus;
	}

	/**
	 * @param submitTdStatusCallStatus
	 *            the submitTdStatusCallStatus to set
	 */
	public void setSubmitTdStatusCallStatus(String submitTdStatusCallStatus) {
		this.submitTdStatusCallStatus = submitTdStatusCallStatus;
	}

	/**
	 * @return the submitIccFeedbackCallStatus
	 */
	public String getSubmitIccFeedbackCallStatus() {
		return submitIccFeedbackCallStatus;
	}

	/**
	 * @param submitIccFeedbackCallStatus
	 *            the submitIccFeedbackCallStatus to set
	 */
	public void setSubmitIccFeedbackCallStatus(String submitIccFeedbackCallStatus) {
		this.submitIccFeedbackCallStatus = submitIccFeedbackCallStatus;
	}

	/**
	 * @return the submitDatacapCallStatus
	 */
	public String getSubmitDatacapCallStatus() {
		return submitDatacapCallStatus;
	}

	/**
	 * @param submitDatacapCallStatus
	 *            the submitDatacapCallStatus to set
	 */
	public void setSubmitDatacapCallStatus(String submitDatacapCallStatus) {
		this.submitDatacapCallStatus = submitDatacapCallStatus;
	}

	/**
	 * @return the submitTpSyncStatus
	 */
	public String getSubmitTpSyncStatus() {
		return submitTpSyncStatus;
	}

	/**
	 * @param submitTpSyncStatus the submitTpSyncStatus to set
	 */
	public void setSubmitTpSyncStatus(String submitTpSyncStatus) {
		this.submitTpSyncStatus = submitTpSyncStatus;
	}

	
}
