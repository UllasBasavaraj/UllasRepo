package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpSubmitPreCheckTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpSubmitPreCheckTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to Submit Pre check transformer calss ");
		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		Object source = null;
		String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE, EMPTY);
		String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);
		if (message != null) {
			String input = null;
			SCBCommObj commObj = null;
			switch (flowType.toUpperCase()) {
			case FlowType.SUBMIT_DTP_SYNC:
				log.info(loggerDealId + "  -  SUBMIT_DTP_SYNC SCB Stage movement transformer...");
				try {
					source = message.getPayload();
					log.debug(loggerDealId + " source ==>" + source);
					if (source instanceof String) {
						input = (String) source;
					} else if (source instanceof InputStream) {
						input = IOUtils.toString((InputStream) source, "UTF-8");
					} else if (source instanceof SCBCommObj) {
						log.info("comm object");
						commObj = (SCBCommObj) source;
					}
					if (null != input) {
						commObj = mapper.readValue(input, SCBCommObj.class);
					}
					log.debug("commObj " + commObj.getBodySection(Sections.DTP_REQUEST_INFO));
					SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.DTP_REQUEST_INFO);
					if (null != section) {
						SCBOcrNlpDealDataObjectExtn getDealDataExtobj = new SCBOcrNlpDealDataObjectExtn();
						getDealDataExtobj = (SCBOcrNlpDealDataObjectExtn) SCBCommObjTransformer
								.sectionToSCBPojo(commObj, getDealDataExtobj);

						if (null != getDealDataExtobj
								&& (getDealDataExtobj.getResponse().equalsIgnoreCase(Fields.DTP_SYNC_SKIP))) {
							log.debug(loggerDealId + "  -  SYNC CHECK Response : " + getDealDataExtobj.getResponse());
							message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.YES);
							message.setInvocationProperty(Fields.DTP_SYNC_APPLICABLE, Fields.DTP_SYNC_SKIP);
							String defaultPayload = message.getInvocationProperty(Fields.DTP_SYNC_RESPONSE_PAYLOAD);
							vppGenericJson = defaultPayload;

						} else if (null != getDealDataExtobj
								&& getDealDataExtobj.getResponse().equalsIgnoreCase(Fields.NOT_MAKR)) {
							log.debug(loggerDealId + "  -  SYNC CHECK Response : " + getDealDataExtobj.getResponse());
							message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.NO);
							message.setInvocationProperty(Fields.DTP_SYNC_APPLICABLE, Fields.NOT_MAKR);
							String defaultPayload = message.getInvocationProperty(Fields.DTP_SYNC_RESPONSE_PAYLOAD);
							vppGenericJson = defaultPayload;

						} else if (null != getDealDataExtobj
								&& getDealDataExtobj.getResponse().equalsIgnoreCase(Fields.DTP_BATCH)) {
							log.debug(loggerDealId + "  -  SYNC CHECK Response : " + getDealDataExtobj.getResponse());
							message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.NO);
							message.setInvocationProperty(Fields.DTP_SYNC_APPLICABLE, Fields.DTP_BATCH);
							String defaultPayload = message.getInvocationProperty(Fields.DTP_SYNC_RESPONSE_PAYLOAD);
							vppGenericJson = defaultPayload;

						} else if (null != getDealDataExtobj
								&& getDealDataExtobj.getResponse().equalsIgnoreCase(Fields.DTP_SYNC)) {
							message.setInvocationProperty(Fields.PRE_CHECK_APPLICABLE, Fields.YES);
							message.setInvocationProperty(Fields.DTP_SYNC_APPLICABLE, Fields.DTP_SYNC);

							String payload = "{ \"countrycode\" : \"" + getDealDataExtobj.getCountry() + "\" , ";
							payload = payload + " \"customerid\" : \"" + getDealDataExtobj.getClientId() + "\" , ";
							payload = payload + " \"regtimestamp\" : \"" + getDealDataExtobj.getRegTimeStamp()
									+ "\" , ";
							payload = payload + " \"tdApplicationReferenceId\" : \""
									+ getDealDataExtobj.getTdApplicationReferenceId() + "\" , ";
							payload = payload + " \"productId\" : \"" + getDealDataExtobj.getProductId() + "\" , ";
							payload = payload + " \"stepId\" : \"" + getDealDataExtobj.getStepId() + "\" , ";
							payload = payload + " \"flowType\" : \"" + FlowType.SUBMIT_DTP_SYNC + "\" , ";
							payload = payload + " \"dtpBatchWindow\" : \"NO\" , ";
							payload = payload + " \"dealid\" : \"" + getDealDataExtobj.getDealId() + "\" } ";
							vppGenericJson = payload;
						}
					}
					log.debug(" SUBMIT_DTP_SYNC vppGenericJson " + vppGenericJson);
				} catch (Exception e) {
					throw new TransformerException(CoreMessages.createStaticMessage(
							loggerDealId + " -  Unable to perform transformation of the DTP Sync check level" + input),
							e);
				}
				break;

			default:
				log.info(loggerDealId + "  -  SUBMIT_DTP_SYNC No Match in the Transformer");
			}
		}
		return vppGenericJson;
	}
}
