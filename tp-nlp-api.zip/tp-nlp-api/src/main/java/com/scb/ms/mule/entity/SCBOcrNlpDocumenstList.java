package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

public class SCBOcrNlpDocumenstList {

	@Id
	private String id;
	private String filenetDocumentId;
	private String documentStatus;
	private List<SCBOcrNlpDocumentPagesList> documentPagesList = new ArrayList<SCBOcrNlpDocumentPagesList>();
	@Transient
	private int documentCharacterPosition;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the filenetDocumentId
	 */
	public String getFilenetDocumentId() {
		return filenetDocumentId;
	}

	/**
	 * @param filenetDocumentId
	 *            the filenetDocumentId to set
	 */
	public void setFilenetDocumentId(String filenetDocumentId) {
		this.filenetDocumentId = filenetDocumentId;
	}

	/**
	 * @return the documentStatus
	 */
	public String getDocumentStatus() {
		return documentStatus;
	}

	/**
	 * @param documentStatus
	 *            the documentStatus to set
	 */
	public void setDocumentStatus(String documentStatus) {
		this.documentStatus = documentStatus;
	}

	/**
	 * @return the documentPagesList
	 */
	public List<SCBOcrNlpDocumentPagesList> getDocumentPagesList() {
		return documentPagesList;
	}

	/**
	 * @param documentPagesList
	 *            the documentPagesList to set
	 */
	public void setDocumentPagesList(List<SCBOcrNlpDocumentPagesList> documentPagesList) {
		this.documentPagesList = documentPagesList;
	}

	/**
	 * @return the documentCharacterPosition
	 */
	public int getDocumentCharacterPosition() {
		return documentCharacterPosition;
	}

	/**
	 * @param documentCharacterPosition
	 *            the documentCharacterPosition to set
	 */
	public void setDocumentCharacterPosition(int documentCharacterPosition) {
		this.documentCharacterPosition = documentCharacterPosition;
	}

}
