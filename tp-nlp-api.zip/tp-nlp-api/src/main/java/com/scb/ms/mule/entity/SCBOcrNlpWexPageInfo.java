package com.scb.ms.mule.entity;

public class SCBOcrNlpWexPageInfo {

	private String documentId = "";
	private String dealId = "";
	private String rescanDocNumber = "";

	/**
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId
	 *            the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the rescanDocNumber
	 */
	public String getRescanDocNumber() {
		return rescanDocNumber;
	}

	/**
	 * @param rescanDocNumber
	 *            the rescanDocNumber to set
	 */
	public void setRescanDocNumber(String rescanDocNumber) {
		this.rescanDocNumber = rescanDocNumber;
	}
}
