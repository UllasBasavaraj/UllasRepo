package com.scb.ms.mule.entity;

public class SCBOcrNlpOTPOtherParties {

	private String addlPartyRole = "";
	private String addlPartyName = "";

	/**
	 * @return the addlPartyRole
	 */
	public String getAddlPartyRole() {
		return addlPartyRole;
	}

	/**
	 * @param addlPartyRole
	 *            the addlPartyRole to set
	 */
	public void setAddlPartyRole(String addlPartyRole) {
		this.addlPartyRole = addlPartyRole;
	}

	/**
	 * @return the addlPartyName
	 */
	public String getAddlPartyName() {
		return addlPartyName;
	}

	/**
	 * @param addlPartyName
	 *            the addlPartyName to set
	 */
	public void setAddlPartyName(String addlPartyName) {
		this.addlPartyName = addlPartyName;
	}
}
