package com.scb.ms.mule.entity;

public class SCBOcrNlpDTPPartyDetails {

	private String partyRole = "";
	private String partyName = "";
	private String partyId = "";
	private String partyExtId = "";
	private SCBOcrNlpDTPAddressDetails address = new SCBOcrNlpDTPAddressDetails();
	private String relatedParty = "N";
	private String swiftBICCode = "";
	private String actionCode = "";

	/**
	 * @return the partyRole
	 */
	public String getPartyRole() {
		return partyRole;
	}

	/**
	 * @param partyRole
	 *            the partyRole to set
	 */
	public void setPartyRole(String partyRole) {
		this.partyRole = partyRole;
	}

	/**
	 * @return the partyName
	 */
	public String getPartyName() {
		return partyName;
	}

	/**
	 * @param partyName
	 *            the partyName to set
	 */
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}

	/**
	 * @return the partyId
	 */
	public String getPartyId() {
		return partyId;
	}

	/**
	 * @param partyId
	 *            the partyId to set
	 */
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	/**
	 * @return the partyExtId
	 */
	public String getPartyExtId() {
		return partyExtId;
	}

	/**
	 * @param partyExtId
	 *            the partyExtId to set
	 */
	public void setPartyExtId(String partyExtId) {
		this.partyExtId = partyExtId;
	}

	/**
	 * @return the address
	 */
	public SCBOcrNlpDTPAddressDetails getAddress() {
		return address;
	}

	/**
	 * @param address
	 *            the address to set
	 */
	public void setAddress(SCBOcrNlpDTPAddressDetails address) {
		this.address = address;
	}

	/**
	 * @return the relatedParty
	 */
	public String getRelatedParty() {
		return relatedParty;
	}

	/**
	 * @param relatedParty
	 *            the relatedParty to set
	 */
	public void setRelatedParty(String relatedParty) {
		this.relatedParty = relatedParty;
	}

	/**
	 * @return the swiftBICCode
	 */
	public String getSwiftBICCode() {
		return swiftBICCode;
	}

	/**
	 * @param swiftBICCode
	 *            the swiftBICCode to set
	 */
	public void setSwiftBICCode(String swiftBICCode) {
		this.swiftBICCode = swiftBICCode;
	}

	/**
	 * @return the actionCode
	 */
	public String getActionCode() {
		return actionCode;
	}

	/**
	 * @param actionCode
	 *            the actionCode to set
	 */
	public void setActionCode(String actionCode) {
		this.actionCode = actionCode;
	}

}
