package com.scb.ms.mule.entity;

public class SCBOcrNlpPlaceDetails {

	private String receipt = "";
	private String receiptCountry = "";
	private String finalDestinaton = "";
	private String finalDestinationCountry = "";

	/**
	 * @return the receipt
	 */
	public String getReceipt() {
		return receipt;
	}

	/**
	 * @param receipt
	 *            the receipt to set
	 */
	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	/**
	 * @return the receiptCountry
	 */
	public String getReceiptCountry() {
		return receiptCountry;
	}

	/**
	 * @param receiptCountry
	 *            the receiptCountry to set
	 */
	public void setReceiptCountry(String receiptCountry) {
		this.receiptCountry = receiptCountry;
	}

	/**
	 * @return the finalDestinaton
	 */
	public String getFinalDestinaton() {
		return finalDestinaton;
	}

	/**
	 * @param finalDestinaton
	 *            the finalDestinaton to set
	 */
	public void setFinalDestinaton(String finalDestinaton) {
		this.finalDestinaton = finalDestinaton;
	}

	/**
	 * @return the finalDestinationCountry
	 */
	public String getFinalDestinationCountry() {
		return finalDestinationCountry;
	}

	/**
	 * @param finalDestinationCountry
	 *            the finalDestinationCountry to set
	 */
	public void setFinalDestinationCountry(String finalDestinationCountry) {
		this.finalDestinationCountry = finalDestinationCountry;
	}

}
