package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.datatypes.SCBDataTable;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpFetchDealObjectTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpFetchDealObjectTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;
	private static String dealDataList = "dealDataList";
	private static String countryStr = "country";
	private static String dealIdStr = "dealId";
	private static String stepIdStr = "stepId";
	private static String tdApplicationReferenceIdStr = "tdApplicationReferenceId";
	private static String clientIdStr = "clientId";
	private static String productIdStr = "productId";
	private static String sysStatusStr = "sysStatus";
	private static String regTimeStampStr = "regTimeStamp";
	private static String dealReleasedStatus = "dealReleasedStatus";

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBOcrNlpFetchDealObjectTransformer calss ");
		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		Object source = null;
		String checkScreenName = message.getInvocationProperty(Fields.CHECK_SCREEN_NAME, EMPTY);
		String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);

		try {
			if (StringUtils.isNotBlank(checkScreenName)
					&& checkScreenName.equalsIgnoreCase(Fields.SCREEN_MAIN_SCREEN)) {
				source = message.getPayload();
				String input = null;
				SCBCommObj commObj = null;
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.SCB_UPDATE_AND_GET_DEAL));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.SCB_UPDATE_AND_GET_DEAL);
				if (null != section) {
					commObj.getBody().addSection(Sections.DEAL_OBJECT, section);
					commObj.getBody().removeSectoin(Sections.SCB_UPDATE_AND_GET_DEAL);
					SCBDataTable tableData = section.getTableValue(dealDataList);
					if(null != tableData){
						String countryCode = (String)tableData.getRowAt(0).get(countryStr);
						String dealId = (String)tableData.getRowAt(0).get(dealIdStr);
						String stepId = (String)tableData.getRowAt(0).get(stepIdStr);
						String tdApplicationReferenceId = (String)tableData.getRowAt(0).get(tdApplicationReferenceIdStr);
						String clientId = (String)tableData.getRowAt(0).get(clientIdStr);
						String productId = (String)tableData.getRowAt(0).get(productIdStr);
						boolean sysStatus = (Boolean)tableData.getRowAt(0).get(sysStatusStr);
						String regTimeStamp = (String)tableData.getRowAt(0).get(regTimeStampStr);
						String dealReleased = (String)tableData.getRowAt(0).get(dealReleasedStatus);
						message.setInvocationProperty(Fields.DEAL_RELEASED, dealReleased);

						String payload = "{ \"countrycode\" : \"" + countryCode + "\" , ";
						payload = payload + " \"customerid\" : \"" + clientId + "\" , ";
						payload = payload + " \"regtimestamp\" : \"" + regTimeStamp + "\" , ";
						payload = payload + " \"tdApplicationReferenceId\" : \"" + tdApplicationReferenceId + "\" , ";
						payload = payload + " \"productId\" : \"" + productId + "\" , ";
						payload = payload + " \"stepId\" : \"" + stepId + "\" , ";
						payload = payload + " \"flowType\" : \"" + FlowType.ADHOC_DTP_SYNC + "\" , ";
						if (sysStatus) {
							payload = payload + " \"dtpBatchWindow\" : \"NO\" , ";
						} else {
							payload = payload + " \"dtpBatchWindow\" : \"YES\" , ";
						}
						payload = payload + " \"dealid\" : \"" + dealId + "\" } ";

						vppGenericJson = payload;
					}
					log.debug(loggerDealId + " vppGenericJson SCBOcrNlpFetchDealObjectTransformer Request " + vppGenericJson);
				}
			}
		} catch (Exception e) {
			log.error(loggerDealId + " SCBOcrNlpFetchDealObjectTransformer Failed : "+e);
		}
		return vppGenericJson;
	}


}
