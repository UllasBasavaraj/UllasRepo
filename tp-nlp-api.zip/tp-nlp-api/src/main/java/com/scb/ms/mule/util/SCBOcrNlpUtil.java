package com.scb.ms.mule.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.HttpEmailHeadersValue;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.HttpHeadersValue;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.HttpTDHeadersValue;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;

public class SCBOcrNlpUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOcrNlpUtil.class);
	private static final String DATE_TIME_FORMAT_AS_STRING = "dd-MMM-yyyy HH:mm:ss";
	private static final String CURR_DATE_FORMAT = "yyyyMMdd-hhmmss";
	private static final String TD_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss" + "+08:00";

	public static SCBHeader createSCBNlpHeaderObject(String moduleCode) {

		SCBHeader object = new SCBHeader();
		object.setUUID(UUID.randomUUID().toString());
		object.setServiceName(HttpHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(ModuleFunctionCodes.INITIATE_NLP_PROCESS_MODULE);
		object.setBankGroupCode(HttpHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	public static SCBHeader createSCBNlpFileHeaderObject(String moduleCode) {

		SCBHeader object = new SCBHeader();
		object.setUUID(UUID.randomUUID().toString());
		object.setServiceName(HttpHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(ModuleFunctionCodes.INITIATE_NLP_ENRICH_LAYOUT);
		object.setBankGroupCode(HttpHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	public static SCBHeader createSCBFileNetHeaderObject(String moduleCode) {

		SCBHeader object = new SCBHeader();
		object.setUUID(UUID.randomUUID().toString());
		object.setServiceName(HttpTDHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(HttpTDHeadersValue.COMMOBJ_MODULE_FUNCTION_CODE);
		object.setBankGroupCode(HttpTDHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpTDHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpTDHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpTDHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpTDHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpTDHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpTDHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpTDHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	public static String getTDTimeStamp(String regTimeStamp) {
		String tdFormatDate = "";

		try {
			SimpleDateFormat dateFormatter = new SimpleDateFormat(DATE_TIME_FORMAT_AS_STRING);
			Date requestDate = dateFormatter.parse(regTimeStamp);
			SimpleDateFormat tdFormat = new SimpleDateFormat(TD_DATE_FORMAT);
			tdFormatDate = tdFormat.format(requestDate);
			LOGGER.info("DTP Input date : " + regTimeStamp + " Converted into TD format date : " + tdFormatDate);
		} catch (ParseException e) {
			tdFormatDate = "";
			LOGGER.error("Parse date from DTP format to TD format :: " + e.getMessage(), e);
		}
		return tdFormatDate;
	}

	public static String getWTPRGTimeStamp(String regTimeStamp) {
		String tdFormatDate = "";

		try {
			SimpleDateFormat tdFormat = new SimpleDateFormat(TD_DATE_FORMAT);
			Date requestDate = tdFormat.parse(regTimeStamp);

			SimpleDateFormat dateFormatter = new SimpleDateFormat(DATE_TIME_FORMAT_AS_STRING);
			tdFormatDate = dateFormatter.format(requestDate).toUpperCase();

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return tdFormatDate;
	}

	public static String getCurrDate() {
		SimpleDateFormat dateFormatter = new SimpleDateFormat(CURR_DATE_FORMAT);
		String tdFormatDate = dateFormatter.format(new Date());
		return tdFormatDate;
	}

	public static SCBHeader createSCBProcesedTemplateFeedbackHeaderObject(String moduleCode) {

		SCBHeader object = new SCBHeader();
		object.setUUID(UUID.randomUUID().toString());
		object.setServiceName(HttpHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(ModuleFunctionCodes.PROCESSED_TEMPLATE_FEEDBACK);
		object.setBankGroupCode(HttpHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	public static SCBHeader createSCBDTPFetchHeaderObject(String moduleCode) {

		SCBHeader object = new SCBHeader();
		object.setUUID(UUID.randomUUID().toString());
		object.setServiceName(HttpHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(ModuleFunctionCodes.UPDATE_DTP_OLD_PARTIES);
		object.setBankGroupCode(HttpHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	public static SCBHeader createEmailHeaderObject(String moduleCode) {

		SCBHeader object = new SCBHeader();
		object.setUUID(HttpEmailHeadersValue.COMMOBJ_UUID);
		object.setServiceName(HttpEmailHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(HttpEmailHeadersValue.COMMOBJ_MODULE_FUNCTION_CODE);
		object.setBankGroupCode(HttpEmailHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpEmailHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpEmailHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpEmailHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpEmailHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpEmailHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpEmailHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpEmailHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	// TNLP-976
	public static SCBHeader createSCBUpdateWEXFeedbackProcessHeaderObject(String moduleCode) {
		return createPreFormatHeader(ModuleFunctionCodes.UPDATE_WEX_FEEDBACK_PROCESS, moduleCode);
	}

	// TNLP-959
	public static SCBHeader createSCBUpdateWEXServerStatusHeaderObject(String moduleCode) {
		return createPreFormatHeader(ModuleFunctionCodes.UPDATE_WEX_SERVER_STATUS, moduleCode);
	}

	// TNLP-976
	public static SCBHeader createSCBUpdateWEXDictEntriesProcessedHeaderObject(String moduleCode) {
		return createPreFormatHeader(ModuleFunctionCodes.UPDATE_WEX_TO_PROCESSED_DICT, moduleCode);
	}

	public static SCBHeader createSCBDataCapFeedbackResponseHeaderObject(String moduleCode) {
		return createPreFormatHeader(ModuleFunctionCodes.FINAL_SUBMIT_DATACAP_RES, moduleCode);
	}

	public static SCBHeader createSCBProcessWEXTemplateResultsHeaderObject(String moduleCode) {
		return createPreFormatHeader(ModuleFunctionCodes.PROCESS_WEX_TEMPLATE_RESULTS, moduleCode);
	}

	public static SCBHeader createSCBDealReleaseHeaderObject(String moduleCode) {
		return createPreFormatHeader(ModuleFunctionCodes.DEAL_STATUS_RELEASED_MODULE, moduleCode);
	}

	private static SCBHeader createPreFormatHeader(String moduleFunction, String moduleCode) {
		SCBHeader object = new SCBHeader();
		object.setUUID(UUID.randomUUID().toString());
		object.setServiceName(HttpHeadersValue.COMMOBJ_OCR_NLP_SERVICE_NAME);
		object.setModuleCode(moduleCode);
		object.setModuleFunctionCode(moduleFunction);
		object.setBankGroupCode(HttpHeadersValue.COMMOBJ_BANK_GROUP_CODE);
		object.setCtyCode(HttpHeadersValue.COMMOBJ_CTY_CODE);
		object.setFromSysCode(HttpHeadersValue.COMMOBJ_FROM_SYS_CODE);
		object.setToSysCode(HttpHeadersValue.COMMOBJ_TO_SYS_CODE);
		object.setUserId(HttpHeadersValue.COMMOBJ_USER_ID);
		object.setCommand(HttpHeadersValue.COMMOBJ_COMMAND);
		object.setEventStep(HttpHeadersValue.COMMOBJ_EVENT_STEP);
		object.setDirection(HttpHeadersValue.COMMOBJ_DIRECTION);

		return object;
	}

	public static String formatDateTimeAsString(Date dateTime) {

		if (dateTime != null) {
			SimpleDateFormat dateTimeFormatter = new SimpleDateFormat(DATE_TIME_FORMAT_AS_STRING);

			try {
				String fomatedDate = dateTimeFormatter.format(dateTime);
				return fomatedDate.toUpperCase();
			} catch (Exception e) {
				LOGGER.error("Invalid date format. ", e);
			}
		}

		return "";
	}

}
