package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpUpdateFinalDeal extends SCBOcrNlpDealSubStatus {

	private String tpForwardFlowStartTime;
	private String tpForwardFlowEndTime;
	private String tdForwardFlowStartTime;
	private String tdForwardFlowEndTime;
	private String logDealId;
	private String logCountryCode;
	private String logRegTimeStamp;
	private String logTdApplicationReferenceId;
	private String logFlowType;
	private String digitizerStatus;
	private String productId;
	private String clientId;
	private String stepId;
	private String tpSubmitFlowStartTime;
	private String tpSubmitFlowEndTime;
	private String tdSubmitFlowStartTime;
	private String tdSubmitFlowEndTime;
	private String datacapFeedbackFlowStartTime;
	private String datacapFeedbackFlowEndTime;
	private String datacapFeedbackStatus;
	private List<SCBOcrNlpDTPFetchPartyDetails> partyDetailsList = new ArrayList<SCBOcrNlpDTPFetchPartyDetails>();

	/**
	 * @return the tpForwardFlowStartTime
	 */
	public String getTpForwardFlowStartTime() {
		return tpForwardFlowStartTime;
	}

	/**
	 * @param tpForwardFlowStartTime
	 *            the tpForwardFlowStartTime to set
	 */
	public void setTpForwardFlowStartTime(String tpForwardFlowStartTime) {
		this.tpForwardFlowStartTime = tpForwardFlowStartTime;
	}

	/**
	 * @return the tpForwardFlowEndTime
	 */
	public String getTpForwardFlowEndTime() {
		return tpForwardFlowEndTime;
	}

	/**
	 * @param tpForwardFlowEndTime
	 *            the tpForwardFlowEndTime to set
	 */
	public void setTpForwardFlowEndTime(String tpForwardFlowEndTime) {
		this.tpForwardFlowEndTime = tpForwardFlowEndTime;
	}

	/**
	 * @return the tdForwardFlowStartTime
	 */
	public String getTdForwardFlowStartTime() {
		return tdForwardFlowStartTime;
	}

	/**
	 * @param tdForwardFlowStartTime
	 *            the tdForwardFlowStartTime to set
	 */
	public void setTdForwardFlowStartTime(String tdForwardFlowStartTime) {
		this.tdForwardFlowStartTime = tdForwardFlowStartTime;
	}

	/**
	 * @return the tdForwardFlowEndTime
	 */
	public String getTdForwardFlowEndTime() {
		return tdForwardFlowEndTime;
	}

	/**
	 * @param tdForwardFlowEndTime
	 *            the tdForwardFlowEndTime to set
	 */
	public void setTdForwardFlowEndTime(String tdForwardFlowEndTime) {
		this.tdForwardFlowEndTime = tdForwardFlowEndTime;
	}

	/**
	 * @return the logDealId
	 */
	public String getLogDealId() {
		return logDealId;
	}

	/**
	 * @param logDealId
	 *            the logDealId to set
	 */
	public void setLogDealId(String logDealId) {
		this.logDealId = logDealId;
	}

	/**
	 * @return the logCountryCode
	 */
	public String getLogCountryCode() {
		return logCountryCode;
	}

	/**
	 * @param logCountryCode
	 *            the logCountryCode to set
	 */
	public void setLogCountryCode(String logCountryCode) {
		this.logCountryCode = logCountryCode;
	}

	/**
	 * @return the logRegTimeStamp
	 */
	public String getLogRegTimeStamp() {
		return logRegTimeStamp;
	}

	/**
	 * @param logRegTimeStamp
	 *            the logRegTimeStamp to set
	 */
	public void setLogRegTimeStamp(String logRegTimeStamp) {
		this.logRegTimeStamp = logRegTimeStamp;
	}

	/**
	 * @return the logTdApplicationReferenceId
	 */
	public String getLogTdApplicationReferenceId() {
		return logTdApplicationReferenceId;
	}

	/**
	 * @param logTdApplicationReferenceId
	 *            the logTdApplicationReferenceId to set
	 */
	public void setLogTdApplicationReferenceId(String logTdApplicationReferenceId) {
		this.logTdApplicationReferenceId = logTdApplicationReferenceId;
	}

	/**
	 * @return the logFlowType
	 */
	public String getLogFlowType() {
		return logFlowType;
	}

	/**
	 * @param logFlowType
	 *            the logFlowType to set
	 */
	public void setLogFlowType(String logFlowType) {
		this.logFlowType = logFlowType;
	}

	/**
	 * @return the digitizerStatus
	 */
	public String getDigitizerStatus() {
		return digitizerStatus;
	}

	/**
	 * @param digitizerStatus
	 *            the digitizerStatus to set
	 */
	public void setDigitizerStatus(String digitizerStatus) {
		this.digitizerStatus = digitizerStatus;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the tpSubmitFlowStartTime
	 */
	public String getTpSubmitFlowStartTime() {
		return tpSubmitFlowStartTime;
	}

	/**
	 * @param tpSubmitFlowStartTime
	 *            the tpSubmitFlowStartTime to set
	 */
	public void setTpSubmitFlowStartTime(String tpSubmitFlowStartTime) {
		this.tpSubmitFlowStartTime = tpSubmitFlowStartTime;
	}

	/**
	 * @return the tpSubmitFlowEndTime
	 */
	public String getTpSubmitFlowEndTime() {
		return tpSubmitFlowEndTime;
	}

	/**
	 * @param tpSubmitFlowEndTime
	 *            the tpSubmitFlowEndTime to set
	 */
	public void setTpSubmitFlowEndTime(String tpSubmitFlowEndTime) {
		this.tpSubmitFlowEndTime = tpSubmitFlowEndTime;
	}

	/**
	 * @return the tdSubmitFlowStartTime
	 */
	public String getTdSubmitFlowStartTime() {
		return tdSubmitFlowStartTime;
	}

	/**
	 * @param tdSubmitFlowStartTime
	 *            the tdSubmitFlowStartTime to set
	 */
	public void setTdSubmitFlowStartTime(String tdSubmitFlowStartTime) {
		this.tdSubmitFlowStartTime = tdSubmitFlowStartTime;
	}

	/**
	 * @return the tdSubmitFlowEndTime
	 */
	public String getTdSubmitFlowEndTime() {
		return tdSubmitFlowEndTime;
	}

	/**
	 * @param tdSubmitFlowEndTime
	 *            the tdSubmitFlowEndTime to set
	 */
	public void setTdSubmitFlowEndTime(String tdSubmitFlowEndTime) {
		this.tdSubmitFlowEndTime = tdSubmitFlowEndTime;
	}

	/**
	 * @return the datacapFeedbackFlowStartTime
	 */
	public String getDatacapFeedbackFlowStartTime() {
		return datacapFeedbackFlowStartTime;
	}

	/**
	 * @param datacapFeedbackFlowStartTime
	 *            the datacapFeedbackFlowStartTime to set
	 */
	public void setDatacapFeedbackFlowStartTime(String datacapFeedbackFlowStartTime) {
		this.datacapFeedbackFlowStartTime = datacapFeedbackFlowStartTime;
	}

	/**
	 * @return the datacapFeedbackFlowEndTime
	 */
	public String getDatacapFeedbackFlowEndTime() {
		return datacapFeedbackFlowEndTime;
	}

	/**
	 * @param datacapFeedbackFlowEndTime
	 *            the datacapFeedbackFlowEndTime to set
	 */
	public void setDatacapFeedbackFlowEndTime(String datacapFeedbackFlowEndTime) {
		this.datacapFeedbackFlowEndTime = datacapFeedbackFlowEndTime;
	}

	/**
	 * @return the datacapFeedbackStatus
	 */
	public String getDatacapFeedbackStatus() {
		return datacapFeedbackStatus;
	}

	/**
	 * @param datacapFeedbackStatus
	 *            the datacapFeedbackStatus to set
	 */
	public void setDatacapFeedbackStatus(String datacapFeedbackStatus) {
		this.datacapFeedbackStatus = datacapFeedbackStatus;
	}

	/**
	 * @return the partyDetailsList
	 */
	public List<SCBOcrNlpDTPFetchPartyDetails> getPartyDetailsList() {
		return partyDetailsList;
	}

	/**
	 * @param partyDetailsList the partyDetailsList to set
	 */
	public void setPartyDetailsList(List<SCBOcrNlpDTPFetchPartyDetails> partyDetailsList) {
		this.partyDetailsList = partyDetailsList;
	}



}
