package com.scb.ms.mule.transformer;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDataObj;
import com.scb.ms.mule.entity.SCBOcrNlpDocumentPages;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealSubStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;




public class SCBOcrNlpSinglePageNLPTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpSinglePageNLPTransformer.class);
	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBSinglePageNLPTransformer calss ");
		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		String operationType = message.getInvocationProperty(Fields.SINGLE_PAGE_OPERATION_TYPE, "");
		String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, "");
		if (message != null &&  operationType.equalsIgnoreCase(Fields.PRE_DOWNLOAD)) {	
			String originalInput = message.getInvocationProperty(Fields.FILE_ORIGINAL_PAYLOAD, "");
			int iCounter = new Integer (message.getInvocationProperty(Fields.FILE_PAGE_COUNTER, "")).intValue();
			try {
				SCBOcrNlpDataObj ocrReqObj = mapper.readValue(originalInput, SCBOcrNlpDataObj.class);
				if(null != ocrReqObj && null != ocrReqObj.getDocumentPagesList()
						&& ocrReqObj.getDocumentPagesList().size() >= iCounter){

					SCBOcrNlpDocumentPages page = ocrReqObj.getDocumentPagesList().get(iCounter-1);
					String fileId = page.getLayoutXml();
					String countryCode = ocrReqObj.getCountry();
					if(null != fileId && fileId.length() > 0 && fileId.length() < 50 ){
						message.setInvocationProperty(Fields.SINGLE_PAGE_DOWNLOADABLE, "TRUE");
					}
					
					message.setInvocationProperty(Fields.SINGLE_PAGE_FILEID, fileId);
					message.setInvocationProperty(Fields.SINGLE_PAGE_COUNTRY_CODE, countryCode);
				}
				vppGenericJson = "";
			}catch (Exception e) {
				log.error(loggerDealId + " - error in SCBSinglePageNLPTransformer Pre Download Json Transformation"+e);
				throw new TransformerException(CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" ), e);
			}
		} 
		else if (message != null &&  operationType.equalsIgnoreCase(Fields.POST_DOWNLOAD)) {	
			String originalInput = message.getInvocationProperty(Fields.FILE_ORIGINAL_PAYLOAD, "");
			String datacapScanId = message.getInvocationProperty(Fields.DATACAP_SCANID, "");
			int iCounter = new Integer (message.getInvocationProperty(Fields.FILE_PAGE_COUNTER, "")).intValue();
			try {
				SCBOcrNlpDataObj ocrReqObj = mapper.readValue(originalInput, SCBOcrNlpDataObj.class);
				ocrReqObj.setId(datacapScanId);
				Object source = message.getPayload();
				String input = "";
				
		    	SCBCommObj rqstObj = new SCBCommObj();
		    	SCBHeader scbHeader = new SCBHeader();
				SCBFooter scbFooter = new SCBFooter();					
				scbHeader = SCBOcrNlpUtil.createSCBNlpFileHeaderObject(ModuleCodes.FORWARD);
		    	rqstObj.setHeader(scbHeader);			
		    	rqstObj.setFooter(scbFooter);
				
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else {
					log.error(loggerDealId + " Unrecognised Format error in Single Page Post processor ");
					throw new TransformerException(CoreMessages.createStaticMessage("Unable to Recognize the Format from File API" ));
				}
				
				if(null != ocrReqObj && null != ocrReqObj.getDocumentPagesList()
						&& ocrReqObj.getDocumentPagesList().size() >= iCounter){

					SCBOcrNlpDocumentPages page = ocrReqObj.getDocumentPagesList().get(iCounter-1);
					page.setLayoutXml(input);
					ocrReqObj.getDocumentPagesList().clear();
					ocrReqObj.getDocumentPagesList().add(page);
					
					rqstObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(ocrReqObj, SCBOcrNlpDataObj.class));
					vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rqstObj);
				    log.debug(loggerDealId + " - genericJson json ==>" + vppGenericJson);

				}
			}catch (Exception e) {
				log.error(loggerDealId + " - error in SCBSinglePageNLPTransformer Post Download Json Transformation"+e);
				throw new TransformerException(CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" ), e);
			}
		}
		else if (message != null &&  operationType.equalsIgnoreCase(Fields.POST_SAVE)) {	

			try {

				Object source = message.getPayload();
				String input = null;
				SCBCommObj commObj = null;
				
		    	log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("source instance of comm obj");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					log.debug("input request :::   ==>" + input);
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.INITIATE_NLP_PROCESS);
				String status = section.getStringData().get(Fields.STATUS);
				if(StringUtils.isNotEmpty(status) && status.equalsIgnoreCase("Failed")){
					message.setInvocationProperty(Fields.FILE_OPER_STATUS, DealSubStatus.FAILED);
				}
				
				vppGenericJson = "";

			}catch (Exception e) {
				log.error(loggerDealId + " - error in SCBSinglePageNLPTransformer Post Download Json Transformation"+e);
				throw new TransformerException(CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" ), e);
			}
		}
		return vppGenericJson;
	}
	
		private static void generateTechnicalErrorMsg(SCBFooter scbFooter, String errorCode, String errorTitle, String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
		}
		

}
