package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.transformer.exception.SCBTransformException;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpDatacapFeedbackResponse;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpDataCapFeedbackResponseToNlpTransformer extends AbstractMessageTransformer {

	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpDataCapFeedbackResponseToNlpTransformer.class);

	private static final String DEAL_ID = "dealId";
	private static final String COUNTRY = "country";
	private static final String STEP_ID = "stepId";
	private static final String CUSTOMER_ID = "customerId";
	private static final String PRODUCT_ID = "productId";
	private static final String SYSTEM_CODE = "systemCode";
	private static final String TP_APPL_REF_NO = "tdApplicationReferenceId";
	private static final String REG_TIMESTAMP = "regTimeStamp";
	private static final String DATACAP_FEEDBACK_ST = Fields.DATACAP_FEEDBACK_ST;
	private static final String DATACAP_FEEDBACK_ET = Fields.DATACAP_FEEDBACK_ET;
	private static final String DATACAP_FEEDBACK_STATUS = Fields.DATACAP_FEEDBACK_STATUS;
	
	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to Mule DataCap Feedback Response transformer class");
		
		String vppGenericJson = null;
		Object source = null;


		if(message != null){
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object scbCommObjJson = null;

			source = message.getPayload();

			try{
				log.debug("Source Mule DataCap Feedback Response transformer ==> " + source);
				String dealId = message.getInvocationProperty(Fields.DEAL_ID);
				String countryCode = message.getInvocationProperty(Fields.COUNTRY_CODE);
				String stepId = message.getInvocationProperty(Fields.STEP_ID);
				String customerId = message.getInvocationProperty(Fields.CUSTOMER_ID);
				String productId = message.getInvocationProperty(Fields.PRODUCT_ID);
				String systemCode = message.getInvocationProperty(Fields.SYSTEM_CODE);
				String tdAppRefNo = message.getInvocationProperty(Fields.TD_APP_REF_ID);
				String regTimeStamp = message.getInvocationProperty(Fields.REG_TIME_STAMP);
				String feedBackStartTime = message.getInvocationProperty(Fields.DATACAP_FEEDBACK_ST);
				String feedbackEndTime = message.getInvocationProperty(Fields.DATACAP_FEEDBACK_ET);
				String feedbackStatus = message.getInvocationProperty(Fields.DATACAP_FEEDBACK_STATUS);

		
				if(source instanceof String){
					input = (String) source;
				}
				else if(source instanceof InputStream){
					input = IOUtils.toString((InputStream) source, "UTF-8");
				}

				// create request, set header and footer
				SCBCommObj request = new SCBCommObj();
                SCBHeader requestHeader = SCBOcrNlpUtil.createSCBDataCapFeedbackResponseHeaderObject(ModuleCodes.SUBMIT);
                SCBFooter requestFooter = new SCBFooter();
                request.setHeader(requestHeader);
                request.setFooter(requestFooter);
                
				// set the request body
				try{
					SCBOcrNlpDatacapFeedbackResponse dataCapFeedbackResponse = null; 

					if ( input != null &&  !"".equals(input) ){
						dataCapFeedbackResponse = mapper.readValue(input, SCBOcrNlpDatacapFeedbackResponse.class);
					} else {
						log.info("DataCap Creating new Object SCBDatacapFeedbackResponse as Payload from DataCap Server response is EMPTY");
						dataCapFeedbackResponse = new SCBOcrNlpDatacapFeedbackResponse();
					}
					
					request.getBody().addSection(SCBCommObjTransformer.pojoToSection(dataCapFeedbackResponse, Sections.FINAL_SUBMIT_DATACAP_RES_SECTION));
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(DEAL_ID, dealId);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(COUNTRY, countryCode);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(STEP_ID, stepId);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(CUSTOMER_ID, customerId);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(PRODUCT_ID, productId);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(SYSTEM_CODE, systemCode);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(TP_APPL_REF_NO, tdAppRefNo);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(REG_TIMESTAMP, regTimeStamp);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(DATACAP_FEEDBACK_ST, feedBackStartTime);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(DATACAP_FEEDBACK_ET, feedbackEndTime);
					request.getBody().getSection(Sections.FINAL_SUBMIT_DATACAP_RES_SECTION).putStringValue(DATACAP_FEEDBACK_STATUS, feedbackStatus);
				}
				catch (SCBTransformException e){
					e.printStackTrace();
					generateTechnicalErrorMessage(requestFooter, "400", "Invalid Request", "Invalid request, missing or invalid data.");
				}

				// create JSON string
				scbCommObjJson = request;
				log.debug("Generic JSON ==> " + scbCommObjJson.toString());
				vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(scbCommObjJson);
				log.debug("Initial data from  DataCap Feedback Response JSON ==> " + vppGenericJson);

				return vppGenericJson;
			}
			catch (Exception e){
				throw new TransformerException(CoreMessages.createStaticMessage("Error in SCBDataCapFeedbackResponseToNlpTransformer: " + source), e);
			}
		}
		
		return null;
	}

	private static void generateTechnicalErrorMessage(SCBFooter requestFooter, String errorCode, String errorTitle, String errorMessage) {
		SCBValidationErrorResult scbValidationErrorCode = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMessage = new SCBValidationErrorResult(errorMessage, "errorMessage", null);
		requestFooter.addError(scbValidationErrorCode);
		requestFooter.addError(scbValidationErrorTitle);
		requestFooter.addError(scbValidationErrorMessage);
	}
}
