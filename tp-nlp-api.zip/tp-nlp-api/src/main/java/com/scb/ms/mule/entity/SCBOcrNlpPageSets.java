package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Transient;

public class SCBOcrNlpPageSets {

	private String setIds;
	private List<SCBOcrNlpSetDetails> setDetailList = new ArrayList<SCBOcrNlpSetDetails>();
	@Transient
	private boolean pageCheckRequired;

	/**
	 * @return the setIds
	 */
	public String getSetIds() {
		return setIds;
	}

	/**
	 * @param setIds
	 *            the setIds to set
	 */
	public void setSetIds(String setIds) {
		this.setIds = setIds;
	}

	/**
	 * @return the setDetailList
	 */
	public List<SCBOcrNlpSetDetails> getSetDetailList() {
		return setDetailList;
	}

	/**
	 * @param setDetailList
	 *            the setDetailList to set
	 */
	public void setSetDetailList(List<SCBOcrNlpSetDetails> setDetailList) {
		this.setDetailList = setDetailList;
	}

	/**
	 * @return the pageCheckRequired
	 */
	public boolean getPageCheckRequired() {
		return pageCheckRequired;
	}

	/**
	 * @param pageCheckRequired
	 *            the pageCheckRequired to set
	 */
	public void setPageCheckRequired(boolean pageCheckRequired) {
		this.pageCheckRequired = pageCheckRequired;
	}

}
