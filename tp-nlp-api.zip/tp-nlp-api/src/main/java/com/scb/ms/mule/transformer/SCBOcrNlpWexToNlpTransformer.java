package com.scb.ms.mule.transformer;

import java.util.HashMap;
import java.util.Map;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpWexPageInfo;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpWexToNlpTransformer extends AbstractMessageTransformer {
	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOcrNlpWexToNlpTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		LOGGER.debug("Enter in to SCBOcrNlpWexToNlpTransformer  calss ");
		String jsonResp = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			Object genericJson = null;
			Object src = null;
			String loggerDealId = EMPTY;
			try {
				loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);
				LOGGER.debug(loggerDealId + " - source ==>" + src);
				// Create SCB Comm Object
				SCBCommObj reqObj = new SCBCommObj();
				SCBHeader header = new SCBHeader();
				SCBFooter footer = new SCBFooter();
				header = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.FORWARD);
				header.setModuleFunctionCode(ModuleFunctionCodes.APPLY_NLP);
				reqObj.setHeader(header);
				reqObj.setFooter(footer);
				try {
					String invocationProperty = message.getInvocationProperty(Fields.FINAL_WEX_PLAYLOAD, EMPTY);
					SCBOcrNlpWexPageInfo nlpWexPageInfo = mapper.readValue(invocationProperty,
							SCBOcrNlpWexPageInfo.class);
					Map<String, SCBSection> wexPageInfoMap = SCBCommObjTransformer.pojoToSection(nlpWexPageInfo,
							SCBOcrNlpWexPageInfo.class);
					SCBSection wexPageInfoSection = wexPageInfoMap.get(Sections.WEX_PAGE_INFO);
					Map<String, SCBSection> pageSecMap = new HashMap<String, SCBSection>();
					pageSecMap.put(Sections.WEX_PAGE_INFO, wexPageInfoSection);
					reqObj.getBody().addSection(pageSecMap);
				} catch (Exception e) {
					LOGGER.error(loggerDealId + " - SCBOcrNlpWexToNlpTransformer Transformer Exception " + e);
					generateTechErrMsg(footer, "400", "Invalid Request", "Invalid request, missing or invalid data.");
				}
				genericJson = reqObj;
				jsonResp = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
			} catch (Exception e) {
				LOGGER.error(loggerDealId + " - SCBOcrNlpWexToNlpTransformer Other Exception " + e);
				throw new TransformerException(
						CoreMessages.createStaticMessage(loggerDealId
								+ " - SCBOcrNlpWexToNlpTransformer Unable to transform commobj to Generic Json" + src),
						e);
			}
		}
		return jsonResp;
	}

	private static void generateTechErrMsg(SCBFooter scbFooter, String errorCode, String errorTitle, String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}

}
