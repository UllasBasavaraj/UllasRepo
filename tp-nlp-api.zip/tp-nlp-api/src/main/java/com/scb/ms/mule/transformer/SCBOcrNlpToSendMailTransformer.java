package com.scb.ms.mule.transformer;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;

import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpEmailData;
import com.scb.ms.mule.entity.SCBOcrNlpEmailStringData;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpToSendMailTransformer extends AbstractMessageTransformer {
	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOcrNlpToSendMailTransformer.class);
	private String transformerType;

	@Override
	public Object transformMessage(MuleMessage source, String arg1) throws TransformerException {
		LOGGER.info("Entered In to SCBToSendMailTransformer");

		String vppGenericJson = null;

		if (source != null) {
			ObjectMapper mapper = new ObjectMapper();
			Object genericJson = null;
			SCBCommObj commObj = null;
			String dealId;
			String stepId;
			String country;
			String regTimeStamp;
			String productId;
			String clientId;
			String systemCode;
			String triggerMail;
			String wexCallStatus;
			String wexTemplateCallStatus;
			String forwardTdStageCallStatus;
			String forwardTdStatusCallStatus;
			String forwardTpCallStatus;
			String submitTpCallStatus;
			String submitTdStageCallStatus;
			String submitTdStatusCallStatus;
			String submitIccFeedbackCallStatus;
			String submitDatacapCallStatus;
			String emailSubject;
			String emailBody;
			String flowType;
			String loggerDealId = source.getInvocationProperty("loggerDealId", "");
			try {
				String isEmailEnabled = source.getInvocationProperty("isEmailEnabled", "");
				String emailReceiver = source.getInvocationProperty("emailReceiver", "");
				String emailSender = source.getInvocationProperty("emailSender", "");

				logger.debug(loggerDealId + "isEmailEnabled : " + isEmailEnabled + " Email Receiver :" + emailReceiver
						+ " emailSender :" + emailSender);

				commObj = (SCBCommObj) source.getPayload();
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.EMAIL_RESPONSE);

				if (null != section) {
					SCBOcrNlpEmailData getEmailDataObj = new SCBOcrNlpEmailData();
					getEmailDataObj = (SCBOcrNlpEmailData) SCBCommObjTransformer.sectionToSCBPojo(commObj, getEmailDataObj);

					triggerMail = getEmailDataObj.getTriggerMail();
					LOGGER.debug(loggerDealId + " - Trigger Mail Enable::: " + getEmailDataObj.getTriggerMail());

					if (SCBOcrNlpMuleConstants.TRIGGER_MAIL.equalsIgnoreCase(triggerMail)) {

						dealId = getEmailDataObj.getDealId();
						stepId = getEmailDataObj.getStepId();
						country = getEmailDataObj.getCountry();
						regTimeStamp = getEmailDataObj.getRegTimeStamp();
						productId = getEmailDataObj.getProductId();
						clientId = getEmailDataObj.getClientId();
						systemCode = getEmailDataObj.getSystemCode();

						wexCallStatus = getEmailDataObj.getWexCallStatus();
						wexTemplateCallStatus = getEmailDataObj.getWexTemplateCallStatus();
						forwardTdStageCallStatus = getEmailDataObj.getForwardTdStageCallStatus();
						forwardTdStatusCallStatus = getEmailDataObj.getForwardTdStatusCallStatus();
						forwardTpCallStatus = getEmailDataObj.getForwardTpCallStatus();
						submitTpCallStatus = getEmailDataObj.getSubmitTpCallStatus();
						submitTdStageCallStatus = getEmailDataObj.getSubmitTdStageCallStatus();
						submitTdStatusCallStatus = getEmailDataObj.getSubmitTpCallStatus();
						submitIccFeedbackCallStatus = getEmailDataObj.getSubmitIccFeedbackCallStatus();
						submitDatacapCallStatus = getEmailDataObj.getSubmitDatacapCallStatus();
						flowType = getEmailDataObj.getFlowType();

						emailSubject = "OCR-NLP WTP Application Error in Deal - " + dealId + " (" + flowType + " FLOW)";

						logger.debug(loggerDealId + " -Deal Info --> " + dealId + " " + stepId + " " + country + " "
								+ regTimeStamp + " " + productId + " " + clientId + " " + systemCode);
						logger.debug(loggerDealId + " -Error Status " + wexCallStatus + " " + wexTemplateCallStatus + " "
								+ forwardTdStageCallStatus + " " + forwardTdStatusCallStatus + " " + forwardTpCallStatus
								+ " " + submitTpCallStatus + " " + submitTdStageCallStatus + " "
								+ submitTdStatusCallStatus + " " + submitTdStatusCallStatus + " "
								+ submitIccFeedbackCallStatus + " " + submitDatacapCallStatus);

						emailBody = "Dear Team, <br>" + "<br>"
								+ "An error has occurred in the OCR-NLP WTP Application at " + flowType
								+ " FLOW. Please find the Deal details below : " + "<br>" + "<br><b>Deal Id : </b> "
								+ dealId + "<br>" + "<b>Step Id     : </b> " + stepId + "<br>"
								+ "<b>Country     : </b> " + country + "<br>" + "<b>Registration timestamp : </b> "
								+ regTimeStamp + "<br>" + "<b>Product code : </b> " + productId + "<br>"
								+ "<b>Client ID : </b> " + clientId + "<br>" + "<b>System Code : </b> " + systemCode
								+ "<br>" + "<b>Country : </b> " + country + "<br>" + "<br>"
								+ "<b>Forward flow Status :</b> " + "<br>" + "<br>"
								+ "<b>Wex Call Status                 : </b> " + wexCallStatus + "<br>"
								+ "<b>Wex Template CallStatus         : </b> " + wexTemplateCallStatus + "<br>"
								+ "<b>Forward TD Stage Call Status    : </b> " + forwardTdStageCallStatus + "<br>"
								+ "<b>Forward TD Status Call Status   : </b> " + forwardTdStatusCallStatus + "<br>"
								+ "<b>Forward DTP Call Status          : </b> " + forwardTpCallStatus + "<br>" + "<br>"
								+ "<b>Submit flow Status :</b> " + "<br>" + "<br>" + "<b>Submit " + systemCode
								+ " Call Status           : </b> " + submitTpCallStatus + "<br>"
								+ "<b>Submit TD Stage Call Status     : </b> " + submitTdStageCallStatus + "<br>"
								+ "<b>Submit TD Status Call Status    : </b> " + submitTdStatusCallStatus + "<br>"
								+ "<b>Submit Icc Feedback Call Status : </b> " + submitIccFeedbackCallStatus + "<br>"
								+ "<b>Submit Datacap Call Status      : </b> " + submitDatacapCallStatus + "<br>";

						SCBCommObj rqstObj = new SCBCommObj();
						SCBFooter scbFooter = new SCBFooter();

						rqstObj.setHeader(SCBOcrNlpUtil.createEmailHeaderObject(ModuleCodes.SUBMIT));
						rqstObj.setFooter(scbFooter);

						SCBOcrNlpEmailStringData emailStringData = new SCBOcrNlpEmailStringData();
						emailStringData.setEmailSubject(emailSubject);
						emailStringData.setEmailReceiver(emailReceiver);
						emailStringData.setEmailSender(emailSender);
						emailStringData.setEmailBody(emailBody);

						rqstObj.getBody().addSection(SCBCommObjTransformer.pojoToSection(emailStringData,
								SCBOcrNlpMuleConstants.SECTIONNAME_EMAIL));

						genericJson = rqstObj;
						LOGGER.debug(loggerDealId + " -genericJson json ==>" + genericJson.toString());
						vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);
						LOGGER.debug(loggerDealId + " -SCB Error Email Transformer json : " + vppGenericJson);
					}
				}
			} catch (Exception e) {
				LOGGER.error(loggerDealId + " - Exception in Error email constructon " + e);
				throw new TransformerException(CoreMessages.createStaticMessage(
						loggerDealId + " -Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return vppGenericJson;
	}

	public String getTransformerType() {
		return transformerType;
	}

	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}

}
