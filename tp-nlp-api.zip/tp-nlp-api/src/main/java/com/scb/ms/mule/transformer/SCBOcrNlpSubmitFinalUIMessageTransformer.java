package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DealSubmitUIMessages;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.DigitizerStatus;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpSubmitFinalUIMessageTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpSubmitFinalUIMessageTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to Submit Sync check transformer calss ");
		String vppGenericJson = null;
		ObjectMapper mapper = new ObjectMapper();
		Object source = null;
		String flowType = message.getInvocationProperty(FlowType.FLOW_TYPE, EMPTY);
		String loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);

		if (message != null) {
			String input = null;
			SCBCommObj commObj = null;
			log.info(loggerDealId + "  -  Final UI Message Transformer.");
			try {
				source = message.getPayloadAsString();
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.info("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.SCB_FINAL_DEAL_RESPONSE));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.SCB_FINAL_DEAL_RESPONSE);
				if (null != section) {
					SCBOcrNlpDealDataObjectExtn dealDataExtobj = new SCBOcrNlpDealDataObjectExtn();
					dealDataExtobj = (SCBOcrNlpDealDataObjectExtn) SCBCommObjTransformer.sectionToSCBPojo(commObj,
							dealDataExtobj);
					String finalDealSubmitStatus = message.getInvocationProperty(Fields.DEAL_FINAL_SUBMIT_STATUS,
							EMPTY);
					String digitizerStatus = message.getInvocationProperty(Fields.DIGITIZER_STATUS, EMPTY);

					if (StringUtils.isNotBlank(finalDealSubmitStatus)) {
						if (finalDealSubmitStatus.equalsIgnoreCase(DealStatus.SUBMIT_SUCCESSFUL)) {
							// success Message
							dealDataExtobj.setResponse(DigitizerStatus.UPDATED);
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.UPDATED);
						} else {
							if (StringUtils.isNotBlank(digitizerStatus)
									&& StringUtils.contains(digitizerStatus.toUpperCase(), DigitizerStatus.TXNL)) {
								// TxnLock Message
								dealDataExtobj.setResponse(DigitizerStatus.TXNL);
								dealDataExtobj.setResponseMessage(DealSubmitUIMessages.TXNL);
							} else if (StringUtils.isNotBlank(digitizerStatus)
									&& StringUtils.contains(digitizerStatus.toUpperCase(), Fields.NOT_MAKR)) {
								// Not in Mkr Message
								dealDataExtobj.setResponse(DigitizerStatus.NOTMAKR);
								dealDataExtobj.setResponseMessage(DealSubmitUIMessages.NOTINMKR);
							} else {
								// all Techfail Message
								dealDataExtobj.setResponse(DigitizerStatus.TECHFAIL);
								dealDataExtobj.setResponseMessage(DealSubmitUIMessages.TECHFAIL);
							}
						}
					} else if (StringUtils.isBlank(finalDealSubmitStatus)) {
						String response = dealDataExtobj.getResponse();
						switch (response) {
						case DigitizerStatus.BATCH:
							// Batch Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.BATCH);
							break;
						case Fields.DTP_BATCH:
							// Batch Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.BATCH);
							break;
						case DigitizerStatus.NOTMAKR:
							// Not in mkr Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.NOTINMKR);
							break;
						case DigitizerStatus.TECHFAIL:
							// all Techfail Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.TECHFAIL);
							break;
						case Fields.EXCEL_DOWNLOAD:
							// Excel download Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.EXCEL_DOWNLOAD);
							break;
						case Fields.CHECK_INTEGRITY_FAILED:
							// Integrity Failed Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.CHECK_INTEGRITY_FAILED);
							break;
						case Fields.DEAL_OP_STATE:
							// Integrity Failed Message
							dealDataExtobj.setResponseMessage(DealSubmitUIMessages.DEAL_OP_STATE);
							break;
						default:
							log.info(loggerDealId + " -  No Equivalent UI Return Stauts" + response);
						}
					}

					commObj.removeBodySection(Sections.SCB_FINAL_DEAL_RESPONSE);
					commObj.getBody().addSection(
							SCBCommObjTransformer.pojoToSection(dealDataExtobj, SCBOcrNlpDealDataObjectExtn.class));
					vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObj);
					log.debug(loggerDealId + " -  SCBOcrNlpSubmitFinalUIMessageTransformer final json" + vppGenericJson);
				}

			} catch (Exception e) {
				throw new TransformerException(CoreMessages.createStaticMessage(loggerDealId
						+ " -  Unable to perform transformation of the SCBOcrNlpSubmitFinalUIMessageTransformer level"
						+ input), e);
			}
		}
		return vppGenericJson;
	}
}
