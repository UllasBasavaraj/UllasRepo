package com.scb.ms.mule.service;

import org.apache.log4j.Logger;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;
import org.springframework.beans.factory.annotation.Autowired;

import com.scb.ms.mule.util.SCBOcrNlpMuleCloudConfigProperties;
import com.scb.ribbon.client.SCBRegistryService;

public class SCBServiceDiscoveryLookup implements Callable {
	
	private static Logger logger = Logger.getLogger(SCBServiceDiscoveryLookup.class);
	private static final String EUREKA_ENABLED = "eureka.enable";
	private static final String EUREKA_HOST = "eureka.client.service-url.defaultZone";
	
	/*private static final String TP_CB_AUDITTXNFLATELASTIC_MS_HOST = "audittxnflatelastic.service.host";
	private static final String TP_CB_AUDITTXNFLATELASTIC_MS_PORT= "audittxnflatelastic.service.port";
	private static final String TP_CB_AUDITTXNFLATELASTIC_MS_EUREKA_ID= "TP-CB-AUDITTXNFLATELASTIC-MS";

	private static final String TP_CB_TXNFLATELASTIC_MS_HOST = "txnflatelastic.service.host";
	private static final String TP_CB_TXNFLATELASTIC_MS_PORT= "txnflatelastic.service.port";
	private static final String TP_CB_TXNFLATELASTIC_MS_EUREKA_ID= "TP-CB-TXNFLATELASTIC-MS";

	private static final String TP_CB_TIMELINEEVENTS_MS_HOST = "timelineevents.service.host";
	private static final String TP_CB_TIMELINEEVENTS_MS_PORT= "timelineevents.service.port";
	private static final String TP_CB_TIMELINEEVENTS_MS_EUREKA_ID= "TP-CB-TIMELINEEVENTS-MS";
	
	private static final String TP_UTIL_LDAP_MS_HOST = "ldap.host";
	private static final String TP_UTIL_LDAP_MS_PORT= "ldap.port";
	private static final String TP_UTIL_LDAP_MS_EUREKA_ID= "TP-UTIL-LDAP-MS";
	
	private static final String TP_CB_STATICPARTY_MS_HOST = "party.service.host";
	private static final String TP_CB_STATICPARTY_MS_PORT= "party.service.port";
	private static final String TP_CB_STATICPARTY_MS_EUREKA_ID= "TP-CB-STATICPARTY-MS";
	
	private static final String TP_CB_TRANSACTIONPRIORITY_MS_HOST = "txn.weight.service.host";
	private static final String TP_CB_TRANSACTIONPRIORITY_MS_PORT= "txn.weight.service.port";
	private static final String TP_CB_TRANSACTIONPRIORITY_MS_EUREKA_ID= "TP-CB-TRANSACTIONPRIORITY-MS";
	
	private static final String TP_CB_ALERTPOSTCREATION_MS_HOST = "alert.post.creation.service.host";
	private static final String TP_CB_ALERTPOSTCREATION_MS_PORT= "alert.post.creation.service.port";
	private static final String TP_CB_ALERTPOSTCREATION_MS_EUREKA_ID= "TP-CB-ALERTPOSTCREATION-MS";
	
	private static final String TP_CB_ALERTACTIVITY_MS_HOST = "client.behaviour.service.host";
	private static final String TP_CB_ALERTACTIVITY_MS_PORT= "client.behaviour.service.port";
	private static final String TP_CB_ALERTACTIVITY_MS_EUREKA_ID= "TP-CB-ALERTACTIVITY-MS";
	
	private static final String TP_CB_TRANSACTION_MS_HOST = "txn.service.host";
	private static final String TP_CB_TRANSACTION_MS_PORT= "txn.service.port";
	private static final String TP_CB_TRANSACTION_MS_EUREKA_ID= "TP-CB-TRANSACTION-MS";
	
	private static final String TP_CB_LOOKUP_MS_HOST = "cb.lookup.service.host";
	private static final String TP_CB_LOOKUP_MS_PORT= "cb.lookup.service.port";
	private static final String TP_CB_LOOKUP_MS_EUREKA_ID= "TP-CB-LOOKUP-MS";
	
	private static final String TP_CB_TIMELINEINQUIRY_MS_HOST = "timeline.service.host";
	private static final String TP_CB_TIMELINEINQUIRY_MS_PORT= "timeline.service.port";
	private static final String TP_CB_TIMELINEINQUIRY_MS_EUREKA_ID= "TP-CB-TIMELINEINQUIRY-MS";
	
	private static final String TP_CB_TXNENRICHMENT_MS_HOST = "cb.txnenrichment.host";
	private static final String TP_CB_TXNENRICHMENT_MS_PORT= "cb.txnenrichment.port";
	private static final String TP_CB_TXNENRICHMENT_MS_EUREKA_ID= "TP-CB-TXNENRICHMENT-MS";
	
	private static final String TP_CB_ALERTTRIGGER_MS_HOST = "alert.trigger.host";
	private static final String TP_CB_ALERTTRIGGER_MS_PORT= "alert.trigger.port";
	private static final String TP_CB_ALERTTRIGGER_MS_EUREKA_ID= "TP-CB-ALERTTRIGGER-MS";
	
	private static final String TP_CB_ALERTREASONHISTORY_MS_HOST = "alert.history.host";
	private static final String TP_CB_ALERTREASONHISTORY_MS_PORT= "alert.history.port";
	private static final String TP_CB_ALERTREASONHISTORY_MS_EUREKA_ID= "TP-CB-ALERTREASONHISTORY-MS";
	
	private static final String TP_CB_ALERTDATA_MS_HOST = "release.stage.txn.host";
	private static final String TP_CB_ALERTDATA_MS_PORT= "release.stage.txn.port";
	private static final String TP_CB_ALERTDATA_MS_EUREKA_ID= "TP-CB-ALERTDATA-MS";
	
	private static final String TP_CB_CLIENTSNAPSHOT_MS_HOST = "cb.ms.clientsnapshot.host";
	private static final String TP_CB_CLIENTSNAPSHOT_MS_PORT= "cb.ms.clientsnapshot.port";
	private static final String TP_CB_CLIENTSNAPSHOT_MS_EUREKA_ID= "TP-CB-CLIENTSNAPSHOT-MS";
	
	private static final String TP_ESR_ALERTTRIGGER_MS_HOST = "alert.trigger.esr.host";
	private static final String TP_ESR_ALERTTRIGGER_MS_PORT= "alert.trigger.esr.port";
	private static final String TP_ESR_ALERTTRIGGER_MS_EUREKA_ID= "TP-ESR-ALERTTRIGGER-MS";
	
	private static final String TP_OTP_API_HOST = "param.data.host";
	private static final String TP_OTP_API_PORT= "param.data.port";
	private static final String TP_OTP_API_EUREKA_ID= "TP-OTP-API";
	
	private static final String TP_ESR_MAILSERVICE_MS_HOST = "mail.service.host";
	private static final String TP_ESR_MAILSERVICE_MS_PORT= "mail.service.port";
	private static final String TP_ESR_MAILSERVICE_MS_EUREKA_ID= "TP-ESR-MAILSERVICE-MS";
	
	
	private static final String TP_CB_WFALERTTRIGGER_MS_HOST = "cb.wfalerttrigger.service.host";
	private static final String TP_CB_WFALERTTRIGGER_MS_PORT= "cb.wfalerttrigger.service.port";
	private static final String TP_CB_WFALERTTRIGGER_MS_EUREKA_ID= "TP-CB-WFALERTTRIGGER-MS";
	
	private static final String TP_CB_WFALERTMANAGER_MS_HOST = "cb.wfalertmanager.service.host";
	private static final String TP_CB_WFALERTMANAGER_MS_PORT= "cb.wfalertmanager.service.port";
	private static final String TP_CB_WFALERTMANAGER_MS_EUREKA_ID= "TP-CB-WFALERTMANAGER-MS";
	
	private static final String TP_INSURANCE_API_HOST = "crd.insurance.api.host";
	private static final String TP_INSURANCE_API_PORT= "crd.insurance.api.port";
	private static final String TP_INSURANCE_API_EUREKA_ID= "TP-INSURANCE-API";
	
	private static final String TP_CB_WFMAILSERVICE_MS_HOST = "cb.wfmail.service.host";
	private static final String TP_CB_WFMAILSERVICE_MS_PORT= "cb.wfmail.service.port";
	private static final String TP_CB_WFMAILSERVICE_MS_EUREKA_ID ="TP-CB-WFMAILSERVICE-MS";
	*/
	private static final String TP_FILE_API_MS_HOST = "file.api.host";
	private static final String TP_FILE_API_MS_PORT = "file.api.port";
	private static final String TP_FILE_API_EUREKA_ID ="TP-FILE-API"; 
	
	private static final String TP_NLP_DATA_MS_HOST = "nlp.api.host";
	private static final String TP_NLP_DATA_MS_PORT = "nlp.api.port";
	private static final String TP_NLP_DATA_MS_EUREKA_ID ="TP-NLP-DATA-MS";
		
	private static String eurekaHost="";
	
	@Autowired
	SCBRegistryService registryService;
	
	@Autowired
	SCBOcrNlpMuleCloudConfigProperties muleCloudProperties;
	
	@Override
	public Object onCall(MuleEventContext eventContext) {
		MuleMessage message = eventContext.getMessage();
		String eurekaId="";
		String eurekaServiceId="";
		String activeEnv="";
		String fallbackInstance="";
		boolean eurekaEnable = false;
		String[] eurekaInsArr= new String[]{};
		
		try {
			activeEnv = message.getProperty("activeEnv", PropertyScope.INVOCATION).toString().toUpperCase(); 
			eurekaId = message.getProperty("eurekaId", PropertyScope.INVOCATION); 
			eurekaServiceId = eurekaId+"-"+activeEnv;
			eurekaEnable = Boolean.parseBoolean(((muleCloudProperties.get(EUREKA_ENABLED) !=null)? String.valueOf(muleCloudProperties.get(EUREKA_ENABLED)) : "false")); 
			eurekaHost = (String) muleCloudProperties.get(EUREKA_HOST);			
			fallbackInstance=retrieveMSfromProperty(eurekaId);
			if (eurekaEnable){
				logger.info("Discovering from EurekaHost:: "+eurekaHost);
			//	fallbackInstance=retrieveMSfromProperty(eurekaId);
				String eurekaInstance = registryService.getServiceInstance(eurekaServiceId, fallbackInstance);
				if (eurekaInstance != null && !eurekaInstance.equals("")){
					eurekaInsArr = eurekaInstance.split(":");
				} else {
					eurekaInsArr = fallbackInstance.split(":");
					logger.info("EurekaEnabled::"+eurekaEnable+", but eurekaId:["+eurekaServiceId+"] seems not registered. Retrieving from propertyFile - [host::"+eurekaInsArr[0]+", port::"+eurekaInsArr[1]+"]");
				}
			} else {
			//	fallbackInstance=retrieveMSfromProperty(eurekaId);
				eurekaInsArr = fallbackInstance.split(":");
				logger.info("EurekaEnabled::"+eurekaEnable+" for eurekaId:["+eurekaServiceId+"], retrieving from propertyFile - [host::"+eurekaInsArr[0]+", port::"+eurekaInsArr[1]+"]");
			}
			
			message.setProperty("msHost",eurekaInsArr[0], PropertyScope.INVOCATION);
			message.setProperty("msPort",eurekaInsArr[1], PropertyScope.INVOCATION);
			message.setProperty("eurekaEnable",eurekaEnable, PropertyScope.INVOCATION);
			
			
		} catch (Exception e) {
			logger.error(e);
		}
		
		return message;
	}
	
	private String retrieveMSfromProperty(String eurekaId) throws Exception{
		if (eurekaId.contains(TP_NLP_DATA_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_NLP_DATA_MS_HOST)+":"+muleCloudProperties.get(TP_NLP_DATA_MS_PORT);
		} /* else if (eurekaId.contains(TP_CB_TIMELINEEVENTS_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_TIMELINEEVENTS_MS_HOST)+":"+muleCloudProperties.get(TP_CB_TIMELINEEVENTS_MS_PORT);
		} else if (eurekaId.contains(TP_UTIL_LDAP_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_UTIL_LDAP_MS_HOST)+":"+muleCloudProperties.get(TP_UTIL_LDAP_MS_PORT);
		} else if (eurekaId.contains(TP_CB_STATICPARTY_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_STATICPARTY_MS_HOST)+":"+muleCloudProperties.get(TP_CB_STATICPARTY_MS_PORT);
		} else if (eurekaId.contains(TP_CB_TRANSACTIONPRIORITY_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_TRANSACTIONPRIORITY_MS_HOST)+":"+muleCloudProperties.get(TP_CB_TRANSACTIONPRIORITY_MS_PORT);
		} else if (eurekaId.contains(TP_CB_ALERTPOSTCREATION_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_ALERTPOSTCREATION_MS_HOST)+":"+muleCloudProperties.get(TP_CB_ALERTPOSTCREATION_MS_PORT);
		} else if (eurekaId.contains(TP_CB_ALERTACTIVITY_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_ALERTACTIVITY_MS_HOST)+":"+muleCloudProperties.get(TP_CB_ALERTACTIVITY_MS_PORT);
		} else if (eurekaId.contains(TP_CB_TRANSACTION_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_TRANSACTION_MS_HOST)+":"+muleCloudProperties.get(TP_CB_TRANSACTION_MS_PORT);
		} else if (eurekaId.contains(TP_CB_LOOKUP_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_LOOKUP_MS_HOST)+":"+muleCloudProperties.get(TP_CB_LOOKUP_MS_PORT);
		} else if (eurekaId.contains(TP_CB_TIMELINEINQUIRY_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_TIMELINEINQUIRY_MS_HOST)+":"+muleCloudProperties.get(TP_CB_TIMELINEINQUIRY_MS_PORT);
		} else if (eurekaId.contains(TP_CB_TXNENRICHMENT_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_TXNENRICHMENT_MS_HOST)+":"+muleCloudProperties.get(TP_CB_TXNENRICHMENT_MS_PORT);
		} else if (eurekaId.contains(TP_CB_ALERTTRIGGER_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_ALERTTRIGGER_MS_HOST)+":"+muleCloudProperties.get(TP_CB_ALERTTRIGGER_MS_PORT);
		} else if (eurekaId.contains(TP_CB_ALERTREASONHISTORY_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_ALERTREASONHISTORY_MS_HOST)+":"+muleCloudProperties.get(TP_CB_ALERTREASONHISTORY_MS_PORT);
		} else if (eurekaId.contains(TP_CB_ALERTDATA_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_ALERTDATA_MS_HOST)+":"+muleCloudProperties.get(TP_CB_ALERTDATA_MS_PORT);
		} else if (eurekaId.contains(TP_CB_CLIENTSNAPSHOT_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_CLIENTSNAPSHOT_MS_HOST)+":"+muleCloudProperties.get(TP_CB_CLIENTSNAPSHOT_MS_PORT);
		} else if (eurekaId.contains(TP_ESR_ALERTTRIGGER_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_ESR_ALERTTRIGGER_MS_HOST)+":"+muleCloudProperties.get(TP_ESR_ALERTTRIGGER_MS_PORT);
		} else if (eurekaId.contains(TP_OTP_API_EUREKA_ID)){
			return muleCloudProperties.get(TP_OTP_API_HOST)+":"+muleCloudProperties.get(TP_OTP_API_PORT);
		} else if (eurekaId.contains(TP_ESR_MAILSERVICE_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_ESR_MAILSERVICE_MS_HOST)+":"+muleCloudProperties.get(TP_ESR_MAILSERVICE_MS_PORT);
		} else if (eurekaId.contains(TP_CB_TXNFLATELASTIC_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_TXNFLATELASTIC_MS_HOST)+":"+muleCloudProperties.get(TP_CB_TXNFLATELASTIC_MS_PORT);
		}  else if (eurekaId.contains(TP_CB_WFALERTTRIGGER_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_WFALERTTRIGGER_MS_HOST)+":"+muleCloudProperties.get(TP_CB_WFALERTTRIGGER_MS_PORT);
		} else if (eurekaId.contains(TP_CB_WFALERTMANAGER_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_WFALERTMANAGER_MS_HOST)+":"+muleCloudProperties.get(TP_CB_WFALERTMANAGER_MS_PORT);
		} else if (eurekaId.contains(TP_INSURANCE_API_EUREKA_ID)){
			return muleCloudProperties.get(TP_INSURANCE_API_HOST)+":"+muleCloudProperties.get(TP_INSURANCE_API_PORT);
		} else if (eurekaId.contains(TP_CB_WFMAILSERVICE_MS_EUREKA_ID)){
			return muleCloudProperties.get(TP_CB_WFMAILSERVICE_MS_HOST)+":"+muleCloudProperties.get(TP_CB_WFMAILSERVICE_MS_PORT);
		}*/ else if(eurekaId.contains(TP_FILE_API_EUREKA_ID)) {
			return muleCloudProperties.get(TP_FILE_API_MS_HOST)+":"+muleCloudProperties.get(TP_FILE_API_MS_PORT);
		} 
		else {
			throw new Exception("Eureka Service ID ("+eurekaId+") is not yet setup.");
		}
	}
	
}


