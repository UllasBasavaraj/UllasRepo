package com.scb.ms.mule.transformer;

import java.io.InputStream;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.entity.SCBOcrNlpOTPDocumentDetails;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewTxnUpdateReq;
import com.scb.ms.mule.entity.SCBOcrNlpOTPNewUpdateReq;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpToOTPNEWTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpToOTPNEWTransformer.class);
	private String transformerType;

	@Override
	public Object transformMessage(MuleMessage message, String arg1) throws TransformerException {
		log.debug("Enter in to SCBNLPToOTPNEWTransformer calss ");
		String vppGenericJson = null;
		Object source = null;
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			SCBCommObj commObj = null;
			SCBOcrNlpOTPNewTxnUpdateReq txnUpdateRequest = null;
			SCBOcrNlpOTPNewUpdateReq otpNewUpdateReq = null;
			String loggerDealId = "";
			try {
				source = message.getPayload();
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.OTP_NEW_REQUEST_INFO));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.OTP_NEW_REQUEST_INFO);
				if (null != section) {
					SCBOcrNlpDealDataObjectExtn getDealDataExtobj = new SCBOcrNlpDealDataObjectExtn();
					getDealDataExtobj = (SCBOcrNlpDealDataObjectExtn) SCBCommObjTransformer.sectionToSCBPojo(commObj,
							getDealDataExtobj);
					try {
						if (getDealDataExtobj != null) {
							loggerDealId = getDealDataExtobj.getDealId();
							String countryCode = getDealDataExtobj.getCountry();
							log.debug(loggerDealId + " - Country code of Deal    " + countryCode);
							countryCode = getDealDataExtobj.getCountry();
							String systemCode = getDealDataExtobj.getSystemCode();
							String reqTimeStamp = getDealDataExtobj.getRegTimeStamp();

							otpNewUpdateReq = new SCBOcrNlpOTPNewUpdateReq();
							// may change header format
							otpNewUpdateReq.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
							otpNewUpdateReq.setSourceSystem(systemCode);
							otpNewUpdateReq.setCountryCode(countryCode);
							otpNewUpdateReq.setCustomerId(getDealDataExtobj.getClientId());
							otpNewUpdateReq.setDealReferance(getDealDataExtobj.getDealId());
							otpNewUpdateReq.setProductCode(getDealDataExtobj.getProductId());
							otpNewUpdateReq.setStepCode(getDealDataExtobj.getStepId());
							otpNewUpdateReq.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(reqTimeStamp));

							List<SCBOcrNlpOTPDocumentDetails> documentDetailsList = getDealDataExtobj
									.getDocumentDetails();
							otpNewUpdateReq.setDocumentDetails(documentDetailsList);
							txnUpdateRequest = new SCBOcrNlpOTPNewTxnUpdateReq();
							txnUpdateRequest.setDocCreateRequest(otpNewUpdateReq);
						}
					} catch (Exception e) {
						log.error(loggerDealId + " - Error in NLP to OTP NEW Transformer" + e);
					}
				}

				vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(txnUpdateRequest);
				log.debug(loggerDealId + " - txnUpdate Request of OTP New system  ==>" + vppGenericJson);

			} catch (Exception e) {
				log.error(loggerDealId + " - Error in NLP to OTP NEW Transformer" + e);
				throw new TransformerException(CoreMessages.createStaticMessage(
						loggerDealId + " - Unable to transform commobj to Generic Json in NLPToOTPNEW class " + source),
						e);
			}
		}
		return vppGenericJson;
	}

	public String getTransformerType() {
		return transformerType;
	}

	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}

}
