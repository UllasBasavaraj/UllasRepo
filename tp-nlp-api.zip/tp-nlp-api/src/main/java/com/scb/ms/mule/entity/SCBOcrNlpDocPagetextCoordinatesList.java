package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Transient;

public class SCBOcrNlpDocPagetextCoordinatesList {

	private List<SCBOcrNlpTextCoordinatesList> textCoordinatesList = new ArrayList<SCBOcrNlpTextCoordinatesList>();
	@Transient
	private String documentId = "";
	@Transient
	private String documentPageId = "";

	/**
	 * @return the textCoordinatesList
	 */
	public List<SCBOcrNlpTextCoordinatesList> getTextCoordinatesList() {
		return textCoordinatesList;
	}

	/**
	 * @param textCoordinatesList
	 *            the textCoordinatesList to set
	 */
	public void setTextCoordinatesList(List<SCBOcrNlpTextCoordinatesList> textCoordinatesList) {
		this.textCoordinatesList = textCoordinatesList;
	}

	/**
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId
	 *            the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * @return the documentPageId
	 */
	public String getDocumentPageId() {
		return documentPageId;
	}

	/**
	 * @param documentPageId
	 *            the documentPageId to set
	 */
	public void setDocumentPageId(String documentPageId) {
		this.documentPageId = documentPageId;
	}

}
