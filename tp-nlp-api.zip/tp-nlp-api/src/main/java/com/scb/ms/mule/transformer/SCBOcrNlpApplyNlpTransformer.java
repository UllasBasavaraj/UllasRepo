package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpUtil;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;

public class SCBOcrNlpApplyNlpTransformer extends AbstractMessageTransformer {
	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOcrNlpApplyNlpTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		LOGGER.info("Enter in to SCBOcrNlpApplyNlpTransformer  calss ");
		String jsonResp = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			Object src = null;
			String loggerDealId = EMPTY;
			byte[] input = null;
			SCBCommObj commObj = null;
			Object genericJson = null;
			try {
				loggerDealId = message.getInvocationProperty(Fields.LOGGER_DEAL_ID, EMPTY);
				LOGGER.debug(loggerDealId + " - source ==>" + src);
				// Create SCB Comm Object
				SCBCommObj reqObj = new SCBCommObj();
				SCBHeader header = new SCBHeader();
				SCBFooter footer = new SCBFooter();
				header = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.FORWARD);
				header.setModuleFunctionCode(ModuleFunctionCodes.APPLY_NLP);
				reqObj.setHeader(header);
				reqObj.setFooter(footer);
				try {
					src = message.getPayload();
					if (src instanceof String) {
						input = ((String) src).getBytes();
					} else if (src instanceof InputStream) {
						input = IOUtils.toByteArray((InputStream) src);
					} else if (src instanceof SCBCommObj) {
						commObj = (SCBCommObj) src;
					}

					if (null != input) {
						commObj = mapper.readValue(input, SCBCommObj.class);
					}

					SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.WEX_PAGE_INFO);
					reqObj.getBody().addSection(Sections.WEX_PAGE_INFO, section);
					genericJson = reqObj;
					jsonResp = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);

				} catch (Exception e) {
					LOGGER.error(loggerDealId + " - SCBOcrNlpApplyNlpTransformer Transformer Exception " + e);
					generateTechErrMsg(footer, "400", "Invalid Request", "Invalid request, missing or invalid data.");
				}
			} catch (Exception e) {
				LOGGER.error(loggerDealId + " - SCBOcrNlpApplyNlpTransformer Other Exception " + e);
				throw new TransformerException(
						CoreMessages.createStaticMessage(loggerDealId
								+ " - SCBOcrNlpApplyNlpTransformer Unable to transform commobj to Generic Json" + src),
						e);
			}
		}
		return jsonResp;
	}

	private static void generateTechErrMsg(SCBFooter scbFooter, String errorCode, String errorTitle, String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}

}
