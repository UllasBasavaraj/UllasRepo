package com.scb.ms.mule.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpDatacapTemplateFeedback {
	@JsonProperty("dealId")
	private String dealId;
	@JsonProperty("productId")
	private String productId;
	@JsonProperty("stepId")
	private String stepId;
	@JsonProperty("clientId")
	private String clientId;
	@JsonProperty("country")
	private String country;
	@JsonProperty("regTimestamp")
	private String regTimestamp;
	@JsonProperty("systemCode")
	private String systemCode;
	@JsonProperty("dealType")
	private String dealType;
	@JsonProperty("templateFeedbackDataList")
	private List<SCBOcrNlpDatacapTemplateFeedbackPage> templateFeedbackDataList = new ArrayList<>();
	@JsonProperty("srcAppName")
	private String srcAppName;

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the regTimestamp
	 */
	public String getRegTimestamp() {
		return regTimestamp;
	}

	/**
	 * @param regTimestamp
	 *            the regTimestamp to set
	 */
	public void setRegTimestamp(String regTimestamp) {
		this.regTimestamp = regTimestamp;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the dealType
	 */
	public String getDealType() {
		return dealType;
	}

	/**
	 * @param dealType
	 *            the dealType to set
	 */
	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	/**
	 * @return the templateFeedbackDataList
	 */
	public List<SCBOcrNlpDatacapTemplateFeedbackPage> getTemplateFeedbackDataList() {
		return templateFeedbackDataList;
	}

	/**
	 * @param templateFeedbackDataList
	 *            the templateFeedbackDataList to set
	 */
	public void setTemplateFeedbackDataList(List<SCBOcrNlpDatacapTemplateFeedbackPage> templateFeedbackDataList) {
		this.templateFeedbackDataList = templateFeedbackDataList;
	}

	/**
	 * @return the srcAppName
	 */
	public String getSrcAppName() {
		return srcAppName;
	}

	/**
	 * @param srcAppName the srcAppName to set
	 */
	public void setSrcAppName(String srcAppName) {
		this.srcAppName = srcAppName;
	}

}
