package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;


public class SCBOcrNlpDealDataObject {

	@Id
	private String id;
	private String dealId = "";
	private String wexTemplateId = "";
	private String productId = "";
	private String stepId = "";
	private String clientId = "";
	private String country = "";
	private List<SCBOcrNlpDataExtractionFieldsList> dataEntryFieldList = new ArrayList<SCBOcrNlpDataExtractionFieldsList>();
	private String dealStatus = "";
	private String digitizerStatus = "";
	private SCBOcrNlpDealSubStatus dealSubStatus = new SCBOcrNlpDealSubStatus();
	private SCBOcrNlpPageSets pageSets = new SCBOcrNlpPageSets();
	private SCBOcrNlpPageSets oldPageSets = new SCBOcrNlpPageSets();
	private String systemCode = "";
	private String lastModifiedBy = "";
	private String lastModifiedEmail = "";
	private String lastModifiedDate = "";
	private String displayScreen = "";
	private String regTimeStamp = "";
	private String tdApplicationReferenceId = "";
	private String dealReleasedStatus = "";
	private String dealReleasedDate = "";
	private String subProductCode = "";
	private String regTimeMsStr = "";
	private String sysDate = "";
	private int rescanDocNum;
	@Transient
	private String response = "";

	private String dealType = "";

	private List<SCBOcrNlpDocumenstList> documentsList = new ArrayList<SCBOcrNlpDocumenstList>();

	@Transient
	private List<SCBOcrNlpKeyValue> fieldSizeList = new ArrayList<SCBOcrNlpKeyValue>();

	@Transient
	private List<SCBOcrNlpMandatoryKeyValue> mandatoryList = new ArrayList<SCBOcrNlpMandatoryKeyValue>();
	
	@Transient
	private List<SCBOcrNlpDataEntryFieldsInfo> dataEntryFieldCheckList = new ArrayList<SCBOcrNlpDataEntryFieldsInfo>();

	@Transient
	private int pageIdleTime;

	@Transient
	private boolean fromRCS;
	@Transient
	private int configIdleTime;
	@Transient
	private String dealSubmitStatus;
	
	@Transient
	private String userId;

	@Transient
	private boolean isSysStatus;
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the wexTemplateId
	 */
	public String getWexTemplateId() {
		return wexTemplateId;
	}

	/**
	 * @param wexTemplateId
	 *            the wexTemplateId to set
	 */
	public void setWexTemplateId(String wexTemplateId) {
		this.wexTemplateId = wexTemplateId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	
	

	/**
	 * @return the dataEntryFieldList
	 */
	public List<SCBOcrNlpDataExtractionFieldsList> getDataEntryFieldList() {
		return dataEntryFieldList;
	}

	/**
	 * @param dataEntryFieldList the dataEntryFieldList to set
	 */
	public void setDataEntryFieldList(List<SCBOcrNlpDataExtractionFieldsList> dataEntryFieldList) {
		this.dataEntryFieldList = dataEntryFieldList;
	}

	/**
	 * @return the dealStatus
	 */
	public String getDealStatus() {
		return dealStatus;
	}

	/**
	 * @param dealStatus
	 *            the dealStatus to set
	 */
	public void setDealStatus(String dealStatus) {
		this.dealStatus = dealStatus;
	}

	/**
	 * @return the digitizerStatus
	 */
	public String getDigitizerStatus() {
		return digitizerStatus;
	}

	/**
	 * @param digitizerStatus
	 *            the digitizerStatus to set
	 */
	public void setDigitizerStatus(String digitizerStatus) {
		this.digitizerStatus = digitizerStatus;
	}

	/**
	 * @return the dealSubStatus
	 */
	public SCBOcrNlpDealSubStatus getDealSubStatus() {
		return dealSubStatus;
	}

	/**
	 * @param dealSubStatus
	 *            the dealSubStatus to set
	 */
	public void setDealSubStatus(SCBOcrNlpDealSubStatus dealSubStatus) {
		this.dealSubStatus = dealSubStatus;
	}

	/**
	 * @return the pageSets
	 */
	public SCBOcrNlpPageSets getPageSets() {
		return pageSets;
	}

	/**
	 * @param pageSets
	 *            the pageSets to set
	 */
	public void setPageSets(SCBOcrNlpPageSets pageSets) {
		this.pageSets = pageSets;
	}

	/**
	 * @return the oldPageSets
	 */
	public SCBOcrNlpPageSets getOldPageSets() {
		return oldPageSets;
	}

	/**
	 * @param oldPageSets
	 *            the oldPageSets to set
	 */
	public void setOldPageSets(SCBOcrNlpPageSets oldPageSets) {
		this.oldPageSets = oldPageSets;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * @param lastModifiedBy
	 *            the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return the lastModifiedEmail
	 */
	public String getLastModifiedEmail() {
		return lastModifiedEmail;
	}

	/**
	 * @param lastModifiedEmail
	 *            the lastModifiedEmail to set
	 */
	public void setLastModifiedEmail(String lastModifiedEmail) {
		this.lastModifiedEmail = lastModifiedEmail;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate
	 *            the lastModifiedDate to set
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the displayScreen
	 */
	public String getDisplayScreen() {
		return displayScreen;
	}

	/**
	 * @param displayScreen
	 *            the displayScreen to set
	 */
	public void setDisplayScreen(String displayScreen) {
		this.displayScreen = displayScreen;
	}

	/**
	 * @return the regTimeStamp
	 */
	public String getRegTimeStamp() {
		return regTimeStamp;
	}

	/**
	 * @param regTimeStamp
	 *            the regTimeStamp to set
	 */
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}

	/**
	 * @return the tdApplicationReferenceId
	 */
	public String getTdApplicationReferenceId() {
		return tdApplicationReferenceId;
	}

	/**
	 * @param tdApplicationReferenceId
	 *            the tdApplicationReferenceId to set
	 */
	public void setTdApplicationReferenceId(String tdApplicationReferenceId) {
		this.tdApplicationReferenceId = tdApplicationReferenceId;
	}

	/**
	 * @return the sysDate
	 */
	public String getSysDate() {
		return sysDate;
	}

	/**
	 * @param sysDate
	 *            the sysDate to set
	 */
	public void setSysDate(String sysDate) {
		this.sysDate = sysDate;
	}

	/**
	 * @return the rescanDocNum
	 */
	public int getRescanDocNum() {
		return rescanDocNum;
	}

	/**
	 * @param rescanDocNum
	 *            the rescanDocNum to set
	 */
	public void setRescanDocNum(int rescanDocNum) {
		this.rescanDocNum = rescanDocNum;
	}

	/**
	 * @return the response
	 */
	public String getResponse() {
		return response;
	}

	/**
	 * @param response
	 *            the response to set
	 */
	public void setResponse(String response) {
		this.response = response;
	}

	/**
	 * @return the dealType
	 */
	public String getDealType() {
		return dealType;
	}

	/**
	 * @param dealType
	 *            the dealType to set
	 */
	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	/**
	 * @return the documentsList
	 */
	public List<SCBOcrNlpDocumenstList> getDocumentsList() {
		return documentsList;
	}

	/**
	 * @param documentsList
	 *            the documentsList to set
	 */
	public void setDocumentsList(List<SCBOcrNlpDocumenstList> documentsList) {
		this.documentsList = documentsList;
	}

	/**
	 * @return the fieldSizeList
	 */
	public List<SCBOcrNlpKeyValue> getFieldSizeList() {
		return fieldSizeList;
	}

	/**
	 * @param fieldSizeList
	 *            the fieldSizeList to set
	 */
	public void setFieldSizeList(List<SCBOcrNlpKeyValue> fieldSizeList) {
		this.fieldSizeList = fieldSizeList;
	}

	/**
	 * @return the mandatoryList
	 */
	public List<SCBOcrNlpMandatoryKeyValue> getMandatoryList() {
		return mandatoryList;
	}

	/**
	 * @param mandatoryList
	 *            the mandatoryList to set
	 */
	public void setMandatoryList(List<SCBOcrNlpMandatoryKeyValue> mandatoryList) {
		this.mandatoryList = mandatoryList;
	}

	/**
	 * @return the pageIdleTime
	 */
	public int getPageIdleTime() {
		return pageIdleTime;
	}

	/**
	 * @param pageIdleTime
	 *            the pageIdleTime to set
	 */
	public void setPageIdleTime(int pageIdleTime) {
		this.pageIdleTime = pageIdleTime;
	}

	/**
	 * @return the fromRCS
	 */
	public boolean getFromRCS() {
		return fromRCS;
	}

	/**
	 * @param fromRCS
	 *            the fromRCS to set
	 */
	public void setFromRCS(boolean fromRCS) {
		this.fromRCS = fromRCS;
	}

	/**
	 * @return the configIdleTime
	 */
	public int getConfigIdleTime() {
		return configIdleTime;
	}

	/**
	 * @param configIdleTime
	 *            the configIdleTime to set
	 */
	public void setConfigIdleTime(int configIdleTime) {
		this.configIdleTime = configIdleTime;
	}

	/**
	 * @return the dealReleasedStatus
	 */
	public String getDealReleasedStatus() {
		return dealReleasedStatus;
	}

	/**
	 * @param dealReleasedStatus
	 *            the dealReleasedStatus to set
	 */
	public void setDealReleasedStatus(String dealReleasedStatus) {
		this.dealReleasedStatus = dealReleasedStatus;
	}


	/**
	 * @return the dealReleasedDate
	 */
	public String getDealReleasedDate() {
		return dealReleasedDate;
	}

	/**
	 * @param dealReleasedDate the dealReleasedDate to set
	 */
	public void setDealReleasedDate(String dealReleasedDate) {
		this.dealReleasedDate = dealReleasedDate;
	}

	/**
	 * @return the subProductCode
	 */
	public String getSubProductCode() {
		return subProductCode;
	}

	/**
	 * @param subProductCode
	 *            the subProductCode to set
	 */
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	/**
	 * @return the dealSubmitStatus
	 */
	public String getDealSubmitStatus() {
		return dealSubmitStatus;
	}

	/**
	 * @param dealSubmitStatus
	 *            the dealSubmitStatus to set
	 */
	public void setDealSubmitStatus(String dealSubmitStatus) {
		this.dealSubmitStatus = dealSubmitStatus;
	}

	/**
	 * @return the dataEntryFieldCheckList
	 */
	public List<SCBOcrNlpDataEntryFieldsInfo> getDataEntryFieldCheckList() {
		return dataEntryFieldCheckList;
	}

	/**
	 * @param dataEntryFieldCheckList the dataEntryFieldCheckList to set
	 */
	public void setDataEntryFieldCheckList(List<SCBOcrNlpDataEntryFieldsInfo> dataEntryFieldCheckList) {
		this.dataEntryFieldCheckList = dataEntryFieldCheckList;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	/**
	 * @return the regTimeMsStr
	 */
	public String getRegTimeMsStr() {
		return regTimeMsStr;
	}

	/**
	 * @param regTimeMsStr the regTimeMsStr to set
	 */
	public void setRegTimeMsStr(String regTimeMsStr) {
		this.regTimeMsStr = regTimeMsStr;
	}

	/**
	 * @return the isSysStatus
	 */
	public boolean getSysStatus() {
		return isSysStatus;
	}

	/**
	 * @param isSysStatus the isSysStatus to set
	 */
	public void setSysStatus(boolean isSysStatus) {
		this.isSysStatus = isSysStatus;
	}

}
