package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;

public class SCBOcrNlpDataEntryFields {

	@Id
	private String id;
	private String dealId;
	private String productId;
	private String stepId;
	private String clientId;
	private String country;
	private String regTimestamp;
	private String systemCode;
	private String tdAppRefId;
	private List<SCBOcrNlpDataExtractionFieldsList> dataEntryFieldsList = new ArrayList<SCBOcrNlpDataExtractionFieldsList>();

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDealId() {
		return dealId;
	}

	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getStepId() {
		return stepId;
	}

	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getRegTimestamp() {
		return regTimestamp;
	}

	public void setRegTimestamp(String regTimestamp) {
		this.regTimestamp = regTimestamp;
	}

	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	public String getTdAppRefId() {
		return tdAppRefId;
	}

	public void setTdAppRefId(String tdAppRefId) {
		this.tdAppRefId = tdAppRefId;
	}

	public List<SCBOcrNlpDataExtractionFieldsList> getDataEntryFieldsList() {
		return dataEntryFieldsList;
	}

	public void setDataEntryFieldsList(List<SCBOcrNlpDataExtractionFieldsList> dataEntryFieldsList) {
		this.dataEntryFieldsList = dataEntryFieldsList;
	}

}
