package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpTemplateEntity {

	private String name;
	private List<SCBOcrNlpTemplateAttribute> attributesList = new ArrayList<>();

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the attributesList
	 */
	public List<SCBOcrNlpTemplateAttribute> getAttributesList() {
		return attributesList;
	}

	/**
	 * @param attributesList
	 *            the attributesList to set
	 */
	public void setAttributesList(List<SCBOcrNlpTemplateAttribute> attributesList) {
		this.attributesList = attributesList;
	}

}
