package com.scb.ms.mule.transformer;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.DataType;
import org.mule.api.transformer.TransformerException;
import org.mule.api.transport.PropertyScope;
import org.mule.module.json.JsonData;
import org.mule.transformer.AbstractMessageTransformer;
import org.springframework.beans.factory.annotation.Autowired;

import com.scb.core.validation.SCBValidationFactory;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.core.util.SCBObjectMapper;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;

public class SCBOcrNlpGenericErrorResponse extends AbstractMessageTransformer {

	@Autowired
	SCBValidationFactory validationFactory;
	
	@Autowired
	SCBObjectMapper mapper;

	private static final String NULL_PAYLOAD = "{NullPayload}";
	
	@Override
	public String transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		SCBCommObj commObj = new SCBCommObj();
		String commObjStr=null;
		Object src = message.getPayload(DataType.STRING_DATA_TYPE);
		String errorMessage = message.getProperty("errorMessage", PropertyScope.INVOCATION); 
		
		try {
			if (src instanceof org.mule.module.json.JsonData){
				JsonData jsonData = (JsonData) src;
				commObj = (SCBCommObj)mapper.readerFor(SCBCommObj.class).readValue(jsonData.toString());	
			} else if (src instanceof SCBCommObj) {
				commObj = (SCBCommObj) src;
			} else if (src instanceof String) {
				if (NULL_PAYLOAD.equals(src)){
					commObj = (SCBCommObj) message.getOriginalPayload();
				} else {
					commObj = (SCBCommObj)mapper.readerFor(SCBCommObj.class).readValue((String) src);
				}
			}
			
			SCBSection section = new SCBSection();
			section.putBooleanValue("isTechError", true);
			commObj.getBody().addSection("TExceptionSec", section);
			commObj.addFooterError(validationFactory.createError(SCBOcrNlpMuleConstants.MULE_GENERAL_VALIDATION, new String[]{"ERROR - "+errorMessage}));
			commObjStr = mapper.writer().writeValueAsString(commObj);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}

		
		return commObjStr;
	}

}