package com.scb.ms.mule.entity;

public class SCBOcrNlpVesselDetails {

	private String id = "";
	private String name = "";
	private String flagOfcountry = "";
	private String imoNo = "";
	private String carrierBookingNumber = "";
	private String carrierName = "";

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the flagOfcountry
	 */
	public String getFlagOfcountry() {
		return flagOfcountry;
	}

	/**
	 * @param flagOfcountry
	 *            the flagOfcountry to set
	 */
	public void setFlagOfcountry(String flagOfcountry) {
		this.flagOfcountry = flagOfcountry;
	}

	/**
	 * @return the imoNo
	 */
	public String getImoNo() {
		return imoNo;
	}

	/**
	 * @param imoNo
	 *            the imoNo to set
	 */
	public void setImoNo(String imoNo) {
		this.imoNo = imoNo;
	}

	/**
	 * @return the carrierBookingNumber
	 */
	public String getCarrierBookingNumber() {
		return carrierBookingNumber;
	}

	/**
	 * @param carrierBookingNumber
	 *            the carrierBookingNumber to set
	 */
	public void setCarrierBookingNumber(String carrierBookingNumber) {
		this.carrierBookingNumber = carrierBookingNumber;
	}

	/**
	 * @return the carrierName
	 */
	public String getCarrierName() {
		return carrierName;
	}

	/**
	 * @param carrierName
	 *            the carrierName to set
	 */
	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

}
