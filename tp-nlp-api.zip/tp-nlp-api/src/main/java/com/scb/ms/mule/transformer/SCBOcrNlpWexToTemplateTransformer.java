package com.scb.ms.mule.transformer;

import java.io.InputStream;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpWexPageInfo;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpWexToTemplateTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpWexToTemplateTransformer.class);
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.debug("Starting SCBWexToTemplateTransformer class");
		String jsonResponse = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			byte[] input = null;
			Object genericJson = null;
			Object src = null;
			String loggerDealId = EMPTY;
			SCBCommObj commObj = null;
			SCBSection wexPageInfoSection;
			try {
				src = message.getPayload();
				loggerDealId = message.getInvocationProperty("loggerDealId", EMPTY);
				log.debug(loggerDealId + " - source ==>" + src);
				if (src instanceof String) {
					log.debug(loggerDealId + " - source instance of String");
					input = ((String) src).getBytes();
				} else if (src instanceof InputStream) {
					log.debug(loggerDealId + " - source instance of Input Stream");
					input = IOUtils.toByteArray((InputStream) src);
				} else if (src instanceof SCBCommObj) {
					log.debug(loggerDealId + " - source instance of comm obj ... " + src);
					commObj = (SCBCommObj) src;
				} else {
					log.debug(loggerDealId + " - Unpredicted Incoming response type from WEX");
				}

				if (commObj != null || input != null) {
					// Create SCB Comm Object
					SCBCommObj reqObj = new SCBCommObj();
					SCBHeader header = SCBOcrNlpUtil.createSCBProcessWEXTemplateResultsHeaderObject(ModuleCodes.WEX);
					SCBFooter footer = new SCBFooter();
					reqObj.setHeader(header);
					reqObj.setFooter(footer);
					try {
						if (input != null) {
							log.debug(loggerDealId + " - WEX output" + input.toString());
							String invocationProperty = message
									.getInvocationProperty(Fields.FINAL_WEX__TEMPLATE_PLAYLOAD, EMPTY);
							SCBOcrNlpWexPageInfo nlpWexPageInfo = mapper.readValue(invocationProperty,
									SCBOcrNlpWexPageInfo.class);
							Map<String, SCBSection> wexPageInfoMap = SCBCommObjTransformer.pojoToSection(nlpWexPageInfo,
									SCBOcrNlpWexPageInfo.class);
							wexPageInfoSection = wexPageInfoMap.get(Sections.WEX_PAGE_INFO);
						} else {
							wexPageInfoSection = ((SCBCommObj) commObj).getBodySection(Sections.WEX_PAGE_INFO);
						}

						reqObj.getBody().addSection(Sections.WEX_PAGE_INFO, wexPageInfoSection);

					} catch (Exception e) {
						log.error(loggerDealId + " - SCBOcrNlpWexToTemplateTransformer Exception " + e);
						genTechErrMsg(footer, "400", "Invalid Request", "Invalid request, missing or invalid data.");
					}
					genericJson = reqObj;
				}
				jsonResponse = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(genericJson);

			} catch (Exception e) {
				log.error(loggerDealId + " - Other Exception " + e);
				throw new TransformerException(CoreMessages.createStaticMessage(loggerDealId
						+ " - SCBOcrNlpWexToTemplateTransformer Unable to transform commobj to Generic Json" + src), e);
			}
		}
		return jsonResponse;
	}

	private static void genTechErrMsg(SCBFooter scbFooter, String errorCode, String errorTitle, String errorMsg) {
		SCBValidationErrorResult scbValidationErrorCd = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMsg = new SCBValidationErrorResult(errorMsg, "errorMessage", null);
		scbFooter.addError(scbValidationErrorCd);
		scbFooter.addError(scbValidationErrorTitle);
		scbFooter.addError(scbValidationErrorMsg);
	}
}
