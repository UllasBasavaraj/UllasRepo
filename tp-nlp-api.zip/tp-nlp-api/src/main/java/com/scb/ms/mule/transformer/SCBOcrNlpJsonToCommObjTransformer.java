package com.scb.ms.mule.transformer;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

import com.scb.core.common.util.CommObjSerializationUtil;
import com.scb.ms.communication.SCBCommObj;

public class SCBOcrNlpJsonToCommObjTransformer extends AbstractTransformer {

	@Override
	protected SCBCommObj doTransform(Object src, String enc)
			throws TransformerException {
		SCBCommObj scbCommObj = null;
		if (src instanceof String) {
			scbCommObj = CommObjSerializationUtil.fromJson((String) src);
		}
		return scbCommObj;
	}

}