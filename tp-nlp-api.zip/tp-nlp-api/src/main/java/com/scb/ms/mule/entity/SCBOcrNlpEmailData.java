package com.scb.ms.mule.entity;

public class SCBOcrNlpEmailData {

	private String dealId;
	private String stepId;
	private String country;
	private String regTimeStamp;
	private String productId;
	private String clientId;
	private String systemCode;
	private String triggerMail;
	private String wexCallStatus = "";
	private String wexTemplateCallStatus = "";
	private String forwardTdStageCallStatus = "";
	private String forwardTdStatusCallStatus = "";
	private String forwardTpCallStatus = "";
	private String submitTpCallStatus = "";
	private String submitTdStageCallStatus = "";
	private String submitTdStatusCallStatus = "";
	private String submitIccFeedbackCallStatus = "";
	private String submitDatacapCallStatus = "";
	private String flowType = "";

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the regTimeStamp
	 */
	public String getRegTimeStamp() {
		return regTimeStamp;
	}

	/**
	 * @param regTimeStamp
	 *            the regTimeStamp to set
	 */
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the triggerMail
	 */
	public String getTriggerMail() {
		return triggerMail;
	}

	/**
	 * @param triggerMail
	 *            the triggerMail to set
	 */
	public void setTriggerMail(String triggerMail) {
		this.triggerMail = triggerMail;
	}

	/**
	 * @return the wexCallStatus
	 */
	public String getWexCallStatus() {
		return wexCallStatus;
	}

	/**
	 * @param wexCallStatus
	 *            the wexCallStatus to set
	 */
	public void setWexCallStatus(String wexCallStatus) {
		this.wexCallStatus = wexCallStatus;
	}

	/**
	 * @return the wexTemplateCallStatus
	 */
	public String getWexTemplateCallStatus() {
		return wexTemplateCallStatus;
	}

	/**
	 * @param wexTemplateCallStatus
	 *            the wexTemplateCallStatus to set
	 */
	public void setWexTemplateCallStatus(String wexTemplateCallStatus) {
		this.wexTemplateCallStatus = wexTemplateCallStatus;
	}

	/**
	 * @return the forwardTdStageCallStatus
	 */
	public String getForwardTdStageCallStatus() {
		return forwardTdStageCallStatus;
	}

	/**
	 * @param forwardTdStageCallStatus
	 *            the forwardTdStageCallStatus to set
	 */
	public void setForwardTdStageCallStatus(String forwardTdStageCallStatus) {
		this.forwardTdStageCallStatus = forwardTdStageCallStatus;
	}

	/**
	 * @return the forwardTdStatusCallStatus
	 */
	public String getForwardTdStatusCallStatus() {
		return forwardTdStatusCallStatus;
	}

	/**
	 * @param forwardTdStatusCallStatus
	 *            the forwardTdStatusCallStatus to set
	 */
	public void setForwardTdStatusCallStatus(String forwardTdStatusCallStatus) {
		this.forwardTdStatusCallStatus = forwardTdStatusCallStatus;
	}

	/**
	 * @return the forwardTpCallStatus
	 */
	public String getForwardTpCallStatus() {
		return forwardTpCallStatus;
	}

	/**
	 * @param forwardTpCallStatus
	 *            the forwardTpCallStatus to set
	 */
	public void setForwardTpCallStatus(String forwardTpCallStatus) {
		this.forwardTpCallStatus = forwardTpCallStatus;
	}

	/**
	 * @return the submitTpCallStatus
	 */
	public String getSubmitTpCallStatus() {
		return submitTpCallStatus;
	}

	/**
	 * @param submitTpCallStatus
	 *            the submitTpCallStatus to set
	 */
	public void setSubmitTpCallStatus(String submitTpCallStatus) {
		this.submitTpCallStatus = submitTpCallStatus;
	}

	/**
	 * @return the submitTdStageCallStatus
	 */
	public String getSubmitTdStageCallStatus() {
		return submitTdStageCallStatus;
	}

	/**
	 * @param submitTdStageCallStatus
	 *            the submitTdStageCallStatus to set
	 */
	public void setSubmitTdStageCallStatus(String submitTdStageCallStatus) {
		this.submitTdStageCallStatus = submitTdStageCallStatus;
	}

	/**
	 * @return the submitTdStatusCallStatus
	 */
	public String getSubmitTdStatusCallStatus() {
		return submitTdStatusCallStatus;
	}

	/**
	 * @param submitTdStatusCallStatus
	 *            the submitTdStatusCallStatus to set
	 */
	public void setSubmitTdStatusCallStatus(String submitTdStatusCallStatus) {
		this.submitTdStatusCallStatus = submitTdStatusCallStatus;
	}

	/**
	 * @return the submitIccFeedbackCallStatus
	 */
	public String getSubmitIccFeedbackCallStatus() {
		return submitIccFeedbackCallStatus;
	}

	/**
	 * @param submitIccFeedbackCallStatus
	 *            the submitIccFeedbackCallStatus to set
	 */
	public void setSubmitIccFeedbackCallStatus(String submitIccFeedbackCallStatus) {
		this.submitIccFeedbackCallStatus = submitIccFeedbackCallStatus;
	}

	/**
	 * @return the submitDatacapCallStatus
	 */
	public String getSubmitDatacapCallStatus() {
		return submitDatacapCallStatus;
	}

	/**
	 * @param submitDatacapCallStatus
	 *            the submitDatacapCallStatus to set
	 */
	public void setSubmitDatacapCallStatus(String submitDatacapCallStatus) {
		this.submitDatacapCallStatus = submitDatacapCallStatus;
	}

	/**
	 * @return the flowType
	 */
	public String getFlowType() {
		return flowType;
	}

	/**
	 * @param flowType
	 *            the flowType to set
	 */
	public void setFlowType(String flowType) {
		this.flowType = flowType;
	}

}
