package com.scb.ms.mule.entity;

public class SCBOcrNlpGetDealObject {

	private String dealId;
	private String country;
	private String stepId;
	private String clientId;
	private String filenetDocumentId;
	private String image;

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the filenetDocumentId
	 */
	public String getFilenetDocumentId() {
		return filenetDocumentId;
	}

	/**
	 * @param filenetDocumentId
	 *            the filenetDocumentId to set
	 */
	public void setFilenetDocumentId(String filenetDocumentId) {
		this.filenetDocumentId = filenetDocumentId;
	}

	/**
	 * @return the image
	 */
	public String getImage() {
		return image;
	}

	/**
	 * @param image
	 *            the image to set
	 */
	public void setImage(String image) {
		this.image = image;
	}

}
