package com.scb.ms.mule.transformer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpWEXDictionaryEntries;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;

public class SCBOcrNlpDictionaryEntryTransformer extends AbstractMessageTransformer {

    private static  final Logger logger = LoggerFactory.getLogger(SCBOcrNlpDictionaryEntryTransformer.class);

    @Override
    public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
        logger.info("Entering SCBNLPDictionaryEntryTransformer class");

        String outputJson = null;
        Object source = null;
        String inputString = null;
        SCBCommObj inputScbCommObj = null;
        ObjectMapper mapper = new ObjectMapper();
        if(message != null){
            try{
                source = message.getPayload();
                logger.debug("Source: " + source);

                if(source instanceof String)
                    inputString = (String)source;
                else if(source instanceof InputStream)
                    inputString = IOUtils.toString((InputStream)source, "UTF-8");
                else if(source instanceof SCBCommObj)
                    inputScbCommObj = (SCBCommObj)source;

                if(inputString != null)
                    inputScbCommObj = mapper.readValue(inputString, SCBCommObj.class);

                SCBSection section = inputScbCommObj.getBodySection(SCBOcrNlpMuleConstants.Sections.WEX_DICTIONARY_ENTRIES);
                SCBOcrNlpWEXDictionaryEntries dictionaryEntries = new SCBOcrNlpWEXDictionaryEntries();

                if(section  != null)
                    dictionaryEntries = (SCBOcrNlpWEXDictionaryEntries) SCBCommObjTransformer.sectionToSCBPojo(inputScbCommObj, dictionaryEntries);

                outputJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(dictionaryEntries);
                logger.debug("SCBNLPDictionaryEntryTransformer output JSON: " + outputJson);
            }
            catch (Exception e){
                throw new TransformerException(
                        CoreMessages.createStaticMessage("Unable to generate dictionary entry list from micro service response" + source), e);
            }
        }

        return outputJson;
    }
}
