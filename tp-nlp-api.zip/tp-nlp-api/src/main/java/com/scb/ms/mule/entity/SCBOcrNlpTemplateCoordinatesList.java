package com.scb.ms.mule.entity;

public class SCBOcrNlpTemplateCoordinatesList {

	private int charStart;
	private int charEnd;
	private int layoutCharStart;
	private int layoutCharEnd;
	private String wordValue;

	/**
	 * @return the charStart
	 */
	public int getCharStart() {
		return charStart;
	}

	/**
	 * @param charStart
	 *            the charStart to set
	 */
	public void setCharStart(int charStart) {
		this.charStart = charStart;
	}

	/**
	 * @return the charEnd
	 */
	public int getCharEnd() {
		return charEnd;
	}

	/**
	 * @param charEnd
	 *            the charEnd to set
	 */
	public void setCharEnd(int charEnd) {
		this.charEnd = charEnd;
	}

	/**
	 * @return the layoutCharStart
	 */
	public int getLayoutCharStart() {
		return layoutCharStart;
	}

	/**
	 * @param layoutCharStart
	 *            the layoutCharStart to set
	 */
	public void setLayoutCharStart(int layoutCharStart) {
		this.layoutCharStart = layoutCharStart;
	}

	/**
	 * @return the layoutCharEnd
	 */
	public int getLayoutCharEnd() {
		return layoutCharEnd;
	}

	/**
	 * @param layoutCharEnd
	 *            the layoutCharEnd to set
	 */
	public void setLayoutCharEnd(int layoutCharEnd) {
		this.layoutCharEnd = layoutCharEnd;
	}

	/**
	 * @return the wordValue
	 */
	public String getWordValue() {
		return wordValue;
	}

	/**
	 * @param wordValue the wordValue to set
	 */
	public void setWordValue(String wordValue) {
		this.wordValue = wordValue;
	}
	

}
