package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpNameCaptureListObject {

	private List<SCBOcrNlpNameCaptureList> nameCaptureList = new ArrayList<>();

	/**
	 * @return the nameCaptureList
	 */
	public List<SCBOcrNlpNameCaptureList> getNameCaptureList() {
		return nameCaptureList;
	}

	/**
	 * @param nameCaptureList
	 *            the nameCaptureList to set
	 */
	public void setNameCaptureList(List<SCBOcrNlpNameCaptureList> nameCaptureList) {
		this.nameCaptureList = nameCaptureList;
	}

}
