package com.scb.ms.mule.entity;

public class SCBOcrNlpDTPRoutingDetails {
	private String sequenceNo = "";
	private SCBOcrNlpVesselDetails vessel = new SCBOcrNlpVesselDetails();
	private SCBOcrNlpPortDetails port = new SCBOcrNlpPortDetails();
	private SCBOcrNlpPlaceDetails place = new SCBOcrNlpPlaceDetails();
	/**
	 * @return the sequenceNo
	 */
	public String getSequenceNo() {
		return sequenceNo;
	}
	/**
	 * @param sequenceNo the sequenceNo to set
	 */
	public void setSequenceNo(String sequenceNo) {
		this.sequenceNo = sequenceNo;
	}
	/**
	 * @return the vessel
	 */
	public SCBOcrNlpVesselDetails getVessel() {
		return vessel;
	}
	/**
	 * @param vessel the vessel to set
	 */
	public void setVessel(SCBOcrNlpVesselDetails vessel) {
		this.vessel = vessel;
	}
	/**
	 * @return the port
	 */
	public SCBOcrNlpPortDetails getPort() {
		return port;
	}
	/**
	 * @param port the port to set
	 */
	public void setPort(SCBOcrNlpPortDetails port) {
		this.port = port;
	}
	/**
	 * @return the place
	 */
	public SCBOcrNlpPlaceDetails getPlace() {
		return place;
	}
	/**
	 * @param place the place to set
	 */
	public void setPlace(SCBOcrNlpPlaceDetails place) {
		this.place = place;
	}
	
	
}
