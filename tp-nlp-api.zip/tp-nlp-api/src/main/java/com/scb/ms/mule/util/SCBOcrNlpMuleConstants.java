package com.scb.ms.mule.util;

public class SCBOcrNlpMuleConstants {
	public static final String MULE_GENERAL_VALIDATION = "ERROR.ML00013";
	public static final String DOC_DUP_DISAPPROVAL_VALIDATION = "INFO.MD10545";
	public static final String DOC_NUMBER_VALIDATION = "INFO.MD03020";
	public static final String TOTAL_RFF_CANNOT_ZERO_VALIDATION = "ERROR.MD03050";
	public static final String FIN_TO_RFF_AMT_VALIDATION = "ERROR.MD03025";
	public static final String AUTO_DEBIT_AD01_VAL = "ERROR.MD03651";
	public static final String AUTO_DEBIT_POOL_VAL = "ERROR.MD03649";
	public static final String FIN_INSURANCE_CURR_VALIDATION = "ERROR.MD01023";
	public static final String SINGLEDOC_TIMEOUT_OCCURS = "ERROR.ML00045";

	public static final String PYMT_VALUE_DATE_VALIDATION = "ERROR.IS06022";
	public static final String PYMT_ALLOC_COLLECTION_EMPTY_VALIDATION = "ERROR.IS06033";
	public static final String ACU_FLAG_ON_THIS_BATCH = "ERROR.IS05527";
	public static final String ALLOC_AMT_NOT_EQUAL_TO_PYMT_AMT = "ERROR.IS06043";
	public static final String PYMT_ALLOC_ERROR_MESSAGE = "ERROR.IS01606";
	public static final String PYMT_ALLOC_INFO_MESSAGE = "INFO.IS01563";
	public static final String TOTALPYMTALLOCAMT_ACTUALCREDITAMT_VALIDATION = "ERROR.IS06001";
	public static final String TOTALPRE_PYMTALLOCAMT_ACTUALCREDITAMT_VALIDATION = "ERROR.IS06027";
	public static final String PYMT_COMPARE_FIN_CCY_VALIDATION = "ERROR.IS06031";

	public static final String SECTIONNAME_EMAIL = "emailDetails";
	public static final String TRIGGER_MAIL = "Y";
	public static final String EMPTY_STRING = "";
	public static final String NO_RECORD_FOUND_CODE = "404";

	public interface DigitizerStatus {
		public String PENDING = "PENDING";
		public String UPDATED = "UPDATED";
		public String RESCANN = "RESCANN";
		public String TECHFAIL = "TECHFAIL";
		public String TXNL = "TXNL";
		public String SUBMITFAIL = "SUBMITFAIL";
		public String BATCH = "BATCH";
		public String BATCHFAIL = "BATCHFAIL";
		public String NOTMAKR = "NOTMAKR";
	}

	public interface LayoutXmlNodeAttributes {
		public String POSITION = "pos";
		public String VALUE = "v";
	}

	public interface DealSubStatus {
		public String INITIALIZATION = "INIT";
		public String SUCCESS = "SUCC";
		public String BATCH = "BWIN";
		public String FAILED = "FAIL";
		public String NOTAPPLICABLE = "NAPP";
	}

	public interface DealStatus {
		public String INITIALIZATION = "INIT";
		public String FORWARD_SUCCESSFUL = "FSUCC";
		public String FORWARD_FAILED = "FFAIL";
		public String FORWARD_DTP_BATCH_WINDOW = "FBWIN";
		public String SUBMIT_SUCCESSFUL = "SSUCC";
		public String SUBMIT_FAILED = "SFAIL";
		public String SUBMIT_DTP_BATCH_WINDOW = "SBWIN";
	}
	
	public interface DealSubmitUIMessages {
		public String UPDATED = "Data captured in DTP or OTP";
		public String TXNL = "Transaction is locked at DTP or OTP";
		public String NOTINMKR = "Transaction is not in Maker queue at DTP or OTP";
		public String TECHFAIL = "Technical Failure in Submitting the Transaction to DTP/OTP, Please re-try";
		public String BATCH = "DTP is in Batch Mode, Data will be updated when the Batch window is open";
		public String EXCEL_DOWNLOAD = "Excel to be Downloaded";
		public String CHECK_INTEGRITY_FAILED = "Role code already used, please use a different Role code";
		public String DEAL_OP_STATE = "Deal is in OP status , please open the Deal in DTP and re-submit";
	}

	public interface LayoutXmlNodes {
		public String PAGE = "Page";
		public String BLOCK = "Block";
		public String TABLE = "Table";
		public String TITLE = "Title";
		public String FOOTER = "Footer";
		public String LINE = "L";
		public String WORD = "W";
		public String SPACE = "S";
		public String TAB = "Tab";
	}

	public interface HttpHeaders {
		public String COMMOBJ_DIRECTION = "commobj-direction";
		public String COMMOBJ_EVENT_STEP = "commobj-event-step";
		public String COMMOBJ_USER_ID = "commobj-user-id";
		public String COMMOBJ_TO_SYS_CODE = "commobj-to-sys-code";
		public String COMMOBJ_FROM_SYS_CODE = "commobj-from-sys-code";
		public String COMMOBJ_COMMAND = "commobj-command";
		public String COMMOBJ_CTY_CODE = "commobj-cty-code";
		public String COMMOBJ_BANK_GROUP_CODE = "commobj-bank-group-code";
		public String COMMOBJ_MODULE_FUNCTION_CODE = "commobj-module-function-code";
		public String COMMOBJ_MODULE_CODE = "commobj-module-code";
		public String COMMOBJ_SERVICE_NAME = "commobj-service-name";
		public String COMMOBJ_UUID = "commobj-uuid";
	}

	public interface HttpHeadersValue {

		public String COMMOBJ_DIRECTION = null;
		public String COMMOBJ_EVENT_STEP = null;
		public String COMMOBJ_USER_ID = null;
		public String COMMOBJ_COMMAND = null;
		public String COMMOBJ_TO_SYS_CODE = "STA";
		public String COMMOBJ_FROM_SYS_CODE = "WEBPORT";
		public String COMMOBJ_CTY_CODE = "SG";
		public String COMMOBJ_BANK_GROUP_CODE = "SCB";
		public String COMMOBJ_MODULE_FUNCTION_CODE = "FindById";
		public String COMMOBJ_MODULE_CODE = "NLP";
		public String COMMOBJ_OCR_NLP_SERVICE_NAME = "OCR-NLP";

	}

	public interface HttpTDHeadersValue {

		public String COMMOBJ_DIRECTION = null;
		public String COMMOBJ_EVENT_STEP = null;
		public String COMMOBJ_USER_ID = null;
		public String COMMOBJ_COMMAND = null;
		public String COMMOBJ_TO_SYS_CODE = "TD";
		public String COMMOBJ_FROM_SYS_CODE = "OTP";
		public String COMMOBJ_CTY_CODE = "SG";
		public String COMMOBJ_BANK_GROUP_CODE = "SCB";
		public String COMMOBJ_MODULE_FUNCTION_CODE = null;
		public String COMMOBJ_MODULE_CODE = "DocumentDownload";
		public String COMMOBJ_OCR_NLP_SERVICE_NAME = "DocumentDownloadService";

	}

	public interface HttpEmailHeadersValue {

		public String COMMOBJ_UUID = null;
		public String COMMOBJ_DIRECTION = null;
		public String COMMOBJ_EVENT_STEP = null;
		public String COMMOBJ_USER_ID = null;
		public String COMMOBJ_COMMAND = null;
		public String COMMOBJ_TO_SYS_CODE = null;
		public String COMMOBJ_FROM_SYS_CODE = "NLP";
		public String COMMOBJ_CTY_CODE = "SG";
		public String COMMOBJ_BANK_GROUP_CODE = "SCB";
		public String COMMOBJ_MODULE_FUNCTION_CODE = null;
		public String COMMOBJ_MODULE_CODE = null;
		public String COMMOBJ_OCR_NLP_SERVICE_NAME = "emailutil";

	}

	public interface ModuleFunctionCodes {

		public String INITIATE_NLP_PROCESS_MODULE = "INITIATE_NLP_PROCESS";
		public String GET_DEAL_WITH_IMAGES = "NLP_GET_DEAL_WITH_IMAGE";
		public String POST_TO_DTP = "POST_TO_DTP";
		public String APPLY_NLP = "APPLY_NLP";
		public String APPLY_DATA_EXTRACTION = "APPLY_DATA_EXTRACTION";
		public String APPLY_TEMPLATE = "APPLY_TEMPLATE";
		public String READ_LAYOUT = "READ_LAYOUT";

		public String UPDATE_FINAL_DEAL_RES = "UPDATE_FINAL_DEAL_RES";
		public String PROCESSED_TEMPLATE_FEEDBACK = "PROCESSED_TEMPLATE_FEEDBACK_HANDLER";
		public String UPDATE_DTP_OLD_PARTIES = "UPDATE_DTP_OLD_PARTY";

		public String UPDATE_WEX_TO_PROCESSED_DICT = "UPDATE_WEX_TO_PROCESSED_DICTIONARY"; // TNLP-971
		public String UPDATE_WEX_FEEDBACK_PROCESS = "UPDATE_WEX_FEEDBACK_PROCESS"; // TNLP-976
		public String UPDATE_WEX_SERVER_STATUS = "UPDATE_WEX_SERVER_STATUS"; // TNLP-959

		public String FINAL_SUBMIT_DATACAP_RES = "FINAL_SUBMIT_DATACAP_RES";
		public String PROCESS_WEX_TEMPLATE_RESULTS = "PROCESS_WEX_TEMPLATE_RESULTS";
		public String INITIATE_NLP_ENRICH_LAYOUT = "INITIATE_NLP_ENRICH_LAYOUT";
		public String DEAL_STATUS_RELEASED_MODULE = "DEAL_STATUS_RELEASED";
		public String DEAL_FINAL_SUBMIT = "DEAL_FINAL_SUBMIT";
		public String PROCESS_DATA_EXTRACTION_RESULT = "PROCESS_DATA_EXTRACTION_RESULT";
		public String DEAL_ADHOC_STATUS_UPDATE = "DEAL_ADHOC_STATUS_UPDATE";

	}

	public interface Sections {

		public String DEAL_OBJECT = "SCBOcrNlpDealObject";
		public String GET_DEAL_OBJECT = "SCBOcrNlpGetDealObject";
		public String GET_TD_SECTION = "sCBUploadDocuments";
		public String DTP_REQUEST_INFO = "SCBOcrNlpDealDataObjectExtn";
		public String GET_WEX_DATA_SECTION = "SCBWexData";
		public String INITIATE_NLP_PROCESS = "SCBOcrNlpDataObj";
		public String SCB_DATACAP_SCAN = "SCBOcrNlpDatacapScan";
		public String SCB_FINAL_DEAL_RESPONSE = "SCBOcrNlpDealDataObjectExtn";
		public String OTP_OTHRS_REQUEST_INFO = "SCBOcrNlpDealDataObjectExtn";
		public String OTP_NEW_REQUEST_INFO = "SCBOcrNlpDealDataObjectExtn";
		public String DEAL_PRODUCT_TYPE = "SCBOcrNlpDealProductType";
		public String DATACAP_SCAN = "SCBOcrNlpDatacapScan";
		public String EMAIL_RESPONSE = "SCBOcrNlpEmailData";
		public String WEX_DICTIONARY_ENTRIES = "SCBOcrNlpWEXDictionaryEntries";

		public String FINAL_SUBMIT_DATACAP_REQ_SECTION = "SCBOcrNlpDatacapTemplateFeedback";
		public String FINAL_SUBMIT_DATACAP_RES_SECTION = "SCBOcrNlpDatacapFeedbackResponse";

		public String TEMPLATE_DATA_SECTION = "SCBOcrNlpTemplate";
		public String GET_ACTIVE_WEX_SERVER = "ActiveWexServer";

		public String GET_DTP_OLD_PARTIES = "SCBOcrNlpDTPFetchScreenDetails";
		public String WEX_PAGE_INFO = "SCBOcrNlpWexPageInfo";
		public String TXN_FLAT = "txnFlat";
		public String SCB_UPDATE_AND_GET_DEAL = "SCBOcrNlpUpDateGetDeal";
		public String NLP_EVENT_INFO = "eventInfo";
		public String DTP_BATCH_STATUS = "SCBOcrNlpDTPBatchStatus";

	}

	public interface HighLightTypes {
		public String NAME = "name";
		public String ADDR1 = "address1";
		public String ADDR2 = "address2";
		public String ADDR3 = "address3";
		public String COUNTRY = "countryCode";
	}

	public interface ModuleCodes {
		public String NLP = "NLP";
		public String COMM = "NLP-COMM";
		public String FORWARD = "NLP-FORWARD";
		public String SUBMIT = "NLP-SUBMIT";
		public String WEX = "NLP-WEX";
	}

	public interface FlowType {

		public String FLOW_TYPE = "flowType";
		public String SUBMIT = "SUBMIT";
		public String FORWARD_FLOW = "FORWARD";
		public String SUBMIT_DTP_FLOW = "SUBMIT-DTP";
		public String SUBMIT_OTP_OTH_FLOW = "SUBMIT-OTP-OTH";
		public String SUBMIT_OTP_NEW_FLOW = "SUBMIT-OTP-NEW";
		public String UNLOCK_TD = "UNLOCK-TD";
		public String FORWARD_DTP_BATCH_FLOW = "FORWARD-DTP-BATCH";
		public String SUBMIT_DTP_SYNC = "DTP-SUBMIT-SYNC";
		public String ADHOC_DTP_SYNC = "DTP-ADHOC-SYNC";

	}
	
	public interface DTPFetchFields {

		public String COUNTRY_CODE = "countryCode";
		public String CUSTOMER_ID = "customerId";
		public String DEAL_REFERANCE = "dealReferance";
		public String PRODUCT_CODE = "productCode";
		public String STEP_CODE = "stepCode";
		public String PARTY_DETAILS_LIST = "partyDetails";
		public String PARTY_ROLE = "partyRole";
		public String PARTY_NAME = "partyName";
		public String PARTY_ID = "partyId";
		public String PARTY_EXTN_ID = "partyExtId";
		public String PARTY_ADDRESS1 = "address1";
		public String PARTY_ADDRESS2 = "address2";
		public String PARTY_ADDRESS3 = "address3";
		public String PARTY_COUNTRY = "addCtyCode";
		public String PARTY_DOC_NUMBER = "docNumber";
		public String PARTY_CREATED_STEP = "createdStep";
		public String PARTY_OP_CODE = "opCode";

	}

	public interface Fields {
		public String TP_FF_ST = "tpForwardFlowStartTime";
		public String TP_FF_ET = "tpForwardFlowEndTime";
		public String DEAL_ID = "dealid";
		public String COUNTRY_CODE = "countrycode";
		public String REG_TIME_STAMP = "regtimestamp";
		public String TD_APP_REF_ID = "tdApplicationReferenceId";
		public String TP_FF_STATUS = "forwardTpCallStatus";
		public String LOG_DEAL_ID = "logDealId";
		public String LOG_COUNTRY_CODE = "logCountryCode";
		public String LOG_REG_TIME_STAMP = "logRegTimeStamp";
		public String LOG_TD_APP_REF_ID = "logTdApplicationReferenceId";
		public String SCREEN_NAMES = "screeningNames";
		public String ERRORS = "errors";
		public String NA = "NAPP";
		public String DEAL_Id = "dealId";
		public String CUSTOMER_ID = "customerid";
		public String PRODUCT_ID = "productId";
		public String STEP_ID = "stepId";

		public String TD_FF_ST = "tdForwardFlowStartTime";
		public String TD_FF_ET = "tdForwardFlowEndTime";

		public String WEXCALL_STATUS = "wexCallStatus";
		public String WEX_TEMPLATE_CALL_STATUS = "wexTemplateCallStatus";
		public String TD_FF_STAGE_STATUS = "forwardTdStageCallStatus";
		public String TD_FF_STATUS_CALL = "forwardTdStatusCallStatus";
		public String LOG_FLOW_TYPE = "logFlowType";
		public String DIGITIZER_STATUS = "digitizerStatus";
		public String TD_FORWARD = "TDFORWARD";
		public String TP_FORWARD = "TPFORWARD";
		public String PENDING = "PENDING";

		public String TP_SUB_ST = "tpSubmitFlowStartTime";
		public String TP_SUB_ET = "tpSubmitFlowEndTime";
		public String TD_SUB_ST = "tdSubmitFlowStartTime";
		public String TD_SUB_ET = "tdSubmitFlowEndTime";

		public String TP_SUB_CALL_STATUS = "submitTpCallStatus";
		public String TP_SUB_SYNC_STATUS = "submitTpSyncStatus";
		public String TD_SUB_STAGE_CALL_STATUS = "submitTdStageCallStatus";
		public String TD_SUB_STATUS_CALL_STATUS = "submitTdStatusCallStatus";

		public String DATACAP_FEEDBACK_ST = "datacapFeedbackFlowStartTime";
		public String DATACAP_FEEDBACK_ET = "datacapFeedbackFlowEndTime";
		public String DATACAP_FEEDBACK_STATUS = "datacapFeedbackStatus";
		
		public String DEAL_FINAL_SUBMIT_STATUS = "finalSubmitDealStatus";

		public String DTP_REQ_PAYLOAD = "dtprequestPayload";
		public String SANCTION_PARTIES_REQ = "sanctionPartiesRequest";
		public String OTP_OTH_REQ_PAYLOAD = "otpothrsrequestPayload";
		public String OTP_NEW_REQ_PAYLOAD = "otpnewrequestPayload";
		public String DOC_CREATE_REQ = "docCreateRequest";
		public String LOGGER_DEAL_ID = "loggerDealId";

		public String FILE_ORIGINAL_PAYLOAD = "fileOriginalPayload";
		public String FILE_PAGE_COUNTER = "filePageCounter";

		public String PROCESS_ID = "processId";
		public String DATACAP_SCANID = "datacapScanId";
		public String FINAL_PAYLOAD_TO_NLP = "finalPayloadToNLP";
		public String SINGLE_PAGE_OPERATION_TYPE = "singlePageOperationType";
		public String PRE_DOWNLOAD = "PRE-DOWNLOAD";
		public String SINGLE_PAGE_DOWNLOADABLE = "singlePageDownloadable";

		public String SINGLE_PAGE_FILEID = "singlePageFileId";
		public String SINGLE_PAGE_COUNTRY_CODE = "singlePageCountryCode";
		public String STATUS = "status";

		public String FILE_OPER_STATUS = "fileOperationStatus";
		public String POST_DOWNLOAD = "POST-DOWNLOAD";
		public String POST_SAVE = "POST-SAVE";
		public String REQUEST_TYPE = "requestType";
		public String ENABLE_ICON = "enableIcon";
		public String RELEASE_TXN_LOCK = "releaseTxnLock";
		public String CUR_TD_TXN_STAGECODE = "curTDTxnStageCode";
		public String REG_TIME_MS_STR = "regTimeMsStr";
		public String SYSTEM_CODE = "systemCode";
		public String REQ_STATUS = "requestStatus";
		public String TD_TXN_STAGE_CODE = "tdTxnStageCode";
		public String DTP_RESPONSE_PAYLOAD = "dtpresponsePayload";
		public String NAMES_SCREENING_RESPONSE = "namesScreeningResponse";
		public String STAGE_CALL_INITIATE_STATUS = "stageCallInitiateStatus";
		public String BATCH_PAGE_COUNTER = "batchPageCounter";
		public String ORIGINAL_PAYLOAD = "originalMessagePayload";
		public String BATCH_OPERATION_TYPE = "batchOperationType";
		public String BATCH_INDIVIDUAL_PAYLOAD = "individualMessagePayload";

		public String YES = "YES";
		public String NO = "NO";
		public String TXNLOC = "TXNLOC";
		public String NOT_MAKR = "NOTMAKR";

		public String OTP_OTH_RES_PAYLOAD = "otpothrsresponsePayload";
		public String OTP_NEW_RES_PAYLOAD = "otpnewresponsePayload";

		public String DOC_CREATE_RES = "documentCreateResponse";

		public String DIGITIZER = "Digitizer";

		public String STATUS_MVMNT_RES_PAYLOAD = "statusMvmntResponsePayload";
		public String STAGE_MVMNT_RES_PAYLOAD = "stageMvmntResponsePayload";

		public String STATUS_SUCCESS = "SUCCESS";
		public String TD_STATUS_MVMT_RES = "tdStatusMvmtResponse";
		public String TD_STAGE_MVMT_RES = "tdStageMvmtResponse";
		public String DSUC = "DSUC";
		public String TDFL = "TDFL";
		public String TPFL = "TPFL";
		String FINAL_WEX_PLAYLOAD = "finalWEXReturnPayload";
		String BINARY = "BINARY::";
		String INDEX_COUNT = "indexCount";
		String WEX_SERVER_CODE = "wexServerCode";
		String DOCUMENT_ID = "documentId";
		String LAYOUT_TEXT = "layoutText";
		String INDEX_COUNT_TEMPLATE = "indexCountTemplate";
		String FINAL_WEX__TEMPLATE_PLAYLOAD = "FinalWEXTemplaeReturnPayload";
		String INDEX_DATA_EXTRACT_COUNT = "indexDataExtractCount";
		String FINAL_WEX_DATA_EXTRACT_PLAYLOAD = "FinalWEXDataExtractReturnPayload";
		public String Y = "Y";
		public String N = "N";
		public String FSUCC = "FSUCC";
		public String SSUCC = "SSUCC";
		public String DTP_SYSTEM = "DTP";
		public String DTP_BATCH_WINDOW = "dtpBatchWindow";
		public String INDEX_COUNT_DATAEXTRACTION = "indexCountDataExtract";
		public String FINAL_WEX_DATAEXTRACTION_RETURN_PAYLOAD = "FinalWEXDataExtractionReturnPayload";
		public String DATA_EXTRACTED_TEXT = "dataExtractedText";
		public String DTP_DATA_ENTRY_PRODUCT_CODES = "03,13";
		public String OCR_NLP = "OCRNLP";
		public String DATA_ENTRY_APPLICABLE = "dataEntryApplicable";
		public String DTP_ISSUANCE = "ISS";
		public String DTP_SYNC = "DTP-SYNC";
		public String SUBMIT_FAILED = "SUBMIT-FAILED";
		public String DTP_BATCH = "DTP-BATCH";
		public String PRE_CHECK_APPLICABLE = "precheckApplicable";
		public String DTP_SYNC_APPLICABLE = "dtpSyncApplicable";
		public String DTP_SYNC_RESPONSE_PAYLOAD = "dtpSyncCheckResponse";
		public String DTP_SYNC_SKIP = "DTP-SYNC-SKIP";
		public String CHECK_SCREEN_NAME = "checkScreenName";
		public String SCREEN_MAIN_SCREEN = "mainScreen";
		public String DTP_SUCCESS_RESPONSE = "UPDATED";
		public String DTP_DELETED_RESPONSE = "DELETED";
		public String DTP_INSERTED_RESPONSE = "INSERTED";
		public String DTP_NOTFOUND_RESPONSE = "NOTFOUND";
		public String EXCEL_DOWNLOAD = "EXCEL-DOWNLOAD";
		public String CHECK_INTEGRITY_FAILED = "INTEGRITY-FAILED";
		public String DEAL_OP_STATE = "DEAL-OP-STATE";
		public String DEAL_RELEASED = "dealReleased";
		public String CALL_ORIGINATION_UI = "callOriginatedFromUI";

	}
}
