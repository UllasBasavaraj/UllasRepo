package com.scb.ms.mule.entity;

public class SCBOcrNlpEmailStringData {

	private String emailSender;
	private String emailReceiver;
	private String emailSubject;
	private String emailBody;

	/**
	 * @return the emailSender
	 */
	public String getEmailSender() {
		return emailSender;
	}

	/**
	 * @param emailSender
	 *            the emailSender to set
	 */
	public void setEmailSender(String emailSender) {
		this.emailSender = emailSender;
	}

	/**
	 * @return the emailReceiver
	 */
	public String getEmailReceiver() {
		return emailReceiver;
	}

	/**
	 * @param emailReceiver
	 *            the emailReceiver to set
	 */
	public void setEmailReceiver(String emailReceiver) {
		this.emailReceiver = emailReceiver;
	}

	/**
	 * @return the emailSubject
	 */
	public String getEmailSubject() {
		return emailSubject;
	}

	/**
	 * @param emailSubject
	 *            the emailSubject to set
	 */
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}

	/**
	 * @return the emailBody
	 */
	public String getEmailBody() {
		return emailBody;
	}

	/**
	 * @param emailBody
	 *            the emailBody to set
	 */
	public void setEmailBody(String emailBody) {
		this.emailBody = emailBody;
	}

}
