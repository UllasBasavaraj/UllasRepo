package com.scb.ms.mule.entity;

import org.springframework.data.annotation.Id;

public class SCBOcrNlpDataEntryFieldsInfo {

	@Id
	private String id;
	private String name = "";
	private boolean mandatory;
	private String type = "";
	private String length = "";
	private boolean approvalReq;
	private String acceptableFormat = "";
	private String isSpecialCharacters = "";
	private String displayName = "";
	private int displayOrder;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the mandatory
	 */
	public boolean getMandatory() {
		return mandatory;
	}

	/**
	 * @param mandatory
	 *            the mandatory to set
	 */
	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the length
	 */
	public String getLength() {
		return length;
	}

	/**
	 * @param length
	 *            the length to set
	 */
	public void setLength(String length) {
		this.length = length;
	}

	/**
	 * @return the approvalReq
	 */
	public boolean getApprovalReq() {
		return approvalReq;
	}

	/**
	 * @param approvalReq
	 *            the approvalReq to set
	 */
	public void setApprovalReq(boolean approvalReq) {
		this.approvalReq = approvalReq;
	}

	/**
	 * @return the acceptableFormat
	 */
	public String getAcceptableFormat() {
		return acceptableFormat;
	}

	/**
	 * @param acceptableFormat
	 *            the acceptableFormat to set
	 */
	public void setAcceptableFormat(String acceptableFormat) {
		this.acceptableFormat = acceptableFormat;
	}

	/**
	 * @return the isSpecialCharacters
	 */
	public String getIsSpecialCharacters() {
		return isSpecialCharacters;
	}

	/**
	 * @param isSpecialCharacters
	 *            the isSpecialCharacters to set
	 */
	public void setIsSpecialCharacters(String isSpecialCharacters) {
		this.isSpecialCharacters = isSpecialCharacters;
	}

	/**
	 * @return the displayName
	 */
	public String getDisplayName() {
		return displayName;
	}

	/**
	 * @param displayName the displayName to set
	 */
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	/**
	 * @return the displayOrder
	 */
	public int getDisplayOrder() {
		return displayOrder;
	}

	/**
	 * @param displayOrder the displayOrder to set
	 */
	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	

}
