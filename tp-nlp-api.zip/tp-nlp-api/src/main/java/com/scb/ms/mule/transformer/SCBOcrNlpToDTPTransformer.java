package com.scb.ms.mule.transformer;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.entity.SCBOcrNlpHighlightList;
import com.scb.ms.mule.entity.SCBOcrNlpNameCaptureList;
import com.scb.ms.mule.entity.SCBOcrNlpNamesScreeningListRequest;
import com.scb.ms.mule.entity.SCBOcrNlpNamesScreeningRequest;
import com.scb.ms.mule.entity.SCBOcrNlpPartyDetails;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.HighLightTypes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpToDTPTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpToDTPTransformer.class);
	private String transformerType;
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String arg1) throws TransformerException {
		log.info("Enter in to SCBNLPToDTPTransformer calss ");
		Object source = null;
		String vppGenericJson = null;
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			SCBCommObj commObj = null;

			String loggerDealId = EMPTY;
			try {
				source = message.getPayload();
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.DTP_REQUEST_INFO));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.DTP_REQUEST_INFO);
				if (null != section) {

					SCBOcrNlpDealDataObjectExtn dealExtn = new SCBOcrNlpDealDataObjectExtn();
					dealExtn = (SCBOcrNlpDealDataObjectExtn) SCBCommObjTransformer.sectionToSCBPojo(commObj, dealExtn);
					if (dealExtn != null) {
							loggerDealId = dealExtn.getDealId();
							vppGenericJson = getDTPRequestJson(mapper, loggerDealId, dealExtn);

					}
				}

			} catch (Exception e) {
				log.error(loggerDealId + " - Error in NLP to DTP Transformer" + e);
				throw new TransformerException(CoreMessages.createStaticMessage(
						loggerDealId + " - Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return vppGenericJson;
	}

	private String getDTPRequestJson(ObjectMapper mapper, String loggerDealId, SCBOcrNlpDealDataObjectExtn dealExtn) {
		SCBOcrNlpNamesScreeningRequest namesScreeningReq = null;
		SCBOcrNlpNamesScreeningListRequest nameScreeningReqObj = null;
		String vppGenericJson = null;

		try {
			namesScreeningReq = new SCBOcrNlpNamesScreeningRequest();
			namesScreeningReq.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
			namesScreeningReq.setSystemCode(dealExtn.getSystemCode());
			namesScreeningReq.setCountryCode(dealExtn.getCountry());
			namesScreeningReq.setCustomerId(dealExtn.getClientId());
			namesScreeningReq.setDealReferance(dealExtn.getDealId());
			namesScreeningReq.setProductCode(dealExtn.getProductId());
			namesScreeningReq.setRegTimeStamp(dealExtn.getRegTimeMsStr());
			namesScreeningReq.setStepCode(dealExtn.getStepId());
			List<SCBOcrNlpNameCaptureList> namecaptureList = dealExtn.getNameCaptureList();
			List<SCBOcrNlpPartyDetails> partyDetailsList = new ArrayList<SCBOcrNlpPartyDetails>();

			if (CollectionUtils.isNotEmpty(namecaptureList)) {
				for (SCBOcrNlpNameCaptureList namecaptureObj : namecaptureList) {
					SCBOcrNlpPartyDetails partyDetailsObj = new SCBOcrNlpPartyDetails();
					partyDetailsObj.setPartyExtId(namecaptureObj.getExtensionId());
					partyDetailsObj.setPartyId(namecaptureObj.getPartyId());
					partyDetailsObj.setPartyRole(namecaptureObj.getRoleCode());
					partyDetailsObj.setDocNumber(EMPTY);
					partyDetailsObj.setOpCode(namecaptureObj.getRoleStatus());
					List<SCBOcrNlpHighlightList> highLightList = namecaptureObj.getHighlightsList();
					if (CollectionUtils.isNotEmpty(highLightList)) {
						for (SCBOcrNlpHighlightList highLightObj : highLightList) {
							switch (highLightObj.getType()) {
							case HighLightTypes.NAME:
								partyDetailsObj.setPartyName(highLightObj.getValue() != null
										? highLightObj.getValue().toUpperCase() : EMPTY);
								break;
							case HighLightTypes.ADDR1:
								partyDetailsObj.setAddress1(highLightObj.getValue() != null
										? highLightObj.getValue().toUpperCase() : EMPTY);
								break;
							case HighLightTypes.ADDR2:
								partyDetailsObj.setAddress2(highLightObj.getValue() != null
										? highLightObj.getValue().toUpperCase() : EMPTY);
								break;
							case HighLightTypes.ADDR3:
								partyDetailsObj.setAddress3(highLightObj.getValue() != null
										? highLightObj.getValue().toUpperCase() : EMPTY);
								break;
							case HighLightTypes.COUNTRY:
								partyDetailsObj.setAddCtyCode(namecaptureObj.getCountryCode());
								break;
							default:
								log.error(loggerDealId + " - No Highlight list match");
							}
						}
					}
					partyDetailsList.add(partyDetailsObj);
				}
			}

			namesScreeningReq.setPartyDetails(partyDetailsList);
			nameScreeningReqObj = new SCBOcrNlpNamesScreeningListRequest();
			nameScreeningReqObj.setSanctionPartiesRequest(namesScreeningReq);
			vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(nameScreeningReqObj);
			log.debug(loggerDealId + " - Name Screening request to DTP system  ==>" + vppGenericJson);
		} catch (Exception e) {
			log.error(loggerDealId + " - Error in NLP to DTP Transformer" + e);
		}
		return vppGenericJson;
	}

	public String getTransformerType() {
		return transformerType;
	}

	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}

}
