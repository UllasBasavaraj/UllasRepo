package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.elasticsearch.common.lang3.StringUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.mule.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.datatypes.SCBDataTable;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.entity.SCBOcrNlpDealObject;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Fields;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.FlowType;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleFunctionCodes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpBatchTriggerTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpBatchTriggerTransformer.class);
	private static final String SUBMIT = "SUBMIT";
	private static final String FORWARD = "FORWARD";
	private static String dealDataList = "dealDataList";
	private static String countryStr = "country";
	private static String dealIdStr = "dealId";
	private static String stepIdStr = "stepId";
	private static String tdApplicationReferenceIdStr = "tdApplicationReferenceId";
	private static String clientIdStr = "clientId";
	private static String productIdStr = "productId";
	private static String sysStatusStr = "sysStatus";
	private static String regTimeStampStr = "regTimeStamp";
	private static String dealReleasedStatus = "dealReleasedStatus";
	private static String systemCodeStr = "systemCode";
	private static String responseStr = "response";
	
	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		log.info("Enter in to SCBOcrNlpBatchTriggerTransformer calss ");
		
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object source = message.getInvocationProperty(Fields.ORIGINAL_PAYLOAD);
			SCBCommObj commObj = null;
			try {
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.DEAL_OBJECT));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.DEAL_OBJECT);

				if (null != section) {

					SCBDataTable tableData = section.getTableData().get(dealDataList);
					int iCounter = new Integer (message.getInvocationProperty(Fields.BATCH_PAGE_COUNTER, "")).intValue();
					if(CollectionUtils.isNotEmpty(tableData.getRowData()) && iCounter > 0){
						String countryCode = (String)tableData.getRowAt(iCounter-1).get(countryStr);
						String dealId = (String)tableData.getRowAt(iCounter-1).get(dealIdStr);
						String stepId = (String)tableData.getRowAt(iCounter-1).get(stepIdStr);
						String tdApplicationReferenceId = (String)tableData.getRowAt(iCounter-1).get(tdApplicationReferenceIdStr);
						String clientId = (String)tableData.getRowAt(iCounter-1).get(clientIdStr);
						String productId = (String)tableData.getRowAt(iCounter-1).get(productIdStr);
						boolean sysStatus = (Boolean)tableData.getRowAt(iCounter-1).get(sysStatusStr);
						String regTimeStamp = (String)tableData.getRowAt(iCounter-1).get(regTimeStampStr);
						String dealReleased = (String)tableData.getRowAt(iCounter-1).get(dealReleasedStatus);
						String systemCode = (String)tableData.getRowAt(iCounter-1).get(systemCodeStr);
						String response = (String)tableData.getRowAt(iCounter-1).get(responseStr);
						
						if(StringUtils.isNotEmpty(response) && response.equalsIgnoreCase(SUBMIT)){
							message.setInvocationProperty(Fields.BATCH_OPERATION_TYPE, SUBMIT);
							SCBOcrNlpDealDataObjectExtn dealExtnObj = new SCBOcrNlpDealDataObjectExtn();

							dealExtnObj.setDealId(dealId);
							dealExtnObj.setCountry(countryCode);
							dealExtnObj.setProductId(productId);
							dealExtnObj.setStepId(stepId);
							dealExtnObj.setClientId(clientId);
							dealExtnObj.setRegTimeStamp(regTimeStamp);
							dealExtnObj.setTdApplicationReferenceId(tdApplicationReferenceId);
							dealExtnObj.setSystemCode(systemCode);
							
							SCBCommObj rqstObj = new SCBCommObj();
							SCBHeader scbHeader = new SCBHeader();
							SCBFooter scbFooter = new SCBFooter();
							
							scbHeader = SCBOcrNlpUtil.createSCBNlpHeaderObject(ModuleCodes.SUBMIT);
							scbHeader.setModuleFunctionCode(ModuleFunctionCodes.DEAL_FINAL_SUBMIT);
							rqstObj.setHeader(scbHeader);
							rqstObj.setFooter(scbFooter);

							rqstObj.getBody().addSection(
									SCBCommObjTransformer.pojoToSection(dealExtnObj, SCBOcrNlpDealDataObjectExtn.class));
							
							String payload = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(rqstObj);
							message.setInvocationProperty(Fields.BATCH_INDIVIDUAL_PAYLOAD, payload);
						} else if (StringUtils.isNotEmpty(response) && response.equalsIgnoreCase(FORWARD)){
							message.setInvocationProperty(Fields.BATCH_OPERATION_TYPE, FORWARD);
							
							String payload = "{ \"countrycode\" : \""+countryCode+"\" , ";
							payload = payload + " \"customerid\" : \""+clientId+"\" , ";
							payload = payload + " \"regtimestamp\" : \""+regTimeStamp+"\" , ";
							payload = payload + " \"tdApplicationReferenceId\" : \""+tdApplicationReferenceId+"\" , ";
							payload = payload + " \"productId\" : \""+productId+"\" , ";
							payload = payload + " \"stepId\" : \""+stepId+"\" , ";
							payload = payload + " \"flowType\" : \""+FlowType.FORWARD_DTP_BATCH_FLOW+"\" , ";
							if (sysStatus) {
								payload = payload + " \"dtpBatchWindow\" : \"NO\" , ";
							} else {
								payload = payload + " \"dtpBatchWindow\" : \"YES\" , ";
							}
							payload = payload + " \"dealid\" : \""+dealId+"\" } ";
							
							message.setInvocationProperty(Fields.BATCH_INDIVIDUAL_PAYLOAD, payload);
						} 
						// check if its forward or submit
						// if forward construct forward message
						// if submit construct submit message
						// put it in variable 
						// set the variable type
					}
						


				} 
			} catch (Exception e) {
				log.error("error in SCBOcrNlpBatchTriggerTransformer" + e);
				throw new TransformerException(
						CoreMessages.createStaticMessage("Unable to transform commobj to Generic Json" + source), e);
			}
		}
		return null;
	}

}
