package com.scb.ms.mule.entity;

public class SCBOcrNlpTextCoordinatesList {

	private String id;
	private int x1;
	private int y1;
	private int x2;
	private int y2;
	private String value;
	private int charStart;
	private int charEnd;
	private boolean specialCharIndentifiedByApp;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the x1
	 */
	public int getX1() {
		return x1;
	}

	/**
	 * @param x1
	 *            the x1 to set
	 */
	public void setX1(int x1) {
		this.x1 = x1;
	}

	/**
	 * @return the y1
	 */
	public int getY1() {
		return y1;
	}

	/**
	 * @param y1
	 *            the y1 to set
	 */
	public void setY1(int y1) {
		this.y1 = y1;
	}

	/**
	 * @return the x2
	 */
	public int getX2() {
		return x2;
	}

	/**
	 * @param x2
	 *            the x2 to set
	 */
	public void setX2(int x2) {
		this.x2 = x2;
	}

	/**
	 * @return the y2
	 */
	public int getY2() {
		return y2;
	}

	/**
	 * @param y2
	 *            the y2 to set
	 */
	public void setY2(int y2) {
		this.y2 = y2;
	}

	/**
	 * @return the value
	 */
	public String getValue() {
		return value;
	}

	/**
	 * @param value
	 *            the value to set
	 */
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * @return the charStart
	 */
	public int getCharStart() {
		return charStart;
	}

	/**
	 * @param charStart
	 *            the charStart to set
	 */
	public void setCharStart(int charStart) {
		this.charStart = charStart;
	}

	/**
	 * @return the charEnd
	 */
	public int getCharEnd() {
		return charEnd;
	}

	/**
	 * @param charEnd
	 *            the charEnd to set
	 */
	public void setCharEnd(int charEnd) {
		this.charEnd = charEnd;
	}

	/**
	 * @return the specialCharIndentifiedByApp
	 */
	public boolean isSpecialCharIndentifiedByApp() {
		return specialCharIndentifiedByApp;
	}

	/**
	 * @param specialCharIndentifiedByApp
	 *            the specialCharIndentifiedByApp to set
	 */
	public void setSpecialCharIndentifiedByApp(boolean specialCharIndentifiedByApp) {
		this.specialCharIndentifiedByApp = specialCharIndentifiedByApp;
	}

}
