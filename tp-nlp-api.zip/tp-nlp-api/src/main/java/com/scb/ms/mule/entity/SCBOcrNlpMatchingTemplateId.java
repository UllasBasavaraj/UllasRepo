package com.scb.ms.mule.entity;

public class SCBOcrNlpMatchingTemplateId {

	private int templateId;
	private String imageOffSet = "";

	/**
	 * @return the templateId
	 */
	public int getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the imageOffSet
	 */
	public String getImageOffSet() {
		return imageOffSet;
	}

	/**
	 * @param imageOffSet
	 *            the imageOffSet to set
	 */
	public void setImageOffSet(String imageOffSet) {
		this.imageOffSet = imageOffSet;
	}

}
