package com.scb.ms.mule.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SCBOcrNlpDatacapFeedbackResponse {

	@JsonProperty("BatchID")
	private String batchId;
	@JsonProperty("QueueID")
	private String queueId;

	/**
	 * @return the batchId
	 */
	public String getBatchId() {
		return batchId;
	}

	/**
	 * @param batchId
	 *            the batchId to set
	 */
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	/**
	 * @return the queueId
	 */
	public String getQueueId() {
		return queueId;
	}

	/**
	 * @param queueId
	 *            the queueId to set
	 */
	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

}
