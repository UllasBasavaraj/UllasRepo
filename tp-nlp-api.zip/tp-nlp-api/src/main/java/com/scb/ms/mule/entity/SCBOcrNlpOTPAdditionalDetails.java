package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Transient;


public class SCBOcrNlpOTPAdditionalDetails {

	private String notifyPartyName1 = "";
	private String notifyPartyCty1 = "";
	private String notifyPartyName2 = "";
	private String notifyPartyCty2 = "";
	private String agentsName1 = "";
	private String agentsCty1 = "";
	private String agentsName2 = "";
	private String agentsCty2 = "";
	private String shipAirlineName = "";
	private String shipAirlineCty = "";
	private String thirdPartyName1 = "";
	private String thirdPartyCty1 = "";
	private String thirdPartyName2 = "";
	private String thirdPartyCty2 = "";
	private String thirdPartyName3 = "";
	private String thirdPartyCty3 = "";
	private String carrier = "";
	private String carrierCty = "";
	private String consignee = "";
	private String consigneeCty = "";
	private String shipper = "";
	private String shipperCty = "";
	private String forwardCompName = "";
	private String forwardCompCty = "";
	private String finalDestOfGoods = "";
	private String finalDestOfGoodsCty = "";
	private String portOfShipment = "";
	private String portOfShipmentCty = "";
	private String placeOfTakingCharge = "";
	private String placeOfTakingChargeCty = "";
	private List<SCBOcrNlpOTPOtherParties> otherParties = new ArrayList<SCBOcrNlpOTPOtherParties>();


	/**
	 * @return the notifyPartyName1
	 */
	public String getNotifyPartyName1() {
		return notifyPartyName1;
	}

	/**
	 * @param notifyPartyName1
	 *            the notifyPartyName1 to set
	 */
	public void setNotifyPartyName1(String notifyPartyName1) {
		this.notifyPartyName1 = notifyPartyName1;
	}

	/**
	 * @return the notifyPartyCty1
	 */
	public String getNotifyPartyCty1() {
		return notifyPartyCty1;
	}

	/**
	 * @param notifyPartyCty1
	 *            the notifyPartyCty1 to set
	 */
	public void setNotifyPartyCty1(String notifyPartyCty1) {
		this.notifyPartyCty1 = notifyPartyCty1;
	}

	/**
	 * @return the notifyPartyName2
	 */
	public String getNotifyPartyName2() {
		return notifyPartyName2;
	}

	/**
	 * @param notifyPartyName2
	 *            the notifyPartyName2 to set
	 */
	public void setNotifyPartyName2(String notifyPartyName2) {
		this.notifyPartyName2 = notifyPartyName2;
	}

	/**
	 * @return the notifyPartyCty2
	 */
	public String getNotifyPartyCty2() {
		return notifyPartyCty2;
	}

	/**
	 * @param notifyPartyCty2
	 *            the notifyPartyCty2 to set
	 */
	public void setNotifyPartyCty2(String notifyPartyCty2) {
		this.notifyPartyCty2 = notifyPartyCty2;
	}

	/**
	 * @return the agentsName1
	 */
	public String getAgentsName1() {
		return agentsName1;
	}

	/**
	 * @param agentsName1
	 *            the agentsName1 to set
	 */
	public void setAgentsName1(String agentsName1) {
		this.agentsName1 = agentsName1;
	}

	/**
	 * @return the agentsCty1
	 */
	public String getAgentsCty1() {
		return agentsCty1;
	}

	/**
	 * @param agentsCty1
	 *            the agentsCty1 to set
	 */
	public void setAgentsCty1(String agentsCty1) {
		this.agentsCty1 = agentsCty1;
	}

	/**
	 * @return the agentsName2
	 */
	public String getAgentsName2() {
		return agentsName2;
	}

	/**
	 * @param agentsName2
	 *            the agentsName2 to set
	 */
	public void setAgentsName2(String agentsName2) {
		this.agentsName2 = agentsName2;
	}

	/**
	 * @return the agentsCty2
	 */
	public String getAgentsCty2() {
		return agentsCty2;
	}

	/**
	 * @param agentsCty2
	 *            the agentsCty2 to set
	 */
	public void setAgentsCty2(String agentsCty2) {
		this.agentsCty2 = agentsCty2;
	}

	/**
	 * @return the shipAirlineName
	 */
	public String getShipAirlineName() {
		return shipAirlineName;
	}

	/**
	 * @param shipAirlineName
	 *            the shipAirlineName to set
	 */
	public void setShipAirlineName(String shipAirlineName) {
		this.shipAirlineName = shipAirlineName;
	}

	/**
	 * @return the shipAirlineCty
	 */
	public String getShipAirlineCty() {
		return shipAirlineCty;
	}

	/**
	 * @param shipAirlineCty
	 *            the shipAirlineCty to set
	 */
	public void setShipAirlineCty(String shipAirlineCty) {
		this.shipAirlineCty = shipAirlineCty;
	}

	/**
	 * @return the thirdPartyName1
	 */
	public String getThirdPartyName1() {
		return thirdPartyName1;
	}

	/**
	 * @param thirdPartyName1
	 *            the thirdPartyName1 to set
	 */
	public void setThirdPartyName1(String thirdPartyName1) {
		this.thirdPartyName1 = thirdPartyName1;
	}

	/**
	 * @return the thirdPartyCty1
	 */
	public String getThirdPartyCty1() {
		return thirdPartyCty1;
	}

	/**
	 * @param thirdPartyCty1
	 *            the thirdPartyCty1 to set
	 */
	public void setThirdPartyCty1(String thirdPartyCty1) {
		this.thirdPartyCty1 = thirdPartyCty1;
	}

	/**
	 * @return the thirdPartyName2
	 */
	public String getThirdPartyName2() {
		return thirdPartyName2;
	}

	/**
	 * @param thirdPartyName2
	 *            the thirdPartyName2 to set
	 */
	public void setThirdPartyName2(String thirdPartyName2) {
		this.thirdPartyName2 = thirdPartyName2;
	}

	/**
	 * @return the thirdPartyCty2
	 */
	public String getThirdPartyCty2() {
		return thirdPartyCty2;
	}

	/**
	 * @param thirdPartyCty2
	 *            the thirdPartyCty2 to set
	 */
	public void setThirdPartyCty2(String thirdPartyCty2) {
		this.thirdPartyCty2 = thirdPartyCty2;
	}

	/**
	 * @return the thirdPartyName3
	 */
	public String getThirdPartyName3() {
		return thirdPartyName3;
	}

	/**
	 * @param thirdPartyName3
	 *            the thirdPartyName3 to set
	 */
	public void setThirdPartyName3(String thirdPartyName3) {
		this.thirdPartyName3 = thirdPartyName3;
	}

	/**
	 * @return the thirdPartyCty3
	 */
	public String getThirdPartyCty3() {
		return thirdPartyCty3;
	}

	/**
	 * @param thirdPartyCty3
	 *            the thirdPartyCty3 to set
	 */
	public void setThirdPartyCty3(String thirdPartyCty3) {
		this.thirdPartyCty3 = thirdPartyCty3;
	}

	/**
	 * @return the carrier
	 */
	public String getCarrier() {
		return carrier;
	}

	/**
	 * @param carrier
	 *            the carrier to set
	 */
	public void setCarrier(String carrier) {
		this.carrier = carrier;
	}

	/**
	 * @return the carrierCty
	 */
	public String getCarrierCty() {
		return carrierCty;
	}

	/**
	 * @param carrierCty
	 *            the carrierCty to set
	 */
	public void setCarrierCty(String carrierCty) {
		this.carrierCty = carrierCty;
	}

	/**
	 * @return the consignee
	 */
	public String getConsignee() {
		return consignee;
	}

	/**
	 * @param consignee
	 *            the consignee to set
	 */
	public void setConsignee(String consignee) {
		this.consignee = consignee;
	}

	/**
	 * @return the consigneeCty
	 */
	public String getConsigneeCty() {
		return consigneeCty;
	}

	/**
	 * @param consigneeCty
	 *            the consigneeCty to set
	 */
	public void setConsigneeCty(String consigneeCty) {
		this.consigneeCty = consigneeCty;
	}

	/**
	 * @return the shipper
	 */
	public String getShipper() {
		return shipper;
	}

	/**
	 * @param shipper
	 *            the shipper to set
	 */
	public void setShipper(String shipper) {
		this.shipper = shipper;
	}

	/**
	 * @return the shipperCty
	 */
	public String getShipperCty() {
		return shipperCty;
	}

	/**
	 * @param shipperCty
	 *            the shipperCty to set
	 */
	public void setShipperCty(String shipperCty) {
		this.shipperCty = shipperCty;
	}

	/**
	 * @return the forwardCompName
	 */
	public String getForwardCompName() {
		return forwardCompName;
	}

	/**
	 * @param forwardCompName
	 *            the forwardCompName to set
	 */
	public void setForwardCompName(String forwardCompName) {
		this.forwardCompName = forwardCompName;
	}

	/**
	 * @return the forwardCompCty
	 */
	public String getForwardCompCty() {
		return forwardCompCty;
	}

	/**
	 * @param forwardCompCty
	 *            the forwardCompCty to set
	 */
	public void setForwardCompCty(String forwardCompCty) {
		this.forwardCompCty = forwardCompCty;
	}

	/**
	 * @return the finalDestOfGoods
	 */
	public String getFinalDestOfGoods() {
		return finalDestOfGoods;
	}

	/**
	 * @param finalDestOfGoods
	 *            the finalDestOfGoods to set
	 */
	public void setFinalDestOfGoods(String finalDestOfGoods) {
		this.finalDestOfGoods = finalDestOfGoods;
	}

	/**
	 * @return the finalDestOfGoodsCty
	 */
	public String getFinalDestOfGoodsCty() {
		return finalDestOfGoodsCty;
	}

	/**
	 * @param finalDestOfGoodsCty
	 *            the finalDestOfGoodsCty to set
	 */
	public void setFinalDestOfGoodsCty(String finalDestOfGoodsCty) {
		this.finalDestOfGoodsCty = finalDestOfGoodsCty;
	}

	/**
	 * @return the portOfShipment
	 */
	public String getPortOfShipment() {
		return portOfShipment;
	}

	/**
	 * @param portOfShipment
	 *            the portOfShipment to set
	 */
	public void setPortOfShipment(String portOfShipment) {
		this.portOfShipment = portOfShipment;
	}

	/**
	 * @return the portOfShipmentCty
	 */
	public String getPortOfShipmentCty() {
		return portOfShipmentCty;
	}

	/**
	 * @param portOfShipmentCty
	 *            the portOfShipmentCty to set
	 */
	public void setPortOfShipmentCty(String portOfShipmentCty) {
		this.portOfShipmentCty = portOfShipmentCty;
	}

	/**
	 * @return the placeOfTakingCharge
	 */
	public String getPlaceOfTakingCharge() {
		return placeOfTakingCharge;
	}

	/**
	 * @param placeOfTakingCharge
	 *            the placeOfTakingCharge to set
	 */
	public void setPlaceOfTakingCharge(String placeOfTakingCharge) {
		this.placeOfTakingCharge = placeOfTakingCharge;
	}

	/**
	 * @return the placeOfTakingChargeCty
	 */
	public String getPlaceOfTakingChargeCty() {
		return placeOfTakingChargeCty;
	}

	/**
	 * @param placeOfTakingChargeCty
	 *            the placeOfTakingChargeCty to set
	 */
	public void setPlaceOfTakingChargeCty(String placeOfTakingChargeCty) {
		this.placeOfTakingChargeCty = placeOfTakingChargeCty;
	}

	/**
	 * @return the otherParties
	 */
	public List<SCBOcrNlpOTPOtherParties> getOtherParties() {
		return otherParties;
	}

	/**
	 * @param otherParties
	 *            the otherParties to set
	 */
	public void setOtherParties(List<SCBOcrNlpOTPOtherParties> otherParties) {
		this.otherParties = otherParties;
	}


}
