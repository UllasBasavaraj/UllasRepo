package com.scb.ms.mule.transformer;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.transformer.exception.SCBTransformException;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpWEXDictionaryEntries;
import com.scb.ms.mule.util.SCBOcrNlpUtil;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;

public class SCBOcrNlpWexDictEntriesProcessedToNlpTransformer extends AbstractMessageTransformer {

	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOcrNlpWexDictEntriesProcessedToNlpTransformer.class);

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		LOGGER.info("Enter in to Mule Wex Dictionary Entries Processed transformer class");

		String genericJson = null;
		Object src = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object commObjJson = null;

			src = message.getPayload();

			try {
				LOGGER.debug("Source Mule Wex Dictionary Entries Processed ==> " + src);
				if (src instanceof String) {
					input = (String) src;
				} else if (src instanceof InputStream) {
					input = IOUtils.toString((InputStream) src, "UTF-8");
				}

				// create request, set header and footer
				LOGGER.debug("Creating the request");
				SCBCommObj req = new SCBCommObj();
				SCBHeader reqHeader = SCBOcrNlpUtil.createSCBUpdateWEXDictEntriesProcessedHeaderObject(ModuleCodes.WEX);
				SCBFooter reqFooter = new SCBFooter();
				req.setHeader(reqHeader);
				req.setFooter(reqFooter);

				// set the request body
				try {
					SCBOcrNlpWEXDictionaryEntries wexDictionaryEntries = mapper.readValue(input,
							SCBOcrNlpWEXDictionaryEntries.class);
					req.getBody().addSection(
							SCBCommObjTransformer.pojoToSection(wexDictionaryEntries, "SCBWEXDictionaryEntriesObject"));
				} catch (SCBTransformException e) {
					generateTechErrMsg(reqFooter, "400", "Invalid Request",
							"Invalid request, missing or invalid data.");
				}

				// create JSON string
				commObjJson = req;
				LOGGER.debug("Generic JSON ==> " + commObjJson.toString());
				genericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObjJson);
				LOGGER.debug("Initial data from WEX Utility JSON ==> " + genericJson);

			} catch (Exception e) {
				throw new TransformerException(
						CoreMessages.createStaticMessage("Error in SCBWexDictEntriesProcessedToNlpTransformer: " + src),
						e);
			}
		}
		
		return genericJson;
	}

	private static void generateTechErrMsg(SCBFooter requestFooter, String errorCode, String errorTitle,
			String errorMessage) {
		SCBValidationErrorResult scbValidationErrorCode = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMessage = new SCBValidationErrorResult(errorMessage, "errorMessage",
				null);
		requestFooter.addError(scbValidationErrorCode);
		requestFooter.addError(scbValidationErrorTitle);
		requestFooter.addError(scbValidationErrorMessage);
	}
}
