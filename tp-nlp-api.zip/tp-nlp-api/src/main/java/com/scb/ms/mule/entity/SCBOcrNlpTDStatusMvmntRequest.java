package com.scb.ms.mule.entity;

public class SCBOcrNlpTDStatusMvmntRequest {

	SCBOcrNlpTDStatusMvmntRequestObj tdStatusMvmtRequest;

	/**
	 * @return the tdStatusMvmtRequest
	 */
	public SCBOcrNlpTDStatusMvmntRequestObj getTdStatusMvmtRequest() {
		return tdStatusMvmtRequest;
	}

	/**
	 * @param tdStatusMvmtRequest
	 *            the tdStatusMvmtRequest to set
	 */
	public void setTdStatusMvmtRequest(SCBOcrNlpTDStatusMvmntRequestObj tdStatusMvmtRequest) {
		this.tdStatusMvmtRequest = tdStatusMvmtRequest;
	}

}
