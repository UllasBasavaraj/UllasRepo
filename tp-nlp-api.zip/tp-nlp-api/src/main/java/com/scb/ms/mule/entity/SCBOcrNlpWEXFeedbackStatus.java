package com.scb.ms.mule.entity;

public class SCBOcrNlpWEXFeedbackStatus {
	static final String EMPTY_STRING = "";

	private String code = EMPTY_STRING;
	private String statusTimestamp = EMPTY_STRING;
	private String status = EMPTY_STRING;
	private String id = EMPTY_STRING;

	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * @param code
	 *            the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * @return the statusTimestamp
	 */
	public String getStatusTimestamp() {
		return statusTimestamp;
	}

	/**
	 * @param statusTimestamp
	 *            the statusTimestamp to set
	 */
	public void setStatusTimestamp(String statusTimestamp) {
		this.statusTimestamp = statusTimestamp;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the emptyString
	 */
	public static String getEmptyString() {
		return EMPTY_STRING;
	}

}
