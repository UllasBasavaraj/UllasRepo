package com.scb.ms.mule.entity;


import org.springframework.data.annotation.Id;

public class SCBOcrNlpDealPageTextCoordinatesList {

	@Id
	private String id;
	private String dealId = "";
	private String country = "";
	private String stepId = "";
	private String clientId = "";
	private String systemCode = "";
	private String regTimeStamp = "";
	private String productId = "";
	private String documentId = "";
	private String documentPageId = "";
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDealId() {
		return dealId;
	}
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getStepId() {
		return stepId;
	}
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getSystemCode() {
		return systemCode;
	}
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
	public String getRegTimeStamp() {
		return regTimeStamp;
	}
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getDocumentPageId() {
		return documentPageId;
	}
	public void setDocumentPageId(String documentPageId) {
		this.documentPageId = documentPageId;
	}

}
