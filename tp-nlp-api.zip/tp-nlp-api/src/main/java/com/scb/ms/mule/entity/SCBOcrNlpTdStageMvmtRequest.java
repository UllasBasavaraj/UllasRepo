package com.scb.ms.mule.entity;

public class SCBOcrNlpTdStageMvmtRequest {

	private SCBOcrNlpTdStageMvmtRequestObj tdStageMvmtRequest;

	/**
	 * @return the tdStageMvmtRequest
	 */
	public SCBOcrNlpTdStageMvmtRequestObj getTdStageMvmtRequest() {
		return tdStageMvmtRequest;
	}

	/**
	 * @param tdStageMvmtRequest
	 *            the tdStageMvmtRequest to set
	 */
	public void setTdStageMvmtRequest(SCBOcrNlpTdStageMvmtRequestObj tdStageMvmtRequest) {
		this.tdStageMvmtRequest = tdStageMvmtRequest;
	}

}
