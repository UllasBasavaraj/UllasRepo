package com.scb.ms.mule.entity;

public class SCBOcrNlpNamesScreeningListRequest {

	private SCBOcrNlpNamesScreeningRequest sanctionPartiesRequest;

	/**
	 * @return the sanctionPartiesRequest
	 */
	public SCBOcrNlpNamesScreeningRequest getSanctionPartiesRequest() {
		return sanctionPartiesRequest;
	}

	/**
	 * @param sanctionPartiesRequest the sanctionPartiesRequest to set
	 */
	public void setSanctionPartiesRequest(SCBOcrNlpNamesScreeningRequest sanctionPartiesRequest) {
		this.sanctionPartiesRequest = sanctionPartiesRequest;
	}

}
