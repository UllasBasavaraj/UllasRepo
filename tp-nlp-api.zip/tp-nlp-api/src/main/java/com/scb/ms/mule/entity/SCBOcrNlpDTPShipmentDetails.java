package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpDTPShipmentDetails {

	private String transportType = "";
	private String transportDocumentType = "";
	private String transportDocumentNo = "";
	private String transportDate = "";
	private List<SCBOcrNlpDTPRoutingDetails> routingDetails = new ArrayList<SCBOcrNlpDTPRoutingDetails>();

	/**
	 * @return the transportType
	 */
	public String getTransportType() {
		return transportType;
	}

	/**
	 * @param transportType
	 *            the transportType to set
	 */
	public void setTransportType(String transportType) {
		this.transportType = transportType;
	}

	/**
	 * @return the transportDocumentType
	 */
	public String getTransportDocumentType() {
		return transportDocumentType;
	}

	/**
	 * @param transportDocumentType
	 *            the transportDocumentType to set
	 */
	public void setTransportDocumentType(String transportDocumentType) {
		this.transportDocumentType = transportDocumentType;
	}

	/**
	 * @return the transportDocumentNo
	 */
	public String getTransportDocumentNo() {
		return transportDocumentNo;
	}

	/**
	 * @param transportDocumentNo
	 *            the transportDocumentNo to set
	 */
	public void setTransportDocumentNo(String transportDocumentNo) {
		this.transportDocumentNo = transportDocumentNo;
	}

	/**
	 * @return the transportDate
	 */
	public String getTransportDate() {
		return transportDate;
	}

	/**
	 * @param transportDate
	 *            the transportDate to set
	 */
	public void setTransportDate(String transportDate) {
		this.transportDate = transportDate;
	}

	/**
	 * @return the routingDetails
	 */
	public List<SCBOcrNlpDTPRoutingDetails> getRoutingDetails() {
		return routingDetails;
	}

	/**
	 * @param routingDetails
	 *            the routingDetails to set
	 */
	public void setRoutingDetails(List<SCBOcrNlpDTPRoutingDetails> routingDetails) {
		this.routingDetails = routingDetails;
	}

}
