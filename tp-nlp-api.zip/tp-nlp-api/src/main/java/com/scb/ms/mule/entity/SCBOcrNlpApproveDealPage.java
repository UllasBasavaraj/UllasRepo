package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

public class SCBOcrNlpApproveDealPage {
	
	@Id
	private String id;
	private String tdApplicationReferenceId = "";
	private String dealId = "";
	@Transient
	private String userId;
	private List<SCBOcrNlpApprovePageDocumenstList> documentsList = new ArrayList<SCBOcrNlpApprovePageDocumenstList>();
	
	public String getTdApplicationReferenceId() {
		return tdApplicationReferenceId;
	}
	public void setTdApplicationReferenceId(String tdApplicationReferenceId) {
		this.tdApplicationReferenceId = tdApplicationReferenceId;
	}
	public String getDealId() {
		return dealId;
	}
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<SCBOcrNlpApprovePageDocumenstList> getDocumentsList() {
		return documentsList;
	}
	public void setDocumentsList(List<SCBOcrNlpApprovePageDocumenstList> documentsList) {
		this.documentsList = documentsList;
	}

}
