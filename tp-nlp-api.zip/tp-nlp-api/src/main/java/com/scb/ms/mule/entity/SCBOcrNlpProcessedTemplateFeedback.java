package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpProcessedTemplateFeedback {
	private String dealId;
	private String feedbackScanStartTime;
	private String feedbackScanEndTime;
	private String createTemplateStartTime;
	private String createTemplateEndTime;
	private String feedbackExportStartTime;
	private String feedbackExportEndTime;
	private List<SCBOcrNlpProcessedTemplateFeedbackPage> templateFeedbackProcessedDataList = new ArrayList<>();

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the feedbackScanStartTime
	 */
	public String getFeedbackScanStartTime() {
		return feedbackScanStartTime;
	}

	/**
	 * @param feedbackScanStartTime
	 *            the feedbackScanStartTime to set
	 */
	public void setFeedbackScanStartTime(String feedbackScanStartTime) {
		this.feedbackScanStartTime = feedbackScanStartTime;
	}

	/**
	 * @return the feedbackScanEndTime
	 */
	public String getFeedbackScanEndTime() {
		return feedbackScanEndTime;
	}

	/**
	 * @param feedbackScanEndTime
	 *            the feedbackScanEndTime to set
	 */
	public void setFeedbackScanEndTime(String feedbackScanEndTime) {
		this.feedbackScanEndTime = feedbackScanEndTime;
	}

	/**
	 * @return the createTemplateStartTime
	 */
	public String getCreateTemplateStartTime() {
		return createTemplateStartTime;
	}

	/**
	 * @param createTemplateStartTime
	 *            the createTemplateStartTime to set
	 */
	public void setCreateTemplateStartTime(String createTemplateStartTime) {
		this.createTemplateStartTime = createTemplateStartTime;
	}

	/**
	 * @return the createTemplateEndTime
	 */
	public String getCreateTemplateEndTime() {
		return createTemplateEndTime;
	}

	/**
	 * @param createTemplateEndTime
	 *            the createTemplateEndTime to set
	 */
	public void setCreateTemplateEndTime(String createTemplateEndTime) {
		this.createTemplateEndTime = createTemplateEndTime;
	}

	/**
	 * @return the feedbackExportStartTime
	 */
	public String getFeedbackExportStartTime() {
		return feedbackExportStartTime;
	}

	/**
	 * @param feedbackExportStartTime
	 *            the feedbackExportStartTime to set
	 */
	public void setFeedbackExportStartTime(String feedbackExportStartTime) {
		this.feedbackExportStartTime = feedbackExportStartTime;
	}

	/**
	 * @return the feedbackExportEndTime
	 */
	public String getFeedbackExportEndTime() {
		return feedbackExportEndTime;
	}

	/**
	 * @param feedbackExportEndTime
	 *            the feedbackExportEndTime to set
	 */
	public void setFeedbackExportEndTime(String feedbackExportEndTime) {
		this.feedbackExportEndTime = feedbackExportEndTime;
	}

	/**
	 * @return the templateFeedbackProcessedDataList
	 */
	public List<SCBOcrNlpProcessedTemplateFeedbackPage> getTemplateFeedbackProcessedDataList() {
		return templateFeedbackProcessedDataList;
	}

	/**
	 * @param templateFeedbackProcessedDataList
	 *            the templateFeedbackProcessedDataList to set
	 */
	public void setTemplateFeedbackProcessedDataList(
			List<SCBOcrNlpProcessedTemplateFeedbackPage> templateFeedbackProcessedDataList) {
		this.templateFeedbackProcessedDataList = templateFeedbackProcessedDataList;
	}

}
