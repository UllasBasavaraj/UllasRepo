package com.scb.ms.mule.transformer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.core.validation.SCBValidationErrorResult;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBFooter;
import com.scb.ms.communication.SCBHeader;
import com.scb.ms.mule.entity.SCBOcrNlpProcessedTemplateFeedback;
import com.scb.ms.mule.util.SCBOcrNlpUtil;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.ModuleCodes;

import org.mule.api.MuleMessage;
import org.apache.commons.io.IOUtils;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;

public class SCBOcrNlpProcessedTemplateFeedbackTransformer extends AbstractMessageTransformer {

	private static final Logger LOGGER = LoggerFactory.getLogger(SCBOcrNlpProcessedTemplateFeedbackTransformer.class);
	private String transformerType;

	@Override
	public Object transformMessage(MuleMessage message, String arg1) throws TransformerException {
		LOGGER.info("Running SCBProcessedTemplateFeedbackTransformer");
		String ppCommObjJson = null;
		Object source = null;

		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			Object commObjJson = null;

			try {
				source = message.getPayload();
				LOGGER.debug("Source ==> " + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				}

				// create request, set header and footer
				LOGGER.debug("Creating the request");
				SCBCommObj req = new SCBCommObj();
				SCBHeader reqHeader = SCBOcrNlpUtil.createSCBProcesedTemplateFeedbackHeaderObject(ModuleCodes.SUBMIT);
				SCBFooter reqFooter = new SCBFooter();
				req.setHeader(reqHeader);
				req.setFooter(reqFooter);

				// set the request body
				try {
					SCBOcrNlpProcessedTemplateFeedback processedTemplateFeedback = mapper.readValue(input,
							SCBOcrNlpProcessedTemplateFeedback.class);
					req.getBody().addSection(SCBCommObjTransformer.pojoToSection(processedTemplateFeedback,
							SCBOcrNlpProcessedTemplateFeedback.class));
				} catch (Exception e) {
					generateTechErrMsg(reqFooter, "400", "Invalid Request",
							"Invalid request, missing or invalid data.");
				}

				// create JSON string
				commObjJson = req;
				LOGGER.debug("Generic JSON ==> " + commObjJson.toString());
				ppCommObjJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(commObjJson);
				LOGGER.debug("Initial data from Datacap JSON ==> " + ppCommObjJson);

			} catch (Exception e) {
				throw new TransformerException(
						CoreMessages.createStaticMessage("Error in SCBProcessedTemplateFeedbackTransformer: " + source),
						e);
			}
		}

		return ppCommObjJson;
	}

	private static void generateTechErrMsg(SCBFooter requestFooter, String errorCode, String errorTitle,
			String errorMessage) {
		SCBValidationErrorResult scbValidationErrorCode = new SCBValidationErrorResult(errorCode, "errorCode", null);
		SCBValidationErrorResult scbValidationErrorTitle = new SCBValidationErrorResult(errorTitle, "errorTitle", null);
		SCBValidationErrorResult scbValidationErrorMessage = new SCBValidationErrorResult(errorMessage, "errorMessage",
				null);
		requestFooter.addError(scbValidationErrorCode);
		requestFooter.addError(scbValidationErrorTitle);
		requestFooter.addError(scbValidationErrorMessage);
	}

	public String getTransformerType() {
		return transformerType;
	}

	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}
}
