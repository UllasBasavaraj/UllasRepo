package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

public class SCBOcrNlpNameCaptureList {

	@Id
	private String id;
	private String roleCode = "";
	private String role = "";
	private String systemRole = "";
	private String countryCode = "";
	private String country = "";
	private boolean approved;
	private String partyId = "";
	private String extensionId = "";
	private String isExcelDownload = "N";
	private List<SCBOcrNlpHighlightList> highlightsList = new ArrayList<SCBOcrNlpHighlightList>();
	private String roleStatus = "U";
	private boolean main;
	@Transient
	private String docInvoiceNumber = "";
	@Transient
	private int charStart;
	@Transient
	private int charEnd;
	@Transient
	private String documentPageId;

	private boolean manualAdd;
	private boolean feedback;
	private boolean orphanRoleCode = false;

	private String rubberBandType = "";
	private boolean createdFromTemplate;
	@Transient
	private Integer sortOrderX1;
	@Transient
	private Integer sortOrderY1;
	private boolean suppressedAddress;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the roleCode
	 */
	public String getRoleCode() {
		return roleCode;
	}

	/**
	 * @param roleCode
	 *            the roleCode to set
	 */
	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role
	 *            the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the systemRole
	 */
	public String getSystemRole() {
		return systemRole;
	}

	/**
	 * @param systemRole
	 *            the systemRole to set
	 */
	public void setSystemRole(String systemRole) {
		this.systemRole = systemRole;
	}

	/**
	 * @return the countryCode
	 */
	public String getCountryCode() {
		return countryCode;
	}

	/**
	 * @param countryCode
	 *            the countryCode to set
	 */
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the approved
	 */
	public boolean getApproved() {
		return approved;
	}

	/**
	 * @param approved
	 *            the approved to set
	 */
	public void setApproved(boolean approved) {
		this.approved = approved;
	}

	/**
	 * @return the partyId
	 */
	public String getPartyId() {
		return partyId;
	}

	/**
	 * @param partyId
	 *            the partyId to set
	 */
	public void setPartyId(String partyId) {
		this.partyId = partyId;
	}

	/**
	 * @return the extensionId
	 */
	public String getExtensionId() {
		return extensionId;
	}

	/**
	 * @param extensionId
	 *            the extensionId to set
	 */
	public void setExtensionId(String extensionId) {
		this.extensionId = extensionId;
	}

	/**
	 * @return the isExcelDownload
	 */
	public String getIsExcelDownload() {
		return isExcelDownload;
	}

	/**
	 * @param isExcelDownload
	 *            the isExcelDownload to set
	 */
	public void setIsExcelDownload(String isExcelDownload) {
		this.isExcelDownload = isExcelDownload;
	}

	/**
	 * @return the highlightsList
	 */
	public List<SCBOcrNlpHighlightList> getHighlightsList() {
		return highlightsList;
	}

	/**
	 * @param highlightsList
	 *            the highlightsList to set
	 */
	public void setHighlightsList(List<SCBOcrNlpHighlightList> highlightsList) {
		this.highlightsList = highlightsList;
	}

	/**
	 * @return the roleStatus
	 */
	public String getRoleStatus() {
		return roleStatus;
	}

	/**
	 * @param roleStatus
	 *            the roleStatus to set
	 */
	public void setRoleStatus(String roleStatus) {
		this.roleStatus = roleStatus;
	}

	/**
	 * @return the main
	 */
	public boolean getMain() {
		return main;
	}

	/**
	 * @param main
	 *            the main to set
	 */
	public void setMain(boolean main) {
		this.main = main;
	}

	/**
	 * @return the docInvoiceNumber
	 */
	public String getDocInvoiceNumber() {
		return docInvoiceNumber;
	}

	/**
	 * @param docInvoiceNumber
	 *            the docInvoiceNumber to set
	 */
	public void setDocInvoiceNumber(String docInvoiceNumber) {
		this.docInvoiceNumber = docInvoiceNumber;
	}

	/**
	 * @return the charStart
	 */
	public int getCharStart() {
		return charStart;
	}

	/**
	 * @param charStart
	 *            the charStart to set
	 */
	public void setCharStart(int charStart) {
		this.charStart = charStart;
	}

	/**
	 * @return the charEnd
	 */
	public int getCharEnd() {
		return charEnd;
	}

	/**
	 * @param charEnd
	 *            the charEnd to set
	 */
	public void setCharEnd(int charEnd) {
		this.charEnd = charEnd;
	}

	/**
	 * @return the documentPageId
	 */
	public String getDocumentPageId() {
		return documentPageId;
	}

	/**
	 * @param documentPageId
	 *            the documentPageId to set
	 */
	public void setDocumentPageId(String documentPageId) {
		this.documentPageId = documentPageId;
	}

	/**
	 * @return the manualAdd
	 */
	public boolean getManualAdd() {
		return manualAdd;
	}

	/**
	 * @param manualAdd
	 *            the manualAdd to set
	 */
	public void setManualAdd(boolean manualAdd) {
		this.manualAdd = manualAdd;
	}

	/**
	 * @return the feedback
	 */
	public boolean getFeedback() {
		return feedback;
	}

	/**
	 * @param feedback
	 *            the feedback to set
	 */
	public void setFeedback(boolean feedback) {
		this.feedback = feedback;
	}

	/**
	 * @return the orphanRoleCode
	 */
	public boolean getOrphanRoleCode() {
		return orphanRoleCode;
	}

	/**
	 * @param orphanRoleCode
	 *            the orphanRoleCode to set
	 */
	public void setOrphanRoleCode(boolean orphanRoleCode) {
		this.orphanRoleCode = orphanRoleCode;
	}

	/**
	 * @return the rubberBandType
	 */
	public String getRubberBandType() {
		return rubberBandType;
	}

	/**
	 * @param rubberBandType
	 *            the rubberBandType to set
	 */
	public void setRubberBandType(String rubberBandType) {
		this.rubberBandType = rubberBandType;
	}

	public boolean getCreatedFromTemplate() {
		return createdFromTemplate;
	}

	/**
	 * @return the sortOrderX1
	 */
	public Integer getSortOrderX1() {
		return sortOrderX1;
	}

	/**
	 * @param sortOrderX1 the sortOrderX1 to set
	 */
	public void setSortOrderX1(Integer sortOrderX1) {
		this.sortOrderX1 = sortOrderX1;
	}

	/**
	 * @return the sortOrderY1
	 */
	public Integer getSortOrderY1() {
		return sortOrderY1;
	}

	/**
	 * @param sortOrderY1 the sortOrderY1 to set
	 */
	public void setSortOrderY1(Integer sortOrderY1) {
		this.sortOrderY1 = sortOrderY1;
	}

	/**
	 * @param createdFromTemplate the createdFromTemplate to set
	 */
	public void setCreatedFromTemplate(boolean createdFromTemplate) {
		this.createdFromTemplate = createdFromTemplate;
	}

	/**
	 * @return the suppressedAddress
	 */
	public boolean getSuppressedAddress() {
		return suppressedAddress;
	}

	/**
	 * @param suppressedAddress
	 *            the suppressedAddress to set
	 */
	public void setSuppressedAddress(boolean suppressedAddress) {
		this.suppressedAddress = suppressedAddress;
	}

}