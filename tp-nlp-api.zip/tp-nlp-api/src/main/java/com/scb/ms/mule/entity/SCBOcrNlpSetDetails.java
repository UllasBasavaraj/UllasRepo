package com.scb.ms.mule.entity;

import org.springframework.data.annotation.Id;

public class SCBOcrNlpSetDetails {

	@Id
	private String id;
	private String setNo = "";
	private String dealInvoicePageNo = "";
	private String dealInvoiceNo = "";
	private String documentId = "";
	private String status = "";

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the setNo
	 */
	public String getSetNo() {
		return setNo;
	}

	/**
	 * @param setNo
	 *            the setNo to set
	 */
	public void setSetNo(String setNo) {
		this.setNo = setNo;
	}

	/**
	 * @return the dealInvoicePageNo
	 */
	public String getDealInvoicePageNo() {
		return dealInvoicePageNo;
	}

	/**
	 * @param dealInvoicePageNo
	 *            the dealInvoicePageNo to set
	 */
	public void setDealInvoicePageNo(String dealInvoicePageNo) {
		this.dealInvoicePageNo = dealInvoicePageNo;
	}

	/**
	 * @return the dealInvoiceNo
	 */
	public String getDealInvoiceNo() {
		return dealInvoiceNo;
	}

	/**
	 * @param dealInvoiceNo
	 *            the dealInvoiceNo to set
	 */
	public void setDealInvoiceNo(String dealInvoiceNo) {
		this.dealInvoiceNo = dealInvoiceNo;
	}

	/**
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId
	 *            the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
