package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpRoleTemplateCoordinatesList {

	private int templateId;
	private List<SCBOcrNlpTemplateCoordinatesList> templateCoordinatesList = new ArrayList<SCBOcrNlpTemplateCoordinatesList>();

	/**
	 * @return the templateId
	 */
	public int getTemplateId() {
		return templateId;
	}

	/**
	 * @param templateId
	 *            the templateId to set
	 */
	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	/**
	 * @return the templateCoordinatesList
	 */
	public List<SCBOcrNlpTemplateCoordinatesList> getTemplateCoordinatesList() {
		return templateCoordinatesList;
	}

	/**
	 * @param templateCoordinatesList
	 *            the templateCoordinatesList to set
	 */
	public void setTemplateCoordinatesList(List<SCBOcrNlpTemplateCoordinatesList> templateCoordinatesList) {
		this.templateCoordinatesList = templateCoordinatesList;
	}

}
