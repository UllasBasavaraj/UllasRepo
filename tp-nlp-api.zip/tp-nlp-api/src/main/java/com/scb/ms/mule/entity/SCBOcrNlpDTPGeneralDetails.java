package com.scb.ms.mule.entity;

public class SCBOcrNlpDTPGeneralDetails {

	private String transactionType = "";
	private String currency = "";
	private String amount = "";
	private String invoiceNo = "";
	private String invoiceDate = "";
	private String goodsDescription = "";
	private String collectionType = "";
	private String tenor = "";
	private String daysAfter = "";
	private String startingDate = "";
	private String dueDate = "";
	private String remitBankReferenceNo = "";
	private String sight = "";
	private String attachmentCount = "";

	/**
	 * @return the transactionType
	 */
	public String getTransactionType() {
		return transactionType;
	}

	/**
	 * @param transactionType
	 *            the transactionType to set
	 */
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency
	 *            the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the amount
	 */
	public String getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(String amount) {
		this.amount = amount;
	}

	/**
	 * @return the invoiceNo
	 */
	public String getInvoiceNo() {
		return invoiceNo;
	}

	/**
	 * @param invoiceNo
	 *            the invoiceNo to set
	 */
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	/**
	 * @return the invoiceDate
	 */
	public String getInvoiceDate() {
		return invoiceDate;
	}

	/**
	 * @param invoiceDate
	 *            the invoiceDate to set
	 */
	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	/**
	 * @return the goodsDescription
	 */
	public String getGoodsDescription() {
		return goodsDescription;
	}

	/**
	 * @param goodsDescription
	 *            the goodsDescription to set
	 */
	public void setGoodsDescription(String goodsDescription) {
		this.goodsDescription = goodsDescription;
	}

	/**
	 * @return the collectionType
	 */
	public String getCollectionType() {
		return collectionType;
	}

	/**
	 * @param collectionType
	 *            the collectionType to set
	 */
	public void setCollectionType(String collectionType) {
		this.collectionType = collectionType;
	}

	/**
	 * @return the tenor
	 */
	public String getTenor() {
		return tenor;
	}

	/**
	 * @param tenor
	 *            the tenor to set
	 */
	public void setTenor(String tenor) {
		this.tenor = tenor;
	}

	/**
	 * @return the daysAfter
	 */
	public String getDaysAfter() {
		return daysAfter;
	}

	/**
	 * @param daysAfter
	 *            the daysAfter to set
	 */
	public void setDaysAfter(String daysAfter) {
		this.daysAfter = daysAfter;
	}

	/**
	 * @return the startingDate
	 */
	public String getStartingDate() {
		return startingDate;
	}

	/**
	 * @param startingDate
	 *            the startingDate to set
	 */
	public void setStartingDate(String startingDate) {
		this.startingDate = startingDate;
	}

	/**
	 * @return the dueDate
	 */
	public String getDueDate() {
		return dueDate;
	}

	/**
	 * @param dueDate
	 *            the dueDate to set
	 */
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	/**
	 * @return the remitBankReferenceNo
	 */
	public String getRemitBankReferenceNo() {
		return remitBankReferenceNo;
	}

	/**
	 * @param remitBankReferenceNo the remitBankReferenceNo to set
	 */
	public void setRemitBankReferenceNo(String remitBankReferenceNo) {
		this.remitBankReferenceNo = remitBankReferenceNo;
	}

	/**
	 * @return the sight
	 */
	public String getSight() {
		return sight;
	}

	/**
	 * @param sight
	 *            the sight to set
	 */
	public void setSight(String sight) {
		this.sight = sight;
	}

	/**
	 * @return the attachmentCount
	 */
	public String getAttachmentCount() {
		return attachmentCount;
	}

	/**
	 * @param attachmentCount
	 *            the attachmentCount to set
	 */
	public void setAttachmentCount(String attachmentCount) {
		this.attachmentCount = attachmentCount;
	}

}
