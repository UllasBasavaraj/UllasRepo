package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;

public class SCBOcrNlpDealDataObjectExtn {

	@Id
	private String id;
	private String dealId = "";
	private String productId = "";
	private String stepId = "";
	private String clientId = "";
	private String country = "";
	private String documentId = "";
	private String documentPageId = "";
	private String lastModifiedBy = "";
	private String lastModifiedEmail = "";
	private String lastModifiedDate = "";
	private String layoutXmlExtractedText = "";
	private String templateExtractedText;
	private String systemCode = "";
	private String regTimeStamp = "";
	private String tdApplicationReferenceId = "";
	private String regTimeMsStr = "";
	private String sysDate = "";
	private String dealSystemId = "";
	List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList = new ArrayList<SCBOcrNlpMatchingTemplateId>();
	private String width = "";
	private String height = "";
	private List<SCBOcrNlpNameCaptureList> nameCaptureList = new ArrayList<SCBOcrNlpNameCaptureList>();
	private List<SCBOcrNlpTextCoordinatesList> textCoordinatesList = new ArrayList<SCBOcrNlpTextCoordinatesList>();
	private List<SCBOcrNlpTemplatesCoordinatesList> templateCoordinatesList = new ArrayList<SCBOcrNlpTemplatesCoordinatesList>();
	private String textCoordinatesCompress = "";
	private String pageSet = "";
	private String dealReleasedStatus = "";
	private String dealReleasedDate = "";
	private String subProductCode = "";
	@Transient
	private String finalSystemCode = "";

	@Transient
	private String response = "";
	
	@Transient
	private String responseMessage = "";

	@Transient
	private String statusFlag = "";

	@Transient
	private String tdTxnStageCode = "";

	@Transient
	private String tdRequestTye = "";

	@Transient
	private String requestStatus = "";

	@Transient
	private String enableIcon = "";

	@Transient
	private String releaseTxnLock = "";

	@Transient
	private String dealStatus = "";

	@Transient
	private String digitizerStatus = "";

	// @Transient
	private String docClsType;

	@Transient
	private String duplicatePage;

	@Transient
	private List<SCBOcrNlpOTPDocumentDetails> documentDetails = new ArrayList<SCBOcrNlpOTPDocumentDetails>();
	
	private List<Integer> printAreaCoords = new ArrayList<Integer>();

	@Transient
	private SCBOcrNlpDataEntryFieldsDetails dataEntryFieldsDetails = new SCBOcrNlpDataEntryFieldsDetails();

	private String deReRun = "";

	@Transient
	private String userId;

	@Transient
	private String dataEntryApplicable = "N";

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the documentId
	 */
	public String getDocumentId() {
		return documentId;
	}

	/**
	 * @param documentId
	 *            the documentId to set
	 */
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	/**
	 * @return the documentPageId
	 */
	public String getDocumentPageId() {
		return documentPageId;
	}

	/**
	 * @param documentPageId
	 *            the documentPageId to set
	 */
	public void setDocumentPageId(String documentPageId) {
		this.documentPageId = documentPageId;
	}

	/**
	 * @return the lastModifiedBy
	 */
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	/**
	 * @param lastModifiedBy
	 *            the lastModifiedBy to set
	 */
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	/**
	 * @return the lastModifiedEmail
	 */
	public String getLastModifiedEmail() {
		return lastModifiedEmail;
	}

	/**
	 * @param lastModifiedEmail
	 *            the lastModifiedEmail to set
	 */
	public void setLastModifiedEmail(String lastModifiedEmail) {
		this.lastModifiedEmail = lastModifiedEmail;
	}

	/**
	 * @return the lastModifiedDate
	 */
	public String getLastModifiedDate() {
		return lastModifiedDate;
	}

	/**
	 * @param lastModifiedDate
	 *            the lastModifiedDate to set
	 */
	public void setLastModifiedDate(String lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	/**
	 * @return the layoutXmlExtractedText
	 */
	public String getLayoutXmlExtractedText() {
		return layoutXmlExtractedText;
	}

	/**
	 * @param layoutXmlExtractedText
	 *            the layoutXmlExtractedText to set
	 */
	public void setLayoutXmlExtractedText(String layoutXmlExtractedText) {
		this.layoutXmlExtractedText = layoutXmlExtractedText;
	}

	/**
	 * @return the templateExtractedText
	 */
	public String getTemplateExtractedText() {
		return templateExtractedText;
	}

	/**
	 * @param templateExtractedText
	 *            the templateExtractedText to set
	 */
	public void setTemplateExtractedText(String templateExtractedText) {
		this.templateExtractedText = templateExtractedText;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the regTimeStamp
	 */
	public String getRegTimeStamp() {
		return regTimeStamp;
	}

	/**
	 * @param regTimeStamp
	 *            the regTimeStamp to set
	 */
	public void setRegTimeStamp(String regTimeStamp) {
		this.regTimeStamp = regTimeStamp;
	}

	/**
	 * @return the tdApplicationReferenceId
	 */
	public String getTdApplicationReferenceId() {
		return tdApplicationReferenceId;
	}

	/**
	 * @param tdApplicationReferenceId
	 *            the tdApplicationReferenceId to set
	 */
	public void setTdApplicationReferenceId(String tdApplicationReferenceId) {
		this.tdApplicationReferenceId = tdApplicationReferenceId;
	}

	/**
	 * @return the regTimeMsStr
	 */
	public String getRegTimeMsStr() {
		return regTimeMsStr;
	}

	/**
	 * @param regTimeMsStr
	 *            the regTimeMsStr to set
	 */
	public void setRegTimeMsStr(String regTimeMsStr) {
		this.regTimeMsStr = regTimeMsStr;
	}

	/**
	 * @return the sysDate
	 */
	public String getSysDate() {
		return sysDate;
	}

	/**
	 * @param sysDate
	 *            the sysDate to set
	 */
	public void setSysDate(String sysDate) {
		this.sysDate = sysDate;
	}

	/**
	 * @return the dealSystemId
	 */
	public String getDealSystemId() {
		return dealSystemId;
	}

	/**
	 * @param dealSystemId
	 *            the dealSystemId to set
	 */
	public void setDealSystemId(String dealSystemId) {
		this.dealSystemId = dealSystemId;
	}

	/**
	 * @return the matchingTemplateIdsList
	 */
	public List<SCBOcrNlpMatchingTemplateId> getMatchingTemplateIdsList() {
		return matchingTemplateIdsList;
	}

	/**
	 * @param matchingTemplateIdsList
	 *            the matchingTemplateIdsList to set
	 */
	public void setMatchingTemplateIdsList(List<SCBOcrNlpMatchingTemplateId> matchingTemplateIdsList) {
		this.matchingTemplateIdsList = matchingTemplateIdsList;
	}

	/**
	 * @return the width
	 */
	public String getWidth() {
		return width;
	}

	/**
	 * @param width
	 *            the width to set
	 */
	public void setWidth(String width) {
		this.width = width;
	}

	/**
	 * @return the height
	 */
	public String getHeight() {
		return height;
	}

	/**
	 * @param height
	 *            the height to set
	 */
	public void setHeight(String height) {
		this.height = height;
	}

	/**
	 * @return the nameCaptureList
	 */
	public List<SCBOcrNlpNameCaptureList> getNameCaptureList() {
		return nameCaptureList;
	}

	/**
	 * @param nameCaptureList
	 *            the nameCaptureList to set
	 */
	public void setNameCaptureList(List<SCBOcrNlpNameCaptureList> nameCaptureList) {
		this.nameCaptureList = nameCaptureList;
	}

	/**
	 * @return the textCoordinatesList
	 */
	public List<SCBOcrNlpTextCoordinatesList> getTextCoordinatesList() {
		return textCoordinatesList;
	}

	/**
	 * @param textCoordinatesList
	 *            the textCoordinatesList to set
	 */
	public void setTextCoordinatesList(List<SCBOcrNlpTextCoordinatesList> textCoordinatesList) {
		this.textCoordinatesList = textCoordinatesList;
	}


	/**
	 * @return the textCoordinatesCompress
	 */
	public String getTextCoordinatesCompress() {
		return textCoordinatesCompress;
	}

	/**
	 * @param textCoordinatesCompress
	 *            the textCoordinatesCompress to set
	 */
	public void setTextCoordinatesCompress(String textCoordinatesCompress) {
		this.textCoordinatesCompress = textCoordinatesCompress;
	}

	/**
	 * @return the pageSet
	 */
	public String getPageSet() {
		return pageSet;
	}

	/**
	 * @param pageSet
	 *            the pageSet to set
	 */
	public void setPageSet(String pageSet) {
		this.pageSet = pageSet;
	}

	/**
	 * @return the dealReleasedStatus
	 */
	public String getDealReleasedStatus() {
		return dealReleasedStatus;
	}

	/**
	 * @param dealReleasedStatus
	 *            the dealReleasedStatus to set
	 */
	public void setDealReleasedStatus(String dealReleasedStatus) {
		this.dealReleasedStatus = dealReleasedStatus;
	}

	/**
	 * @return the subProductCode
	 */
	public String getSubProductCode() {
		return subProductCode;
	}

	/**
	 * @param subProductCode
	 *            the subProductCode to set
	 */
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

	/**
	 * @return the finalSystemCode
	 */
	public String getFinalSystemCode() {
		return finalSystemCode;
	}

	/**
	 * @param finalSystemCode
	 *            the finalSystemCode to set
	 */
	public void setFinalSystemCode(String finalSystemCode) {
		this.finalSystemCode = finalSystemCode;
	}

	/**
	 * @return the response
	 */
	public String getResponse() {
		return response;
	}

	/**
	 * @param response
	 *            the response to set
	 */
	public void setResponse(String response) {
		this.response = response;
	}

	/**
	 * @return the statusFlag
	 */
	public String getStatusFlag() {
		return statusFlag;
	}

	/**
	 * @param statusFlag
	 *            the statusFlag to set
	 */
	public void setStatusFlag(String statusFlag) {
		this.statusFlag = statusFlag;
	}

	/**
	 * @return the tdTxnStageCode
	 */
	public String getTdTxnStageCode() {
		return tdTxnStageCode;
	}

	/**
	 * @param tdTxnStageCode
	 *            the tdTxnStageCode to set
	 */
	public void setTdTxnStageCode(String tdTxnStageCode) {
		this.tdTxnStageCode = tdTxnStageCode;
	}

	/**
	 * @return the tdRequestTye
	 */
	public String getTdRequestTye() {
		return tdRequestTye;
	}

	/**
	 * @param tdRequestTye
	 *            the tdRequestTye to set
	 */
	public void setTdRequestTye(String tdRequestTye) {
		this.tdRequestTye = tdRequestTye;
	}

	/**
	 * @return the requestStatus
	 */
	public String getRequestStatus() {
		return requestStatus;
	}

	/**
	 * @param requestStatus
	 *            the requestStatus to set
	 */
	public void setRequestStatus(String requestStatus) {
		this.requestStatus = requestStatus;
	}

	/**
	 * @return the enableIcon
	 */
	public String getEnableIcon() {
		return enableIcon;
	}

	/**
	 * @param enableIcon
	 *            the enableIcon to set
	 */
	public void setEnableIcon(String enableIcon) {
		this.enableIcon = enableIcon;
	}

	/**
	 * @return the releaseTxnLock
	 */
	public String getReleaseTxnLock() {
		return releaseTxnLock;
	}

	/**
	 * @param releaseTxnLock
	 *            the releaseTxnLock to set
	 */
	public void setReleaseTxnLock(String releaseTxnLock) {
		this.releaseTxnLock = releaseTxnLock;
	}

	/**
	 * @return the dealStatus
	 */
	public String getDealStatus() {
		return dealStatus;
	}

	/**
	 * @param dealStatus
	 *            the dealStatus to set
	 */
	public void setDealStatus(String dealStatus) {
		this.dealStatus = dealStatus;
	}

	/**
	 * @return the digitizerStatus
	 */
	public String getDigitizerStatus() {
		return digitizerStatus;
	}

	/**
	 * @param digitizerStatus
	 *            the digitizerStatus to set
	 */
	public void setDigitizerStatus(String digitizerStatus) {
		this.digitizerStatus = digitizerStatus;
	}

	/**
	 * @return the docClsType
	 */
	public String getDocClsType() {
		return docClsType;
	}

	/**
	 * @param docClsType
	 *            the docClsType to set
	 */
	public void setDocClsType(String docClsType) {
		this.docClsType = docClsType;
	}

	/**
	 * @return the duplicatePage
	 */
	public String getDuplicatePage() {
		return duplicatePage;
	}

	/**
	 * @param duplicatePage
	 *            the duplicatePage to set
	 */
	public void setDuplicatePage(String duplicatePage) {
		this.duplicatePage = duplicatePage;
	}

	/**
	 * @return the documentDetails
	 */
	public List<SCBOcrNlpOTPDocumentDetails> getDocumentDetails() {
		return documentDetails;
	}

	/**
	 * @param documentDetails
	 *            the documentDetails to set
	 */
	public void setDocumentDetails(List<SCBOcrNlpOTPDocumentDetails> documentDetails) {
		this.documentDetails = documentDetails;
	}

	/**
	 * @return the dataEntryFieldsDetails
	 */
	public SCBOcrNlpDataEntryFieldsDetails getDataEntryFieldsDetails() {
		return dataEntryFieldsDetails;
	}

	/**
	 * @param dataEntryFieldsDetails
	 *            the dataEntryFieldsDetails to set
	 */
	public void setDataEntryFieldsDetails(SCBOcrNlpDataEntryFieldsDetails dataEntryFieldsDetails) {
		this.dataEntryFieldsDetails = dataEntryFieldsDetails;
	}


	/**
	 * @return the deReRun
	 */
	public String getDeReRun() {
		return deReRun;
	}

	/**
	 * @param deReRun
	 *            the deReRun to set
	 */
	public void setDeReRun(String deReRun) {
		this.deReRun = deReRun;
	}

	/**
	 * @return the dealReleasedDate
	 */
	public String getDealReleasedDate() {
		return dealReleasedDate;
	}

	/**
	 * @param dealReleasedDate the dealReleasedDate to set
	 */
	public void setDealReleasedDate(String dealReleasedDate) {
		this.dealReleasedDate = dealReleasedDate;
	}

	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}

	/**
	 * @param userId
	 *            the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * @return the dataEntryApplicable
	 */
	public String getDataEntryApplicable() {
		return dataEntryApplicable;
	}

	/**
	 * @param dataEntryApplicable
	 *            the dataEntryApplicable to set
	 */
	public void setDataEntryApplicable(String dataEntryApplicable) {
		this.dataEntryApplicable = dataEntryApplicable;
	}

	/**
	 * @return the templateCoordinatesList
	 */
	public List<SCBOcrNlpTemplatesCoordinatesList> getTemplateCoordinatesList() {
		return templateCoordinatesList;
	}

	/**
	 * @param templateCoordinatesList the templateCoordinatesList to set
	 */
	public void setTemplateCoordinatesList(List<SCBOcrNlpTemplatesCoordinatesList> templateCoordinatesList) {
		this.templateCoordinatesList = templateCoordinatesList;
	}

	/**
	 * @return the responseMessage
	 */
	public String getResponseMessage() {
		return responseMessage;
	}

	/**
	 * @param responseMessage the responseMessage to set
	 */
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	
	/**
	 * @return the printAreaCoords
	 */
	public List<Integer> getPrintAreaCoords() {
		return printAreaCoords;
	}

	/**
	 * @param printAreaCoords the printAreaCoords to set
	 */
	public void setPrintAreaCoords(List<Integer> printAreaCoords) {
		this.printAreaCoords = printAreaCoords;
	}
}
