package com.scb.ms.mule.entity;

import org.springframework.data.annotation.Id;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpDatacapScan {

	@Id
	private String id;
	private String dealId;
	private String productId;
	private String stepId;
	private String clientId;
	private String country;
	private String regTimestamp;
	private String regTimeMsStr;
	private String tdApplicationReferenceId;
	private String sysDate;
	private String systemCode;
	private String filenetDocumentId;
	private String scanStartTime;
	private String scanEndTime;
	private String recogStartTime;
	private String recogEndTime;
	private String pageIdStartTime;
	private String pageIdEndTime;
	private String findTemplateStartTime;
	private String findTemplateEndTime;
	private String filenetExportStartTime;
	private String filenetExportEndTime;
	private String wexExportStartTime;
	private String wexExportEndTime;
	private String datacapBatchId;

	private String dealRoutingStartTime = "";
	private String dealRoutingEndTime = "";
	private String dealType = "";
	private String subProductCode = "";

	private List<SCBOcrNlpDatacapScanPage> documentPagesList = new ArrayList<>();

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the dealId
	 */
	public String getDealId() {
		return dealId;
	}

	/**
	 * @param dealId
	 *            the dealId to set
	 */
	public void setDealId(String dealId) {
		this.dealId = dealId;
	}

	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}

	/**
	 * @param productId
	 *            the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}

	/**
	 * @return the stepId
	 */
	public String getStepId() {
		return stepId;
	}

	/**
	 * @param stepId
	 *            the stepId to set
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}

	/**
	 * @return the clientId
	 */
	public String getClientId() {
		return clientId;
	}

	/**
	 * @param clientId
	 *            the clientId to set
	 */
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country
	 *            the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

	/**
	 * @return the regTimestamp
	 */
	public String getRegTimestamp() {
		return regTimestamp;
	}

	/**
	 * @param regTimestamp
	 *            the regTimestamp to set
	 */
	public void setRegTimestamp(String regTimestamp) {
		this.regTimestamp = regTimestamp;
	}

	/**
	 * @return the regTimeMsStr
	 */
	public String getRegTimeMsStr() {
		return regTimeMsStr;
	}

	/**
	 * @param regTimeMsStr
	 *            the regTimeMsStr to set
	 */
	public void setRegTimeMsStr(String regTimeMsStr) {
		this.regTimeMsStr = regTimeMsStr;
	}

	/**
	 * @return the tdApplicationReferenceId
	 */
	public String getTdApplicationReferenceId() {
		return tdApplicationReferenceId;
	}

	/**
	 * @param tdApplicationReferenceId
	 *            the tdApplicationReferenceId to set
	 */
	public void setTdApplicationReferenceId(String tdApplicationReferenceId) {
		this.tdApplicationReferenceId = tdApplicationReferenceId;
	}

	/**
	 * @return the sysDate
	 */
	public String getSysDate() {
		return sysDate;
	}

	/**
	 * @param sysDate
	 *            the sysDate to set
	 */
	public void setSysDate(String sysDate) {
		this.sysDate = sysDate;
	}

	/**
	 * @return the systemCode
	 */
	public String getSystemCode() {
		return systemCode;
	}

	/**
	 * @param systemCode
	 *            the systemCode to set
	 */
	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	/**
	 * @return the filenetDocumentId
	 */
	public String getFilenetDocumentId() {
		return filenetDocumentId;
	}

	/**
	 * @param filenetDocumentId
	 *            the filenetDocumentId to set
	 */
	public void setFilenetDocumentId(String filenetDocumentId) {
		this.filenetDocumentId = filenetDocumentId;
	}

	/**
	 * @return the scanStartTime
	 */
	public String getScanStartTime() {
		return scanStartTime;
	}

	/**
	 * @param scanStartTime
	 *            the scanStartTime to set
	 */
	public void setScanStartTime(String scanStartTime) {
		this.scanStartTime = scanStartTime;
	}

	/**
	 * @return the scanEndTime
	 */
	public String getScanEndTime() {
		return scanEndTime;
	}

	/**
	 * @param scanEndTime
	 *            the scanEndTime to set
	 */
	public void setScanEndTime(String scanEndTime) {
		this.scanEndTime = scanEndTime;
	}

	/**
	 * @return the recogStartTime
	 */
	public String getRecogStartTime() {
		return recogStartTime;
	}

	/**
	 * @param recogStartTime
	 *            the recogStartTime to set
	 */
	public void setRecogStartTime(String recogStartTime) {
		this.recogStartTime = recogStartTime;
	}

	/**
	 * @return the recogEndTime
	 */
	public String getRecogEndTime() {
		return recogEndTime;
	}

	/**
	 * @param recogEndTime
	 *            the recogEndTime to set
	 */
	public void setRecogEndTime(String recogEndTime) {
		this.recogEndTime = recogEndTime;
	}

	/**
	 * @return the pageIdStartTime
	 */
	public String getPageIdStartTime() {
		return pageIdStartTime;
	}

	/**
	 * @param pageIdStartTime
	 *            the pageIdStartTime to set
	 */
	public void setPageIdStartTime(String pageIdStartTime) {
		this.pageIdStartTime = pageIdStartTime;
	}

	/**
	 * @return the pageIdEndTime
	 */
	public String getPageIdEndTime() {
		return pageIdEndTime;
	}

	/**
	 * @param pageIdEndTime
	 *            the pageIdEndTime to set
	 */
	public void setPageIdEndTime(String pageIdEndTime) {
		this.pageIdEndTime = pageIdEndTime;
	}

	/**
	 * @return the findTemplateStartTime
	 */
	public String getFindTemplateStartTime() {
		return findTemplateStartTime;
	}

	/**
	 * @param findTemplateStartTime
	 *            the findTemplateStartTime to set
	 */
	public void setFindTemplateStartTime(String findTemplateStartTime) {
		this.findTemplateStartTime = findTemplateStartTime;
	}

	/**
	 * @return the findTemplateEndTime
	 */
	public String getFindTemplateEndTime() {
		return findTemplateEndTime;
	}

	/**
	 * @param findTemplateEndTime
	 *            the findTemplateEndTime to set
	 */
	public void setFindTemplateEndTime(String findTemplateEndTime) {
		this.findTemplateEndTime = findTemplateEndTime;
	}

	/**
	 * @return the filenetExportStartTime
	 */
	public String getFilenetExportStartTime() {
		return filenetExportStartTime;
	}

	/**
	 * @param filenetExportStartTime
	 *            the filenetExportStartTime to set
	 */
	public void setFilenetExportStartTime(String filenetExportStartTime) {
		this.filenetExportStartTime = filenetExportStartTime;
	}

	/**
	 * @return the filenetExportEndTime
	 */
	public String getFilenetExportEndTime() {
		return filenetExportEndTime;
	}

	/**
	 * @param filenetExportEndTime
	 *            the filenetExportEndTime to set
	 */
	public void setFilenetExportEndTime(String filenetExportEndTime) {
		this.filenetExportEndTime = filenetExportEndTime;
	}

	/**
	 * @return the wexExportStartTime
	 */
	public String getWexExportStartTime() {
		return wexExportStartTime;
	}

	/**
	 * @param wexExportStartTime
	 *            the wexExportStartTime to set
	 */
	public void setWexExportStartTime(String wexExportStartTime) {
		this.wexExportStartTime = wexExportStartTime;
	}

	/**
	 * @return the wexExportEndTime
	 */
	public String getWexExportEndTime() {
		return wexExportEndTime;
	}

	/**
	 * @param wexExportEndTime
	 *            the wexExportEndTime to set
	 */
	public void setWexExportEndTime(String wexExportEndTime) {
		this.wexExportEndTime = wexExportEndTime;
	}

	/**
	 * @return the datacapBatchId
	 */
	public String getDatacapBatchId() {
		return datacapBatchId;
	}

	/**
	 * @param datacapBatchId
	 *            the datacapBatchId to set
	 */
	public void setDatacapBatchId(String datacapBatchId) {
		this.datacapBatchId = datacapBatchId;
	}

	/**
	 * @return the dealRoutingStartTime
	 */
	public String getDealRoutingStartTime() {
		return dealRoutingStartTime;
	}

	/**
	 * @param dealRoutingStartTime
	 *            the dealRoutingStartTime to set
	 */
	public void setDealRoutingStartTime(String dealRoutingStartTime) {
		this.dealRoutingStartTime = dealRoutingStartTime;
	}

	/**
	 * @return the dealRoutingEndTime
	 */
	public String getDealRoutingEndTime() {
		return dealRoutingEndTime;
	}

	/**
	 * @param dealRoutingEndTime
	 *            the dealRoutingEndTime to set
	 */
	public void setDealRoutingEndTime(String dealRoutingEndTime) {
		this.dealRoutingEndTime = dealRoutingEndTime;
	}

	/**
	 * @return the dealType
	 */
	public String getDealType() {
		return dealType;
	}

	/**
	 * @param dealType
	 *            the dealType to set
	 */
	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	/**
	 * @return the documentPagesList
	 */
	public List<SCBOcrNlpDatacapScanPage> getDocumentPagesList() {
		return documentPagesList;
	}

	/**
	 * @param documentPagesList
	 *            the documentPagesList to set
	 */
	public void setDocumentPagesList(List<SCBOcrNlpDatacapScanPage> documentPagesList) {
		this.documentPagesList = documentPagesList;
	}

	/**
	 * @return the subProductCode
	 */
	public String getSubProductCode() {
		return subProductCode;
	}

	/**
	 * @param subProductCode
	 *            the subProductCode to set
	 */
	public void setSubProductCode(String subProductCode) {
		this.subProductCode = subProductCode;
	}

}
