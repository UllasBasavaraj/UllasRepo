package com.scb.ms.mule.entity;

public class SCBOcrNlpOTPNewTxnUpdateReq {

	private SCBOcrNlpOTPNewUpdateReq docCreateRequest;

	/**
	 * @return the docCreateRequest
	 */
	public SCBOcrNlpOTPNewUpdateReq getDocCreateRequest() {
		return docCreateRequest;
	}

	/**
	 * @param docCreateRequest the docCreateRequest to set
	 */
	public void setDocCreateRequest(SCBOcrNlpOTPNewUpdateReq docCreateRequest) {
		this.docCreateRequest = docCreateRequest;
	}



}
