package com.scb.ms.mule.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SCBOcrNlpDatacapTemplateFeedbackPage {
    @JsonProperty("templateReqId")
    private String templateReqId;
    @JsonProperty("docClsTyp")
    private String docClsTyp;
    @JsonProperty("pageLocation")
    private String pageLocation;
    @JsonProperty("ccoLocation")
    private String ccoLocation;
    @JsonProperty("layoutxmlLocation")
    private String layoutxmlLocation;
    @JsonProperty("partyName")
    private String partyName;
	/**
	 * @return the templateReqId
	 */
	public String getTemplateReqId() {
		return templateReqId;
	}
	/**
	 * @param templateReqId the templateReqId to set
	 */
	public void setTemplateReqId(String templateReqId) {
		this.templateReqId = templateReqId;
	}
	/**
	 * @return the docClsTyp
	 */
	public String getDocClsTyp() {
		return docClsTyp;
	}
	/**
	 * @param docClsTyp the docClsTyp to set
	 */
	public void setDocClsTyp(String docClsTyp) {
		this.docClsTyp = docClsTyp;
	}
	/**
	 * @return the pageLocation
	 */
	public String getPageLocation() {
		return pageLocation;
	}
	/**
	 * @param pageLocation the pageLocation to set
	 */
	public void setPageLocation(String pageLocation) {
		this.pageLocation = pageLocation;
	}
	/**
	 * @return the ccoLocation
	 */
	public String getCcoLocation() {
		return ccoLocation;
	}
	/**
	 * @param ccoLocation the ccoLocation to set
	 */
	public void setCcoLocation(String ccoLocation) {
		this.ccoLocation = ccoLocation;
	}
	/**
	 * @return the layoutxmlLocation
	 */
	public String getLayoutxmlLocation() {
		return layoutxmlLocation;
	}
	/**
	 * @param layoutxmlLocation the layoutxmlLocation to set
	 */
	public void setLayoutxmlLocation(String layoutxmlLocation) {
		this.layoutxmlLocation = layoutxmlLocation;
	}
	/**
	 * @return the partyName
	 */
	public String getPartyName() {
		return partyName;
	}
	/**
	 * @param partyName the partyName to set
	 */
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
    
}
