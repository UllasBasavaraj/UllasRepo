package com.scb.ms.mule.transformer;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.config.i18n.CoreMessages;
import org.mule.transformer.AbstractMessageTransformer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.scb.core.transformer.SCBCommObjTransformer;
import com.scb.ms.communication.SCBCommObj;
import com.scb.ms.communication.SCBSection;
import com.scb.ms.mule.entity.SCBOcrNlpDealDataObjectExtn;
import com.scb.ms.mule.entity.SCBOcrNlpHighlightList;
import com.scb.ms.mule.entity.SCBOcrNlpNameCaptureList;
import com.scb.ms.mule.entity.SCBOcrNlpNamesScreeningListRequest;
import com.scb.ms.mule.entity.SCBOcrNlpNamesScreeningRequest;
import com.scb.ms.mule.entity.SCBOcrNlpPartyDetails;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.HighLightTypes;
import com.scb.ms.mule.util.SCBOcrNlpMuleConstants.Sections;
import com.scb.ms.mule.util.SCBOcrNlpUtil;

public class SCBOcrNlpToOTPOthrsTransformer extends AbstractMessageTransformer {
	private static final Logger log = LoggerFactory.getLogger(SCBOcrNlpToOTPOthrsTransformer.class);
	private String transformerType;
	private static String EMPTY = SCBOcrNlpMuleConstants.EMPTY_STRING;

	@Override
	public Object transformMessage(MuleMessage message, String arg1) throws TransformerException {
		log.debug("Enter in to SCBNLPToOTPOthrsTransformer calss ");
		String vppGenericJson = null;
		Object source = null;
		if (message != null) {
			ObjectMapper mapper = new ObjectMapper();
			String input = null;
			SCBCommObj commObj = null;
			SCBOcrNlpNamesScreeningRequest namesScreeningReq = null;
			SCBOcrNlpNamesScreeningListRequest nameScreeningReqObj = null;
			String loggerDealId = EMPTY;
			try {
				source = message.getPayload();
				log.debug("source ==>" + source);
				if (source instanceof String) {
					input = (String) source;
				} else if (source instanceof InputStream) {
					input = IOUtils.toString((InputStream) source, "UTF-8");
				} else if (source instanceof SCBCommObj) {
					log.debug("comm object");
					commObj = (SCBCommObj) source;
				}
				if (null != input) {
					commObj = mapper.readValue(input, SCBCommObj.class);
				}
				log.debug("commObj " + commObj.getBodySection(Sections.OTP_OTHRS_REQUEST_INFO));
				SCBSection section = ((SCBCommObj) commObj).getBodySection(Sections.OTP_OTHRS_REQUEST_INFO);
				if (null != section) {
					SCBOcrNlpDealDataObjectExtn getDealDataExtobj = new SCBOcrNlpDealDataObjectExtn();
					getDealDataExtobj = (SCBOcrNlpDealDataObjectExtn) SCBCommObjTransformer.sectionToSCBPojo(commObj,
							getDealDataExtobj);
					try {
						if (getDealDataExtobj != null) {
							loggerDealId = getDealDataExtobj.getDealId();
							String countryCode = getDealDataExtobj.getCountry();
							log.debug(loggerDealId + " - Country code of Deal    " + countryCode);
							countryCode = getDealDataExtobj.getCountry();
							String systemCode = getDealDataExtobj.getSystemCode();
							String reqTimeStamp = getDealDataExtobj.getRegTimeStamp();
							namesScreeningReq = new SCBOcrNlpNamesScreeningRequest();
							namesScreeningReq.setUuid("OCRNLP" + SCBOcrNlpUtil.getCurrDate());
							namesScreeningReq.setSystemCode(systemCode);
							namesScreeningReq.setCountryCode(countryCode);
							namesScreeningReq.setCustomerId(getDealDataExtobj.getClientId());
							namesScreeningReq.setDealReferance(getDealDataExtobj.getDealId());
							namesScreeningReq.setProductCode(getDealDataExtobj.getProductId());
							namesScreeningReq.setRegTimeStamp(SCBOcrNlpUtil.getTDTimeStamp(reqTimeStamp));
							namesScreeningReq.setStepCode(getDealDataExtobj.getStepId());
							List<SCBOcrNlpNameCaptureList> namecaptureList = getDealDataExtobj.getNameCaptureList();
							List<SCBOcrNlpPartyDetails> partyDetailsList = new ArrayList<SCBOcrNlpPartyDetails>();

							if (CollectionUtils.isNotEmpty(namecaptureList)) {
								for (SCBOcrNlpNameCaptureList namecaptureObj : namecaptureList) {

									SCBOcrNlpPartyDetails partyDetailsObj = new SCBOcrNlpPartyDetails();
									partyDetailsObj.setPartyExtId(namecaptureObj.getExtensionId());
									partyDetailsObj.setPartyId(namecaptureObj.getPartyId());
									partyDetailsObj.setPartyRole(namecaptureObj.getRoleCode());
									partyDetailsObj.setDocNumber(namecaptureObj.getDocInvoiceNumber() != null
											? namecaptureObj.getDocInvoiceNumber() : EMPTY);
								    partyDetailsObj.setOpCode(namecaptureObj.getRoleStatus());

									List<SCBOcrNlpHighlightList> highLightList = namecaptureObj.getHighlightsList();
									if (CollectionUtils.isNotEmpty(highLightList)) {
										for (SCBOcrNlpHighlightList highLightObj : highLightList) {
											switch (highLightObj.getType()) {
											case HighLightTypes.NAME:
												partyDetailsObj.setPartyName(highLightObj.getValue() != null
														? highLightObj.getValue().toUpperCase() : EMPTY);
												break;
											case HighLightTypes.ADDR1:
												partyDetailsObj.setAddress1(highLightObj.getValue() != null
														? highLightObj.getValue().toUpperCase() : EMPTY);
												break;
											case HighLightTypes.ADDR2:
												partyDetailsObj.setAddress2(highLightObj.getValue() != null
														? highLightObj.getValue().toUpperCase() : EMPTY);
												break;
											case HighLightTypes.ADDR3:
												partyDetailsObj.setAddress3(highLightObj.getValue() != null
														? highLightObj.getValue().toUpperCase() : EMPTY);
												break;
											case HighLightTypes.COUNTRY:
												partyDetailsObj.setAddCtyCode(namecaptureObj.getCountryCode());
												break;
											default:
												log.error(loggerDealId + " - No Highlight list match");
											}
										}
									}
									partyDetailsList.add(partyDetailsObj);

								}
							}
							namesScreeningReq.setPartyDetails(partyDetailsList);
							nameScreeningReqObj = new SCBOcrNlpNamesScreeningListRequest();
							nameScreeningReqObj.setSanctionPartiesRequest(namesScreeningReq);
						}
					} catch (Exception e) {
						log.error(loggerDealId + " - Error in NLP to OTP OTH Transformer" + e);
					}
				}
				vppGenericJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(nameScreeningReqObj);
				log.debug(loggerDealId + " - Name Screening request to OTP Othrs system  ==>" + vppGenericJson);

			} catch (Exception e) {
				log.error(loggerDealId + " - Error in NLP to OTP OTH Transformer" + e);
				throw new TransformerException(
						CoreMessages.createStaticMessage(loggerDealId
								+ " - Unable to transform commobj to Generic Json in NLPToOTPOthrs class " + source),
						e);
			}
		}
		return vppGenericJson;
	}

	public String getTransformerType() {
		return transformerType;
	}

	public void setTransformerType(String transformerType) {
		this.transformerType = transformerType;
	}

}
