package com.scb.ms.mule.entity;

import java.util.ArrayList;
import java.util.List;

public class SCBOcrNlpWexPageListInfo {

	private String dealExtnSeqId = "";
	private String wexInput = "";
	private String wexOutput = "";
	private String wexTemplateInput = "";
	private String wexTemplateOutput = "";
	private String wexDataExtractInput = "";
	private String wexDataExtractOutput = "";
	private String docPageId;
	private List<SCBOcrNlpNameCaptureList> nameCaptureList = new ArrayList<SCBOcrNlpNameCaptureList>();
	/**
	 * @return the dealExtnSeqId
	 */
	public String getDealExtnSeqId() {
		return dealExtnSeqId;
	}
	/**
	 * @param dealExtnSeqId the dealExtnSeqId to set
	 */
	public void setDealExtnSeqId(String dealExtnSeqId) {
		this.dealExtnSeqId = dealExtnSeqId;
	}
	/**
	 * @return the wexInput
	 */
	public String getWexInput() {
		return wexInput;
	}
	/**
	 * @param wexInput the wexInput to set
	 */
	public void setWexInput(String wexInput) {
		this.wexInput = wexInput;
	}
	/**
	 * @return the wexOutput
	 */
	public String getWexOutput() {
		return wexOutput;
	}
	/**
	 * @param wexOutput the wexOutput to set
	 */
	public void setWexOutput(String wexOutput) {
		this.wexOutput = wexOutput;
	}
	/**
	 * @return the wexTemplateInput
	 */
	public String getWexTemplateInput() {
		return wexTemplateInput;
	}
	/**
	 * @param wexTemplateInput the wexTemplateInput to set
	 */
	public void setWexTemplateInput(String wexTemplateInput) {
		this.wexTemplateInput = wexTemplateInput;
	}
	/**
	 * @return the wexTemplateOutput
	 */
	public String getWexTemplateOutput() {
		return wexTemplateOutput;
	}
	/**
	 * @param wexTemplateOutput the wexTemplateOutput to set
	 */
	public void setWexTemplateOutput(String wexTemplateOutput) {
		this.wexTemplateOutput = wexTemplateOutput;
	}
	/**
	 * @return the wexDataExtractInput
	 */
	public String getWexDataExtractInput() {
		return wexDataExtractInput;
	}
	/**
	 * @param wexDataExtractInput the wexDataExtractInput to set
	 */
	public void setWexDataExtractInput(String wexDataExtractInput) {
		this.wexDataExtractInput = wexDataExtractInput;
	}
	/**
	 * @return the wexDataExtractOutput
	 */
	public String getWexDataExtractOutput() {
		return wexDataExtractOutput;
	}
	/**
	 * @param wexDataExtractOutput the wexDataExtractOutput to set
	 */
	public void setWexDataExtractOutput(String wexDataExtractOutput) {
		this.wexDataExtractOutput = wexDataExtractOutput;
	}
	/**
	 * @return the docPageId
	 */
	public String getDocPageId() {
		return docPageId;
	}
	/**
	 * @param docPageId the docPageId to set
	 */
	public void setDocPageId(String docPageId) {
		this.docPageId = docPageId;
	}
	/**
	 * @return the nameCaptureList
	 */
	public List<SCBOcrNlpNameCaptureList> getNameCaptureList() {
		return nameCaptureList;
	}
	/**
	 * @param nameCaptureList the nameCaptureList to set
	 */
	public void setNameCaptureList(List<SCBOcrNlpNameCaptureList> nameCaptureList) {
		this.nameCaptureList = nameCaptureList;
	}


}
