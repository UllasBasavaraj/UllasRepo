#!groovy

// Example: EMAIL_RECIPIENTS = "ACB.D@sc.com, EFG.H@sc.com"
EMAIL_RECIPIENTS = "Selvamani.Sambath@sc.com"

echo "Configured Email Recipients: " + EMAIL_RECIPIENTS